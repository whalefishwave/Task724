/* ============================================================
 * ClawHunt #1724 · 零依赖原型 · 多标签页可交互工作台
 * - 纯原生 JS/CSS，零构建、零第三方依赖
 * - 页签：A 创意工作台 / B 企业AI服务层 / C IP工作室 / D 赛事包
 *         订单与工厂 / 契约与规则 / 验收与部署
 * - 真实接口：/api/health · /api/industries · /api/components/{industry}
 * - 授权强校验(G2)与订单状态机追溯(G4)为前端交互演示（不编造端点）
 * ============================================================ */

const STATUS_FLOW = [
  { key: 'DRAFT', zh: '草稿', en: 'Draft', de: 'Entwurf' },
  { key: 'ORDERED', zh: '已下单', en: 'Ordered', de: 'Bestellt' },
  { key: 'PRODUCING', zh: '生产中', en: 'Producing', de: 'In Produktion' },
  { key: 'QC', zh: '质检中', en: 'QC Check', de: 'Qualitätsprüfung' },
  { key: 'PACKED', zh: '已打包', en: 'Packed', de: 'Verpackt' },
  { key: 'SHIPPED', zh: '已发货', en: 'Shipped', de: 'Versendet' },
  { key: 'ACCEPTED', zh: '已验收', en: 'Accepted', de: 'Abgenommen' },
];

const I18N = {
  zh: {
    brand: 'ClawHunt #1724',
    chip: '零依赖原型 · 多标签工作台',
    heroTitle: '工艺AI共创 + C2M 柔性定制平台',
    heroSub: '区域特色产业 AI 赋能一期 · 六产业共享企业 AI 服务层 FDE · 全链路可演示工作台（零依赖版）',
    stackNote: 'Python 标准库 http.server（ThreadingHTTPServer）· 原生 JS/CSS（无构建）· 零第三方依赖 · 离线可运行 · Docker Compose 一键部署',
    footer: '业务核心在 module_a~d，API 层由零依赖 server.py 暴露；A/B/验收页数据来自真实接口，交互演示不调用后端',
    tabs: { a: 'A 创意工作台', b: 'B 企业AI服务层', c: 'C IP工作室', d: 'D 赛事包', orders: '订单与工厂', contracts: '契约与规则', ops: '验收与部署' },
    a: {
      title: '创意工作台 · MODULE A', sub: '概念生成 → 授权强校验（G2）→ 可制造性判定',
      conceptTitle: '概念生成表单（演示）', conceptHint: '选择行业后自动读取真实行业组件，生成演示概念摘要',
      material: '材料', process: '工艺', style: '风格', conceptNote: '创意备注',
      industryLabel: '目标行业', placeholderConcept: '例如：将传统银器工艺与现代极简风格结合…',
      generate: '生成概念', clearing: '清理', conceptResult: '生成的概念摘要', noIndustry: '请先选择行业',
      conceptLine: '面向「{industry}」的 AI 共创概念：{style} × {material}，主工艺 {process}，建议优先复用行业组件并走授权校验后再进入打样。',
      authTitle: '授权强校验演示（G2 · 缺任一字段即拒绝）',
      authDesc: '模拟后端强校验：授权方 / 授权类型 / 地域 / 期限 / 使用范围 / 分成比例 六项必填，少任意一项都拒绝（6/6 通过才算通过）。',
      authFields: { holder: '被授权方', type: '授权类型', region: '地域范围', term: '授权期限', scope: '使用范围', ratio: '分成比例' },
      authPlaceholders: { holder: '如：XX 工坊有限公司', type: '如：独占授权', region: '如：中国大陆', term: '如：2026-01-01 ~ 2026-12-31', scope: '如：电商渠道', ratio: '如：30%' },
      runAuth: '执行强校验', authPass: '校验通过 · 授权合法', authReject: '校验拒绝 · 缺少字段',
      missingList: '缺失字段', allPass: '六项全部通过',
      manufactTitle: '可制造性判定展示', manufactHint: '基于真实行业组件清单（/api/components/{industry}）做可制造性判定',
      manufactDecision: '判定结果', manufactReady: '可制造 · 组件齐备', manufactBlock: '待补充 · 组件不足', compLabel: '可用组件',
    },
    b: {
      title: '企业AI服务层 · MODULE B（FDE）', sub: '六产业共享服务 · 行业配置切换（真实接口）· 出海询盘闭环',
      industryTitle: '行业组件切换（真实接口）', industryHint: 'GET /api/industries → GET /api/components/{industry}',
      currentIndustry: '当前行业', switchTo: '切换到该行业', loading: '加载中…', noData: '暂无数据',
      compTitle: '行业组件能力',
      inquiryTitle: '出海询盘表单（演示）', inquiryHint: '后端暂未暴露询盘端点，以下为本地演示闭环',
      inqCompany: '企业名称', inqContact: '联系人', inqCountry: '目标市场', inqLang: '咨询语言',
      inqMsg: '需求描述', submitInquiry: '提交询盘', inquiryOk: '已收录询盘',
      inquiries: '询盘台账（CRM 演示）', emptyInquiries: '暂无询盘记录',
      countries: ['中国大陆', '欧洲', '北美', '东南亚', '中东'],
      languages: ['中文', 'English', 'Deutsch'],
    },
    c: {
      title: 'IP工作室 · MODULE C', sub: '设计师 × 匠人双角色共创 · 授权矩阵 · 样片入口（发布版保留正式样片，私有资产按防白嫖约定剔除）',
      roleTitle: '双角色共创',
      roles: [
        { k: 'designer', n: '设计师', d: '概念创意 / 视觉资产 / IP 形象设计，产出可登记资产' },
        { k: 'craftsman', n: '匠人', d: '工艺实现 / 打样制造 / 质检反馈，与设计师协同迭代' },
      ],
      matrixTitle: '授权矩阵（演示规则）', matrixHint: '发布版不暴露真实授权数据，以下为演示结构',
      matrixHead: ['资产', '独占授权', '非独占授权', '地域限制', '分成比例'],
      matrixRows: [
        ['IP 视觉形象', '√', '—', '中国大陆', '30%'],
        ['工艺参数集', '√', '√', '全球', '25%'],
        ['短剧样片', '—', '√', '指定渠道', '20%'],
      ],
      sampleTitle: '样片入口',
      sampleHint: '正式样片（AI 配音 / 1080p）保留于发布版供演示；拼接中间产物与私有音频已剔除。',
      sampleAction: '申请查看样片（演示）', sampleModalTitle: '样片预览（演示）',
      sampleMain: '正式样片（AI 配音 · 1080p）', sampleLoading: '加载中…', sampleReady: '可播放',
      sampleHidden: '演示样片按防白嫖约定隐藏，中标后提供', sampleClose: '关闭',
    },
    d: {
      title: '设计共创赛事包 · MODULE D', sub: '三赛道报名（演示）· 智能评审门禁 · KPI 看板',
      trackTitle: '三赛道',
      tracks: [
        { k: 'craft', n: '工艺创新赛道', d: '材料 × 工艺 × 传统再造' },
        { k: 'ip', n: 'IP 衍生赛道', d: '文化 IP × 商业衍生设计' },
        { k: 'combo', n: '跨界融合赛道', d: '多产业 C2M 柔性定制' },
      ],
      regTitle: '赛事报名（演示）', regName: '团队 / 个人名称', regTrack: '报名赛道', regCity: '所在地区', regDesc: '作品简介',
      submitReg: '提交报名', regOk: '报名已受理（演示）', entries: '报名台账', emptyEntries: '暂无报名',
      gateTitle: '打样门禁（演示规则）',
      gateRules: ['提交报名 → 资格审核 → 智能评审打分 → 通过后解锁打样资源', '发布版不暴露真实评审模型，门禁规则为演示'],
    },
    orders: {
      title: '订单与工厂', sub: '订单创建（演示）· 订单状态机追溯 G4 台账（可视化）',
      createTitle: '订单创建表单（演示）', createHint: '后端暂未暴露订单端点，本地演示生成订单并驱动状态机',
      ordProduct: '产品', ordQty: '数量', ordBatch: '批次', ordDeadline: '交期',
      ordPlaceholders: { product: '如：银饰 C2M 定制项链', qty: '如：200', batch: '如：B-2026-003', deadline: '如：2026-12-01' },
      createOrder: '创建订单', orders: '订单列表', emptyOrders: '暂无订单', status: '当前状态',
      stepperTitle: '订单状态机追溯（G4 · 台账可追溯）',
      stepperHint: '点击事件按钮推进状态，右侧台账记录每一步（含时间戳）',
      trigger: '触发事件', timeline: '追溯台账', emptyTimeline: '尚无事件记录', eventPlaceholder: '选择订单',
      evtCreate: '创建', evtOrder: '派单', evtProduce: '生产', evtQc: '质检', evtPack: '打包', evtShip: '发货', evtAccept: '验收',
      noOrderHint: '先在上方创建订单，再驱动状态机',
    },
    contracts: {
      title: '契约与规则', sub: '授权契约类型 · 分成规则 · 合规标识（发布版为演示结构）',
      typesTitle: '授权契约类型（演示）',
      types: [
        { n: '独占授权契约', d: '被授权方在约定地域/渠道独占使用，分成比例最高' },
        { n: '非独占授权契约', d: '多被授权方并行，按实际销售额分成' },
        { n: '定制生产契约', d: 'C2M 一单一产，含交期与验收条款' },
      ],
      rulesTitle: '分成与迁移规则（演示）',
      rules: [
        '授权分成比例在发布版中占位为 null，真实比例于中标后按业务确认',
        '状态机迁移规则：DRAFT→ORDERED→PRODUCING→QC→PACKED→SHIPPED→ACCEPTED',
        'G2 强校验：六字段缺一即拒绝，防止授权要素不完整进入生产',
      ],
      complianceTitle: '合规标识覆盖（G10）',
      complianceHint: '数据文件 22/22 已覆盖合成/脱敏标识，发布版保留声明',
    },
    ops: {
      title: '验收与部署', sub: 'G1–G10 自检清单 · 服务端口 · 后端健康状态（真实接口）',
      healthTitle: '后端服务健康', healthOk: '在线', healthBad: '不可达', healthChecking: '检测中…',
      healthErrorHint: '请先运行 python server.py（或 docker compose up -d --build），再访问本页',
      verifyTitle: 'G1–G10 验收自检清单（VERIFICATION.md）',
      verify: [
        ['G1', '四流程全链闭环：A工艺共创 / B六组件 / C双角色+授权 / D赛事门禁'],
        ['G2', '授权强校验：缺任一字段拒绝 6/6，全字段通过'],
        ['G3', '可制造性规则与人工一致 10/10'],
        ['G4', '订单状态机：QC 台账 7 条可追溯'],
        ['G5', '企业AI服务层可配置行业：jewelry / wood'],
        ['G6', '出海栈三语（zh / en / de）+ 询盘 CRM 闭环'],
        ['G7', '双角色共创 + 授权矩阵 + 正式样片落盘'],
        ['G8', 'tests.py 125 用例全绿，exit=0'],
        ['G9', '自检命令真实可运行 8/8（init_check/compliance/demo/tests/verify）'],
        ['G10', '合成 / 脱敏标识覆盖数据文件 22/22'],
      ],
      portsTitle: '服务端口',
      ports: [
        ['8000', '零依赖 HTTP 服务 + Web 工作台', 'http://<IP>:8000'],
        ['8000/api/health', '后端健康状态', 'http://<IP>:8000/api/health'],
        ['8000/media/*', '样片视频静态服务', 'http://<IP>:8000/media/ai_demo_1080p_voice_neil_bgm_v5.mp4'],
      ],
      colPort: '端口', colUse: '用途', colHow: '访问方式',
    },
    common: { backends: '后端', frontend: '前端', database: '数据库', statusOk: '正常', statusFail: '异常' },
  },

  en: {
    brand: 'ClawHunt #1724',
    chip: 'Zero-Dep Prototype · Multi-Tab Workbench',
    heroTitle: 'AI Co-Creation + C2M Flexible Customization Platform',
    heroSub: 'Regional Industry AI Enablement Phase 1 · FDE Shared Enterprise AI Service Layer · Full-Pipeline Demo Workbench (Zero-Dep)',
    stackNote: 'Python stdlib http.server (ThreadingHTTPServer) · Vanilla JS/CSS (no build) · Zero third-party deps · Offline-ready · Docker Compose one-click deploy',
    footer: 'Core logic lives in module_a~d, exposed via zero-dep server.py; tabs A/B/ops use real endpoints, interaction demos are frontend-only',
    tabs: { a: 'A Studio', b: 'B Enterprise AI', c: 'C IP Studio', d: 'D Contest', orders: 'Orders & Factory', contracts: 'Contracts & Rules', ops: 'Acceptance & Deploy' },
    a: {
      title: 'Co-Creation Studio · MODULE A', sub: 'Concept Generation → Authorization Check (G2) → Manufacturability',
      conceptTitle: 'Concept Generation Form (Demo)', conceptHint: 'Select an industry to load real components and generate a demo concept summary',
      material: 'Material', process: 'Process', style: 'Style', conceptNote: 'Concept Notes',
      industryLabel: 'Target Industry', placeholderConcept: 'e.g. combine traditional silver craft with modern minimalism…',
      generate: 'Generate Concept', clearing: 'Clear', conceptResult: 'Generated Concept Summary', noIndustry: 'Please select an industry first',
      conceptLine: 'AI co-creation concept for "{industry}": {style} × {material}, core process {process}; reuse industry components and pass authorization check before sampling.',
      authTitle: 'Authorization Strict Check Demo (G2 · Reject if any field missing)',
      authDesc: 'Simulates backend strict validation: holder / type / region / term / scope / ratio are all required; missing any one field means rejection (pass only when 6/6).',
      authFields: { holder: 'Licensee', type: 'License Type', region: 'Region', term: 'Term', scope: 'Usage Scope', ratio: 'Royalty Ratio' },
      authPlaceholders: { holder: 'e.g. XX Crafts Co., Ltd.', type: 'e.g. Exclusive', region: 'e.g. Mainland China', term: 'e.g. 2026-01-01 ~ 2026-12-31', scope: 'e.g. E-commerce', ratio: 'e.g. 30%' },
      runAuth: 'Run Strict Check', authPass: 'PASS · Authorization Valid', authReject: 'REJECTED · Missing Fields',
      missingList: 'Missing Fields', allPass: 'All 6 fields provided',
      manufactTitle: 'Manufacturability Assessment', manufactHint: 'Based on real component list from /api/components/{industry}',
      manufactDecision: 'Verdict', manufactReady: 'Manufacturable · Components Ready', manufactBlock: 'Blocked · Components Insufficient', compLabel: 'Available Components',
    },
    b: {
      title: 'Enterprise AI Service Layer · MODULE B (FDE)', sub: 'Six-Industry Shared Services · Industry Switching (Real API) · Overseas Inquiry Loop',
      industryTitle: 'Industry & Component Switching (Real API)', industryHint: 'GET /api/industries → GET /api/components/{industry}',
      currentIndustry: 'Current Industry', switchTo: 'Switch to this industry', loading: 'Loading…', noData: 'No data',
      compTitle: 'Industry Components',
      inquiryTitle: 'Overseas Inquiry Form (Demo)', inquiryHint: 'No inquiry endpoint exposed yet; this is a local demo loop',
      inqCompany: 'Company', inqContact: 'Contact', inqCountry: 'Target Market', inqLang: 'Language',
      inqMsg: 'Requirement', submitInquiry: 'Submit Inquiry', inquiryOk: 'Inquiry recorded',
      inquiries: 'Inquiry Ledger (CRM demo)', emptyInquiries: 'No inquiries yet',
      countries: ['Mainland China', 'Europe', 'North America', 'Southeast Asia', 'Middle East'],
      languages: ['中文', 'English', 'Deutsch'],
    },
    c: {
      title: 'IP Studio · MODULE C', sub: 'Designer × Craftsman Co-Creation · License Matrix · Sample Entry (publish keeps the official sample; private assets excluded)',
      roleTitle: 'Dual-Role Co-Creation',
      roles: [
        { k: 'designer', n: 'Designer', d: 'Concept / visual assets / IP design, registers assets' },
        { k: 'craftsman', n: 'Craftsman', d: 'Process realization / sampling / QC feedback, iterates with designer' },
      ],
      matrixTitle: 'License Matrix (Demo Rules)', matrixHint: 'Publish edition hides real license data; demo structure shown',
      matrixHead: ['Asset', 'Exclusive', 'Non-Exclusive', 'Region', 'Royalty'],
      matrixRows: [
        ['IP Visual Identity', '√', '—', 'Mainland China', '30%'],
        ['Craft Parameter Set', '√', '√', 'Global', '25%'],
        ['Short-Video Sample', '—', '√', 'Chosen Channels', '20%'],
      ],
      sampleTitle: 'Sample Entry',
      sampleHint: 'Official sample (AI voiceover / 1080p) is kept in the publish edition for demo; stitching intermediates and private audio are excluded.',
      sampleAction: 'Request Sample (Demo)', sampleModalTitle: 'Sample Preview (Demo)',
      sampleMain: 'Official Sample (AI Voice, 1080p)', sampleLoading: 'Loading…', sampleReady: 'Playable',
      sampleHidden: 'Demo samples are hidden per the anti-free-ride agreement; provided after award', sampleClose: 'Close',
    },
    d: {
      title: 'Design Co-Creation Contest · MODULE D', sub: 'Three Tracks Registration (Demo) · Smart Review Gate · KPI Board',
      trackTitle: 'Three Tracks',
      tracks: [
        { k: 'craft', n: 'Craft Innovation', d: 'Material × Process × Tradition Reinvention' },
        { k: 'ip', n: 'IP Derivative', d: 'Cultural IP × Commercial Design' },
        { k: 'combo', n: 'Cross-Industry Fusion', d: 'Multi-Industry C2M Customization' },
      ],
      regTitle: 'Contest Registration (Demo)', regName: 'Team / Individual', regTrack: 'Track', regCity: 'Region', regDesc: 'Work Description',
      submitReg: 'Submit Registration', regOk: 'Registration received (Demo)', entries: 'Registration Ledger', emptyEntries: 'No registrations',
      gateTitle: 'Sampling Gate (Demo Rules)',
      gateRules: ['Register → Eligibility → AI review scoring → unlock sampling after pass', 'Publish edition hides the real review model; gate rules are demo'],
    },
    orders: {
      title: 'Orders & Factory', sub: 'Order Creation (Demo) · Order State Machine Trace G4 Ledger (Visualized)',
      createTitle: 'Order Creation Form (Demo)', createHint: 'No order endpoint exposed yet; local demo generates orders and drives the state machine',
      ordProduct: 'Product', ordQty: 'Qty', ordBatch: 'Batch', ordDeadline: 'Deadline',
      ordPlaceholders: { product: 'e.g. Silver C2M custom necklace', qty: 'e.g. 200', batch: 'e.g. B-2026-003', deadline: 'e.g. 2026-12-01' },
      createOrder: 'Create Order', orders: 'Order List', emptyOrders: 'No orders', status: 'Status',
      stepperTitle: 'Order State Machine Trace (G4 · Traceable Ledger)',
      stepperHint: 'Click event buttons to advance status; ledger records every step with timestamp',
      trigger: 'Trigger Event', timeline: 'Trace Ledger', emptyTimeline: 'No events yet', eventPlaceholder: 'Select an order',
      evtCreate: 'Create', evtOrder: 'Dispatch', evtProduce: 'Produce', evtQc: 'QC', evtPack: 'Pack', evtShip: 'Ship', evtAccept: 'Accept',
      noOrderHint: 'Create an order above first, then drive the state machine',
    },
    contracts: {
      title: 'Contracts & Rules', sub: 'License Contract Types · Royalty Rules · Compliance Marking (demo structure in publish)',
      typesTitle: 'License Contract Types (Demo)',
      types: [
        { n: 'Exclusive License', d: 'Exclusive use in agreed region/channel, highest royalty' },
        { n: 'Non-Exclusive License', d: 'Parallel licensees, royalty on actual sales' },
        { n: 'Custom Production Contract', d: 'C2M one-order-one-production with delivery & acceptance terms' },
      ],
      rulesTitle: 'Royalty & Transition Rules (Demo)',
      rules: [
        'Royalty ratios are placeholders (null) in publish edition; real values confirmed after award',
        'State machine transitions: DRAFT→ORDERED→PRODUCING→QC→PACKED→SHIPPED→ACCEPTED',
        'G2 strict check: reject if any of the 6 fields missing to prevent incomplete licensing into production',
      ],
      complianceTitle: 'Compliance Marking Coverage (G10)',
      complianceHint: '22/22 data files covered with synthetic/anonymization marks; declaration kept in publish',
    },
    ops: {
      title: 'Acceptance & Deployment', sub: 'G1–G10 Checklist · Service Ports · Backend Health (Real API)',
      healthTitle: 'Backend Health', healthOk: 'Online', healthBad: 'Unreachable', healthChecking: 'Checking…',
      healthErrorHint: 'Run python server.py (or docker compose up -d --build) first, then revisit this page',
      verifyTitle: 'G1–G10 Acceptance Checklist (VERIFICATION.md)',
      verify: [
        ['G1', 'Four flows closed-loop: A co-creation / B six components / C dual-role+license / D contest gate'],
        ['G2', 'Strict authorization check: reject 6/6 when any field missing, pass when all present'],
        ['G3', 'Manufacturability rules match human review 10/10'],
        ['G4', 'Order state machine: 7 traceable QC ledger entries'],
        ['G5', 'FDE configurable industries: jewelry / wood'],
        ['G6', 'Trilingual (zh / en / de) + inquiry CRM loop'],
        ['G7', 'Dual-role co-creation + license matrix + official sample on disk'],
        ['G8', 'tests.py 125 passed, exit=0'],
        ['G9', 'Self-check commands runnable 8/8 (init_check/compliance/demo/tests/verify)'],
        ['G10', 'Synthetic/anonymization marks cover 22/22 data files'],
      ],
      portsTitle: 'Service Ports',
      ports: [
        ['8000', 'Zero-dep HTTP server + Workbench', 'http://<IP>:8000'],
        ['8000/api/health', 'Backend health', 'http://<IP>:8000/api/health'],
        ['8000/media/*', 'Sample video static', 'http://<IP>:8000/media/ai_demo_1080p_voice_neil_bgm_v5.mp4'],
      ],
      colPort: 'Port', colUse: 'Purpose', colHow: 'Access',
    },
    common: { backends: 'Backend', frontend: 'Frontend', database: 'Database', statusOk: 'OK', statusFail: 'FAIL' },
  },

  de: {
    brand: 'ClawHunt #1724',
    chip: 'Zero-Dep-Prototyp · Multi-Tab-Workbench',
    heroTitle: 'KI-Co-Creation + C2M Flexible Customization Platform',
    heroSub: 'Regional Industry KI Enablement Phase 1 · FDE Shared Enterprise KI Service Layer · Full-Pipeline Demo Workbench (Zero-Dep)',
    stackNote: 'Python-Standardbibliothek http.server (ThreadingHTTPServer) · Vanilla JS/CSS (ohne Build) · Keine Drittanbieter-Abhängigkeiten · Offline-fähig · Docker Compose One-Click-Deploy',
    footer: 'Kernlogik in module_a~d, exponiert über Zero-Dep-server.py; Tabs A/B/ops nutzen echte Endpunkte, Interaktions-Demos nur Frontend',
    tabs: { a: 'A Studio', b: 'B Enterprise-KI', c: 'C IP-Studio', d: 'D Wettbewerb', orders: 'Aufträge & Fabrik', contracts: 'Verträge & Regeln', ops: 'Abnahme & Deploy' },
    a: {
      title: 'Co-Creation-Studio · MODUL A', sub: 'Konzeptgenerierung → Autorisierungsprüfung (G2) → Fertigbarkeit',
      conceptTitle: 'Konzeptgenerierungs-Formular (Demo)', conceptHint: 'Branche wählen lädt echte Komponenten und erzeugt eine Demo-Konzeptzusammenfassung',
      material: 'Material', process: 'Verfahren', style: 'Stil', conceptNote: 'Konzeptnotizen',
      industryLabel: 'Zielbranche', placeholderConcept: 'z.B. traditionelles Silberhandwerk mit modernem Minimalismus…',
      generate: 'Konzept generieren', clearing: 'Zurücksetzen', conceptResult: 'Generierte Konzeptzusammenfassung', noIndustry: 'Bitte zuerst Branche wählen',
      conceptLine: 'KI-Co-Creation-Konzept für "{industry}": {style} × {material}, Kernverfahren {process}; Komponenten wiederverwenden und vor dem Musterbau Autorisierungsprüfung bestehen.',
      authTitle: 'Strenge Autorisierungsprüfung (G2 · Ablehnung bei fehlendem Feld)',
      authDesc: 'Simuliert Backend-Strengprüfung: Lizenznehmer / Typ / Region / Laufzeit / Umfang / Anteil sind Pflichtfelder; fehlt eines → Ablehnung (nur 6/6 besteht).',
      authFields: { holder: 'Lizenznehmer', type: 'Lizenztyp', region: 'Region', term: 'Laufzeit', scope: 'Nutzungsumfang', ratio: 'Lizenzanteil' },
      authPlaceholders: { holder: 'z.B. XX Werkstätten GmbH', type: 'z.B. Exklusiv', region: 'z.B. Festlandchina', term: 'z.B. 2026-01-01 ~ 2026-12-31', scope: 'z.B. E-Commerce', ratio: 'z.B. 30%' },
      runAuth: 'Strenge Prüfung ausführen', authPass: 'BESTANDEN · Autorisierung gültig', authReject: 'ABGELEHNT · Felder fehlen',
      missingList: 'Fehlende Felder', allPass: 'Alle 6 Felder vorhanden',
      manufactTitle: 'Fertigbarkeitsbewertung', manufactHint: 'Basiert auf echter Komponentenliste von /api/components/{industry}',
      manufactDecision: 'Urteil', manufactReady: 'Fertigbar · Komponenten bereit', manufactBlock: 'Blockiert · Komponenten unzureichend', compLabel: 'Verfügbare Komponenten',
    },
    b: {
      title: 'Enterprise-KI-Service-Schicht · MODUL B (FDE)', sub: 'Sechs-Branchen-Dienste · Branchenwechsel (Echte API) · Overseas-Inquiry-Loop',
      industryTitle: 'Branchen- & Komponentenwechsel (Echte API)', industryHint: 'GET /api/industries → GET /api/components/{industry}',
      currentIndustry: 'Aktuelle Branche', switchTo: 'Zu dieser Branche wechseln', loading: 'Laden…', noData: 'Keine Daten',
      compTitle: 'Branchenkomponenten',
      inquiryTitle: 'Anfrageformular (Demo)', inquiryHint: 'Noch kein Anfrage-Endpunkt; lokaler Demo-Loop',
      inqCompany: 'Unternehmen', inqContact: 'Kontakt', inqCountry: 'Zielmarkt', inqLang: 'Sprache',
      inqMsg: 'Anforderung', submitInquiry: 'Anfrage senden', inquiryOk: 'Anfrage erfasst',
      inquiries: 'Anfrage-Ledger (CRM-Demo)', emptyInquiries: 'Noch keine Anfragen',
      countries: ['Festlandchina', 'Europa', 'Nordamerika', 'Südostasien', 'Naher Osten'],
      languages: ['中文', 'English', 'Deutsch'],
    },
    c: {
      title: 'IP-Studio · MODUL C', sub: 'Designer × Handwerker Co-Creation · Lizenzmatrix · Muster-Eingang (Publish behält offizielles Muster; private Assets entfernt)',
      roleTitle: 'Zwei-Rollen-Co-Creation',
      roles: [
        { k: 'designer', n: 'Designer', d: 'Konzept / visuelle Assets / IP-Design, registriert Assets' },
        { k: 'craftsman', n: 'Handwerker', d: 'Verfahrensumsetzung / Musterbau / QC-Feedback, iteriert mit Designer' },
      ],
      matrixTitle: 'Lizenzmatrix (Demo-Regeln)', matrixHint: 'Publish-Version versteckt echte Lizenzdaten; Demo-Struktur',
      matrixHead: ['Asset', 'Exklusiv', 'Nicht-exklusiv', 'Region', 'Anteil'],
      matrixRows: [
        ['IP-Visual-Identität', '√', '—', 'Festlandchina', '30%'],
        ['Verfahrensparameter', '√', '√', 'Global', '25%'],
        ['Kurzvideo-Muster', '—', '√', 'Ausgewählte Kanäle', '20%'],
      ],
      sampleTitle: 'Muster-Eingang',
      sampleHint: 'Offizielles Muster (KI-Stimme / 1080p) bleibt in der Publish-Version für Demo; Zwischenprodukte und private Audios entfernt.',
      sampleAction: 'Muster anfordern (Demo)', sampleModalTitle: 'Muster-Vorschau (Demo)',
      sampleMain: 'Offizielles Muster (KI-Stimme, 1080p)', sampleLoading: 'Laden…', sampleReady: 'Abspielbar',
      sampleHidden: 'Demo-Muster gemäß Anti-Free-Ride-Vereinbarung verborgen; nach Zuschlag geliefert', sampleClose: 'Schließen',
    },
    d: {
      title: 'Design-Co-Creation-Wettbewerb · MODUL D', sub: 'Drei-Track-Anmeldung (Demo) · Smart-Review-Gate · KPI-Board',
      trackTitle: 'Drei Tracks',
      tracks: [
        { k: 'craft', n: 'Handwerksinnovation', d: 'Material × Verfahren × Tradition neu' },
        { k: 'ip', n: 'IP-Derivat', d: 'Kulturelles IP × kommerzielles Design' },
        { k: 'combo', n: 'Branchenübergreifend', d: 'Multi-Industrie C2M Customization' },
      ],
      regTitle: 'Wettbewerbsanmeldung (Demo)', regName: 'Team / Person', regTrack: 'Track', regCity: 'Region', regDesc: 'Werkbeschreibung',
      submitReg: 'Anmeldung senden', regOk: 'Anmeldung eingegangen (Demo)', entries: 'Anmeldungs-Ledger', emptyEntries: 'Keine Anmeldungen',
      gateTitle: 'Musterbau-Gate (Demo-Regeln)',
      gateRules: ['Anmelden → Eignung → KI-Review-Scoring → Muster-Ressourcen nach Bestehen', 'Publish-Version versteckt das echte Review-Modell; Gate-Regeln sind Demo'],
    },
    orders: {
      title: 'Aufträge & Fabrik', sub: 'Auftragserstellung (Demo) · Auftrags-Zustandsmaschine G4 Ledger (visualisiert)',
      createTitle: 'Auftragserstellungs-Formular (Demo)', createHint: 'Noch kein Auftrags-Endpunkt; lokale Demo erzeugt Aufträge und treibt die Zustandsmaschine',
      ordProduct: 'Produkt', ordQty: 'Menge', ordBatch: 'Charge', ordDeadline: 'Liefertermin',
      ordPlaceholders: { product: 'z.B. Silber C2M Halskette', qty: 'z.B. 200', batch: 'z.B. B-2026-003', deadline: 'z.B. 2026-12-01' },
      createOrder: 'Auftrag erstellen', orders: 'Auftragsliste', emptyOrders: 'Keine Aufträge', status: 'Status',
      stepperTitle: 'Auftrags-Zustandsmaschine (G4 · Rückverfolgbares Ledger)',
      stepperHint: 'Ereignis-Buttons klicken zum Fortschritt; Ledger zeichnet jeden Schritt mit Zeitstempel',
      trigger: 'Ereignis auslösen', timeline: 'Trace-Ledger', emptyTimeline: 'Noch keine Ereignisse', eventPlaceholder: 'Auftrag wählen',
      evtCreate: 'Erstellen', evtOrder: 'Disponieren', evtProduce: 'Produzieren', evtQc: 'QC', evtPack: 'Verpacken', evtShip: 'Versenden', evtAccept: 'Abnehmen',
      noOrderHint: 'Zuerst oben einen Auftrag erstellen, dann Zustandsmaschine treiben',
    },
    contracts: {
      title: 'Verträge & Regeln', sub: 'Lizenzvertragstypen · Anteilsregeln · Compliance-Kennzeichnung (Demo-Struktur im Publish)',
      typesTitle: 'Lizenzvertragstypen (Demo)',
      types: [
        { n: 'Exklusivlizenz', d: 'Exklusive Nutzung in vereinbarter Region / Kanal, höchster Anteil' },
        { n: 'Nicht-exklusive Lizenz', d: 'Parallele Lizenznehmer, Anteil auf tatsächlichen Umsatz' },
        { n: 'Kundenauftragsvertrag', d: 'C2M Einzelfertigung mit Liefer- und Abnahmeklauseln' },
      ],
      rulesTitle: 'Anteils- & Übergangsregeln (Demo)',
      rules: [
        'Lizenzanteile sind im Publish Platzhalter (null); echte Werte nach Zuschlag bestätigt',
        'Zustandsübergänge: DRAFT→ORDERED→PRODUCING→QC→PACKED→SHIPPED→ACCEPTED',
        'G2-Strengprüfung: fehlt eines der 6 Felder → Ablehnung, um unvollständige Lizenzen zu verhindern',
      ],
      complianceTitle: 'Compliance-Kennzeichnung (G10)',
      complianceHint: '22/22 Datendateien mit Synthetik-/Anonymisierungs-Kennzeichnung; Erklärung im Publish behalten',
    },
    ops: {
      title: 'Abnahme & Deployment', sub: 'G1–G10-Checkliste · Service-Ports · Backend-Health (Echte API)',
      healthTitle: 'Backend-Health', healthOk: 'Online', healthBad: 'Nicht erreichbar', healthChecking: 'Prüfe…',
      healthErrorHint: 'Zuerst python server.py (oder docker compose up -d --build) ausführen, dann diese Seite neu laden',
      verifyTitle: 'G1–G10-Abnahme-Checkliste (VERIFICATION.md)',
      verify: [
        ['G1', 'Vier Flüsse im Kreis: A Co-Creation / B sechs Komponenten / C Zwei-Rollen+Lizenz / D Wettbewerbs-Gate'],
        ['G2', 'Strenge Autorisierung: Ablehnung 6/6 bei fehlendem Feld, Bestehen bei vollständig'],
        ['G3', 'Fertigbarkeitsregeln = manuelle Prüfung 10/10'],
        ['G4', 'Auftrags-Zustandsmaschine: 7 rückverfolgbare QC-Ledger-Einträge'],
        ['G5', 'FDE konfigurierbare Branchen: jewelry / wood'],
        ['G6', 'Dreisprachig (zh / en / de) + Anfrage-CRM-Loop'],
        ['G7', 'Zwei-Rollen-Co-Creation + Lizenzmatrix + offizielles Muster auf Datenträger'],
        ['G8', 'tests.py 125 passed, exit=0'],
        ['G9', 'Selbstprüf-Befehle lauffähig 8/8 (init_check/compliance/demo/tests/verify)'],
        ['G10', 'Synthetik-/Anonymisierungs-Kennzeichnung deckt 22/22 Datendateien'],
      ],
      portsTitle: 'Service-Ports',
      ports: [
        ['8000', 'Zero-Dep-HTTP-Server + Workbench', 'http://<IP>:8000'],
        ['8000/api/health', 'Backend-Health', 'http://<IP>:8000/api/health'],
        ['8000/media/*', 'Muster-Video-Static', 'http://<IP>:8000/media/ai_demo_1080p_voice_neil_bgm_v5.mp4'],
      ],
      colPort: 'Port', colUse: 'Zweck', colHow: 'Zugriff',
    },
    common: { backends: 'Backend', frontend: 'Frontend', database: 'Datenbank', statusOk: 'OK', statusFail: 'FEHLER' },
  },
};

const TABS = [
  { id: 'a', icon: 'A' }, { id: 'b', icon: 'B' }, { id: 'c', icon: 'C' }, { id: 'd', icon: 'D' },
  { id: 'orders', icon: '◈' }, { id: 'contracts', icon: '⚖' }, { id: 'ops', icon: '◉' },
];

const SAMPLE_URL = '/media/ai_demo_1080p_voice_neil_bgm_v5.mp4';

/* ============ 全局状态 ============ */
const state = {
  lang: 'zh',
  tab: 'a',
  industries: [],
  comps: {},          // industry -> components[]
  compsLoading: false,
  compsError: null,
  health: { status: 'checking' },
  inquiries: [],
  entries: [],
  orders: [],         // {id, product, qty, batch, deadline, status, timeline:[]}
  selectedOrderId: null,
};

/* ============ 工具 ============ */
const $ = (sel, root) => (root || document).querySelector(sel);
const el = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html !== undefined) n.innerHTML = html;
  return n;
};
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}
function fmtTime(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
const t = () => I18N[state.lang];
function replaceVars(tpl, vars) {
  return tpl.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined ? vars[k] : m));
}

/* ============ API ============ */
async function apiHealth() {
  try {
    const r = await fetch('/api/health', { cache: 'no-store' });
    state.health = r.ok ? { status: 'ok' } : { status: 'bad' };
  } catch (e) { state.health = { status: 'bad' }; }
}
async function loadIndustries() {
  try {
    const r = await fetch('/api/industries', { cache: 'no-store' });
    const d = await r.json();
    state.industries = (d.industries || []).map(x => x.id);
    if (state.industries.length) {
      await loadComponents(state.industries[0]);
    }
  } catch (e) {
    state.industries = ['jewelry', 'wood'];
    state.compsError = String(e);
  }
}
async function loadComponents(industry) {
  state.compsLoading = true;
  state.compsError = null;
  try {
    const r = await fetch('/api/components/' + encodeURIComponent(industry), { cache: 'no-store' });
    const d = await r.json();
    state.comps[industry] = d.components || [];
    if (d.stub) state.compsError = d.note || 'stub';
  } catch (e) {
    state.comps[industry] = [];
    state.compsError = String(e);
  }
  state.compsLoading = false;
  render();
}

/* ============ 交互动作 ============ */
function switchLang(lang) { state.lang = lang; render(); }
function switchTab(id) { state.tab = id; render(); }

function doConcept() {
  const industry = $('#concept-industry').value;
  if (!industry) { state.concept = null; state.conceptNote = t().a.noIndustry; render(); return; }
  const material = $('#concept-material').value.trim() || '传统材料';
  const process = $('#concept-process').value.trim() || '手工工艺';
  const style = $('#concept-style').value.trim() || '极简风格';
  const note = $('#concept-note').value.trim();
  state.concept = { industry, material, process, style, note };
  state.conceptNote = null;
  render();
}
function clearConcept() {
  state.concept = null; state.conceptNote = null;
  $('#concept-material').value = ''; $('#concept-process').value = '';
  $('#concept-style').value = ''; $('#concept-note').value = '';
}
function runAuth() {
  const keys = ['holder', 'type', 'region', 'term', 'scope', 'ratio'];
  const missing = keys.filter(k => !$('#auth-' + k).value.trim());
  state.authResult = missing.length ? { pass: false, missing } : { pass: true, missing: [] };
  render();
}
function switchIndustry(industry) { loadComponents(industry); }
function submitInquiry() {
  const rec = {
    company: $('#inq-company').value.trim(), contact: $('#inq-contact').value.trim(),
    country: $('#inq-country').value, lang: $('#inq-lang').value, msg: $('#inq-msg').value.trim(),
    at: fmtTime(new Date()),
  };
  if (!rec.company && !rec.msg) return;
  state.inquiries.unshift(rec);
  state.inquiryOk = true;
  render();
}
function submitReg() {
  const rec = {
    name: $('#reg-name').value.trim(), track: $('#reg-track').value,
    city: $('#reg-city').value.trim(), desc: $('#reg-desc').value.trim(), at: fmtTime(new Date()),
  };
  if (!rec.name) return;
  state.entries.unshift(rec);
  state.regOk = true;
  render();
}
function createOrder() {
  const rec = {
    id: 'ORD-' + String(state.orders.length + 1).padStart(3, '0'),
    product: $('#ord-product').value.trim() || 'C2M 定制产品',
    qty: $('#ord-qty').value.trim() || '—',
    batch: $('#ord-batch').value.trim() || '—',
    deadline: $('#ord-deadline').value.trim() || '—',
    status: 'DRAFT',
    timeline: [{ evt: 'DRAFT', at: fmtTime(new Date()) }],
  };
  state.orders.unshift(rec);
  state.selectedOrderId = rec.id;
  render();
}
function selectOrder(id) { state.selectedOrderId = id; render(); }
function fireEvent(evtKey) {
  const order = state.orders.find(o => o.id === state.selectedOrderId);
  if (!order) return;
  const idx = STATUS_FLOW.findIndex(s => s.key === order.status);
  const targetIdx = STATUS_FLOW.findIndex(s => s.key === evtKey);
  if (targetIdx < 0) return;
  if (targetIdx > idx) {
    order.status = evtKey;
  }
  order.timeline.push({ evt: evtKey, at: fmtTime(new Date()) });
  render();
}

/* ============ 渲染 ============ */
function render() {
  const L = t();
  const app = $('#app');
  app.innerHTML = '';

  app.appendChild(el('div', 'grid-bg'));
  const wrap = el('div', 'wrap');
  app.appendChild(wrap);

  /* ---- Header ---- */
  const hero = el('div', 'hero');
  hero.appendChild(el('div', 'brand-row',
    `<span class="brand">${esc(L.brand)}</span><span class="chip">${esc(L.chip)}</span>`));
  hero.appendChild(el('h1', '', esc(L.heroTitle)));
  hero.appendChild(el('p', 'sub', esc(L.heroSub)));
  hero.appendChild(el('div', 'stack', esc(L.stackNote)));
  wrap.appendChild(hero);

  const langbar = el('div', 'langbar');
  ['zh', 'en', 'de'].forEach(lng => {
    const b = el('button', 'lang-btn' + (state.lang === lng ? ' active' : ''), lng.toUpperCase());
    b.onclick = () => switchLang(lng);
    langbar.appendChild(b);
  });
  wrap.appendChild(langbar);

  /* ---- Tab nav ---- */
  const nav = el('nav', 'tabnav');
  TABS.forEach(tb => {
    const b = el('button', state.tab === tb.id ? 'active' : '',
      `<span class="tab-icon">${tb.icon}</span>${esc(L.tabs[tb.id])}`);
    b.onclick = () => switchTab(tb.id);
    nav.appendChild(b);
  });
  wrap.appendChild(nav);

  /* ---- Panel ---- */
  const panel = el('div', 'tab-panel');
  panel.appendChild(renderTab());
  wrap.appendChild(panel);

  /* ---- Footer ---- */
  const footer = el('footer', 'footer');
  footer.appendChild(el('div', '', esc(L.footer)));
  const api = el('div', 'api-status');
  const h = state.health.status;
  const dot = h === 'ok' ? 'dot-ok' : (h === 'bad' ? 'dot-bad' : 'dot-wait');
  api.innerHTML = `<span class="status-line"><span class="dot ${dot}"></span> /api/health · ` +
    (h === 'ok' ? `<span style="color:var(--ok)">${esc(L.ops.healthOk)}</span>` :
      h === 'bad' ? `<span style="color:var(--danger)">${esc(L.ops.healthBad)}</span>` : esc(L.ops.healthChecking)) +
    ` · /api/industries · /api/components/{industry}</span>`;
  footer.appendChild(api);
  wrap.appendChild(footer);

  bindEvents();
}

/* ---------- 页签渲染 ---------- */
function renderTab() {
  const L = t();
  switch (state.tab) {
    case 'a': return tabA(L);
    case 'b': return tabB(L);
    case 'c': return tabC(L);
    case 'd': return tabD(L);
    case 'orders': return tabOrders(L);
    case 'contracts': return tabContracts(L);
    case 'ops': return tabOps(L);
    default: return el('div', '', '');
  }
}

function fieldHtml(label, id, placeholder, type = 'input') {
  if (type === 'select') return `<label class="field"><span class="field-label">${esc(label)}</span><select id="${id}">${placeholder}</select></label>`;
  if (type === 'textarea') return `<label class="field"><span class="field-label">${esc(label)}</span><textarea id="${id}" rows="2" placeholder="${esc(placeholder)}"></textarea></label>`;
  return `<label class="field"><span class="field-label">${esc(label)}</span><input id="${id}" placeholder="${esc(placeholder)}" /></label>`;
}

function tabA(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.a.title)}</h2><p class="panel-sub">${esc(L.a.sub)}</p>`));
  const g = el('div', 'grid-2');

  /* 概念生成 */
  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.a.conceptTitle)));
  card1.appendChild(el('p', 'hint', esc(L.a.conceptHint)));
  const opts = state.industries.map(i => `<option value="${esc(i)}"${!state.industries.length || i === state.industries[0] ? ' selected' : ''}>${esc(i)}</option>`).join('');
  card1.appendChild(fieldHtml(L.a.industryLabel, 'concept-industry', opts, 'select'));
  const g3 = el('div', 'grid-3');
  g3.innerHTML = fieldHtml(L.a.material, 'concept-material', '') + fieldHtml(L.a.process, 'concept-process', '') + fieldHtml(L.a.style, 'concept-style', '');
  card1.appendChild(g3);
  card1.appendChild(fieldHtml(L.a.conceptNote, 'concept-note', L.a.placeholderConcept, 'textarea'));
  const br1 = el('div', 'btn-row');
  const btn1 = el('button', 'btn btn-primary', esc(L.a.generate)); btn1.onclick = doConcept;
  const btn2 = el('button', 'btn', esc(L.a.clearing)); btn2.onclick = clearConcept;
  br1.appendChild(btn1); br1.appendChild(btn2);
  card1.appendChild(br1);
  if (state.conceptNote) card1.appendChild(el('p', 'hint', `<span style="color:var(--warn)">${esc(state.conceptNote)}</span>`));
  if (state.concept) {
    card1.appendChild(el('div', 'card-title', esc(L.a.conceptResult)));
    card1.appendChild(el('p', '', esc(replaceVars(L.a.conceptLine, state.concept))));
  }
  g.appendChild(card1);

  /* 授权强校验 G2 */
  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.a.authTitle)));
  card2.appendChild(el('p', 'hint', esc(L.a.authDesc)));
  const fields = ['holder', 'type', 'region', 'term', 'scope', 'ratio'];
  const g3b = el('div', 'grid-3');
  g3b.innerHTML = fields.map(k => fieldHtml(L.a.authFields[k], 'auth-' + k, L.a.authPlaceholders[k])).join('');
  card2.appendChild(g3b);
  const br2 = el('div', 'btn-row');
  const btnAuth = el('button', 'btn btn-primary', esc(L.a.runAuth)); btnAuth.onclick = runAuth;
  br2.appendChild(btnAuth);
  card2.appendChild(br2);
  if (state.authResult) {
    if (state.authResult.pass) {
      card2.appendChild(el('p', 'status-line', `<span class="dot dot-ok"></span><span style="color:var(--ok)">${esc(L.a.authPass)}</span> · ${esc(L.a.allPass)}`));
    } else {
      card2.appendChild(el('p', 'status-line', `<span class="dot dot-bad"></span><span style="color:var(--danger)">${esc(L.a.authReject)}</span>`));
      card2.appendChild(el('div', 'hint', `${esc(L.a.missingList)}: ${state.authResult.missing.map(k => esc(L.a.authFields[k])).join(' / ')}`));
    }
  }
  g.appendChild(card2);

  /* 可制造性 */
  const card3 = el('section', 'card');
  card3.appendChild(el('div', 'card-title', esc(L.a.manufactTitle)));
  card3.appendChild(el('p', 'hint', esc(L.a.manufactHint)));
  const cur = $('#concept-industry') ? $('#concept-industry').value : (state.industries[0] || '');
  const compsHere = (state.comps[cur] || []);
  const ready = compsHere.length >= 3;
  card3.appendChild(el('div', 'status-line', ready
    ? `<span class="dot dot-ok"></span><span style="color:var(--ok)">${esc(L.a.manufactReady)}</span>`
    : `<span class="dot dot-bad"></span><span style="color:var(--danger)">${esc(L.a.manufactBlock)}</span>`));
  card3.appendChild(el('p', 'hint', `${esc(L.a.compLabel)}（${cur || '—'}）：${compsHere.length}`));
  if (compsHere.length) {
    const ul = el('ul', '');
    compsHere.forEach(c => ul.appendChild(el('li', '', `${esc(c.name)} · ${esc(c.description)}`)));
    card3.appendChild(ul);
  }
  g.appendChild(card3);

  panel.appendChild(g);
  return panel;
}

function tabB(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.b.title)}</h2><p class="panel-sub">${esc(L.b.sub)}</p>`));
  const g = el('div', 'grid-2');

  /* 行业组件切换 */
  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.b.industryTitle)));
  card1.appendChild(el('p', 'hint', esc(L.b.industryHint)));
  const optHtml = state.industries.map(i => `<option value="${esc(i)}">${esc(i)}</option>`).join('');
  card1.appendChild(fieldHtml(L.b.currentIndustry, 'b-industry', optHtml, 'select'));
  const br = el('div', 'btn-row');
  const btn = el('button', 'btn btn-primary', esc(L.b.switchTo));
  btn.onclick = () => switchIndustry($('#b-industry').value);
  br.appendChild(btn);
  card1.appendChild(br);
  if (state.compsError) card1.appendChild(el('p', 'hint', `<span style="color:var(--warn)">${esc(state.compsError)}</span>`));
  card1.appendChild(el('div', 'card-title', esc(L.b.compTitle)));
  if (state.compsLoading) {
    card1.appendChild(el('p', 'hint', esc(L.b.loading)));
  } else {
    const curId = $('#b-industry') ? $('#b-industry').value : (state.industries[0] || '');
    const comps = state.comps[curId] || [];
    if (!comps.length) {
      card1.appendChild(el('p', 'hint', esc(L.b.noData)));
    } else {
      const table = el('table', '');
      table.innerHTML = `<thead><tr><th>${esc(L.b.compTitle)}</th><th>${esc(L.b.compTitle)}</th><th>${esc(L.b.compTitle)}</th></tr></thead>`;
      table.innerHTML = '<thead><tr><th>ID</th><th>Name</th><th>Capabilities</th></tr></thead><tbody>' +
        comps.map(c => `<tr><td>${esc(c.component_id)}</td><td>${esc(c.name)}<br/><span style="color:var(--muted);font-size:12px">${esc(c.description)}</span></td><td style="font-size:12px">${esc((c.capabilities || []).join(', '))}</td></tr>`).join('') + '</tbody>';
      card1.appendChild(table);
    }
  }
  g.appendChild(card1);

  /* 询盘 CRM 演示 */
  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.b.inquiryTitle)));
  card2.appendChild(el('p', 'hint', esc(L.b.inquiryHint)));
  card2.appendChild(fieldHtml(L.b.inqCompany, 'inq-company', ''));
  card2.appendChild(fieldHtml(L.b.inqContact, 'inq-contact', ''));
  card2.appendChild(fieldHtml(L.b.inqCountry, 'inq-country', L.b.countries.map(c => `<option>${esc(c)}</option>`).join(''), 'select'));
  card2.appendChild(fieldHtml(L.b.inqLang, 'inq-lang', L.b.languages.map(c => `<option>${esc(c)}</option>`).join(''), 'select'));
  card2.appendChild(fieldHtml(L.b.inqMsg, 'inq-msg', '', 'textarea'));
  const br2 = el('div', 'btn-row');
  const b2 = el('button', 'btn btn-primary', esc(L.b.submitInquiry)); b2.onclick = submitInquiry;
  br2.appendChild(b2);
  card2.appendChild(br2);
  if (state.inquiryOk) card2.appendChild(el('p', 'hint', `<span style="color:var(--ok)">${esc(L.b.inquiryOk)}</span>`));
  card2.appendChild(el('div', 'card-title', esc(L.b.inquiries)));
  if (!state.inquiries.length) {
    card2.appendChild(el('p', 'hint', esc(L.b.emptyInquiries)));
  } else {
    const ul = el('ul', 'timeline');
    state.inquiries.forEach(r => ul.appendChild(el('li', '', `<span class="ts">${esc(r.at)}</span>${esc(r.company || r.contact)} · ${esc(r.country)} · ${esc(r.lang)} · ${esc(r.msg)}`)));
    card2.appendChild(ul);
  }
  g.appendChild(card2);

  panel.appendChild(g);
  return panel;
}

function tabC(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.c.title)}</h2><p class="panel-sub">${esc(L.c.sub)}</p>`));
  const g = el('div', 'grid-2');

  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.c.roleTitle)));
  const roles = el('div', 'grid-2');
  L.c.roles.forEach(r => {
    const c = el('div', 'card', `<b>${esc(r.n)}</b><p class="hint" style="margin-top:6px">${esc(r.d)}</p>`);
    c.style.marginBottom = '0';
    roles.appendChild(c);
  });
  card1.appendChild(roles);
  card1.appendChild(el('div', 'card-title', esc(L.c.matrixTitle)));
  card1.appendChild(el('p', 'hint', esc(L.c.matrixHint)));
  const table = el('table', '');
  table.innerHTML = '<thead><tr>' + L.c.matrixHead.map(h => `<th>${esc(h)}</th>`).join('') + '</tr></thead><tbody>' +
    L.c.matrixRows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('') + '</tbody>';
  card1.appendChild(table);
  g.appendChild(card1);

  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.c.sampleTitle)));
  card2.appendChild(el('p', 'hint', esc(L.c.sampleHint)));
  const br = el('div', 'btn-row');
  const btn = el('button', 'btn btn-primary', esc(L.c.sampleAction));
  btn.onclick = openSampleModal;
  br.appendChild(btn);
  card2.appendChild(br);
  g.appendChild(card2);

  panel.appendChild(g);
  return panel;
}

function tabD(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.d.title)}</h2><p class="panel-sub">${esc(L.d.sub)}</p>`));
  const g = el('div', 'grid-2');

  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.d.trackTitle)));
  const tracks = el('div', 'grid-3');
  L.d.tracks.forEach(tr => {
    const c = el('div', 'card', `<b>${esc(tr.n)}</b><p class="hint" style="margin-top:6px">${esc(tr.d)}</p>`);
    c.style.marginBottom = '0';
    tracks.appendChild(c);
  });
  card1.appendChild(tracks);
  card1.appendChild(el('div', 'card-title', esc(L.d.gateTitle)));
  const ul = el('ul', '');
  L.d.gateRules.forEach(r => ul.appendChild(el('li', '', esc(r))));
  card1.appendChild(ul);
  g.appendChild(card1);

  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.d.regTitle)));
  card2.appendChild(fieldHtml(L.d.regName, 'reg-name', ''));
  card2.appendChild(fieldHtml(L.d.regTrack, 'reg-track', L.d.tracks.map(x => `<option>${esc(x.n)}</option>`).join(''), 'select'));
  card2.appendChild(fieldHtml(L.d.regCity, 'reg-city', ''));
  card2.appendChild(fieldHtml(L.d.regDesc, 'reg-desc', '', 'textarea'));
  const br = el('div', 'btn-row');
  const b = el('button', 'btn btn-primary', esc(L.d.submitReg)); b.onclick = submitReg;
  br.appendChild(b);
  card2.appendChild(br);
  if (state.regOk) card2.appendChild(el('p', 'hint', `<span style="color:var(--ok)">${esc(L.d.regOk)}</span>`));
  card2.appendChild(el('div', 'card-title', esc(L.d.entries)));
  if (!state.entries.length) {
    card2.appendChild(el('p', 'hint', esc(L.d.emptyEntries)));
  } else {
    const ul2 = el('ul', 'timeline');
    state.entries.forEach(r => ul2.appendChild(el('li', '', `<span class="ts">${esc(r.at)}</span>${esc(r.name)} · ${esc(r.track)} · ${esc(r.city)}`)));
    card2.appendChild(ul2);
  }
  g.appendChild(card2);

  panel.appendChild(g);
  return panel;
}

function tabOrders(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.orders.title)}</h2><p class="panel-sub">${esc(L.orders.sub)}</p>`));
  const g = el('div', 'grid-2');

  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.orders.createTitle)));
  card1.appendChild(el('p', 'hint', esc(L.orders.createHint)));
  card1.appendChild(fieldHtml(L.orders.ordProduct, 'ord-product', L.orders.ordPlaceholders.product));
  const g3 = el('div', 'grid-3');
  g3.innerHTML = fieldHtml(L.orders.ordQty, 'ord-qty', L.orders.ordPlaceholders.qty) +
    fieldHtml(L.orders.ordBatch, 'ord-batch', L.orders.ordPlaceholders.batch) +
    fieldHtml(L.orders.ordDeadline, 'ord-deadline', L.orders.ordPlaceholders.deadline);
  card1.appendChild(g3);
  const br = el('div', 'btn-row');
  const b = el('button', 'btn btn-primary', esc(L.orders.createOrder)); b.onclick = createOrder;
  br.appendChild(b);
  card1.appendChild(br);
  card1.appendChild(el('div', 'card-title', esc(L.orders.orders)));
  if (!state.orders.length) {
    card1.appendChild(el('p', 'hint', esc(L.orders.emptyOrders)));
  } else {
    const list = el('div', '');
    state.orders.forEach(o => {
      const item = el('div', 'status-line', `<span class="dot ${o.status === 'ACCEPTED' ? 'dot-ok' : 'dot-wait'}"></span>` +
        `<b>${esc(o.id)}</b> ${esc(o.product)} · ${esc(o.qty)} · ${esc(o.batch)} · ${esc(o.deadline)} ` +
        `<span class="badge badge-${o.status === 'ACCEPTED' ? 'ok' : 'mut'}">${esc(o.status)}</span>`);
      item.style.cursor = 'pointer';
      item.style.padding = '6px 0';
      item.onclick = () => selectOrder(o.id);
      list.appendChild(item);
    });
    card1.appendChild(list);
  }
  g.appendChild(card1);

  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.orders.stepperTitle)));
  card2.appendChild(el('p', 'hint', esc(L.orders.stepperHint)));
  const curOrder = state.orders.find(o => o.id === state.selectedOrderId);
  if (!curOrder) {
    card2.appendChild(el('p', 'hint', esc(L.orders.noOrderHint)));
  } else {
    /* stepper */
    const step = el('div', 'stepper');
    STATUS_FLOW.forEach((s, i) => {
      const active = STATUS_FLOW.findIndex(x => x.key === curOrder.status) >= i;
      step.appendChild(el('div', 'step' + (active ? ' active' : ''),
        `<span class="step-dot">${i + 1}</span><span class="step-label">${esc(s[state.lang])}</span>`));
      if (i < STATUS_FLOW.length - 1) step.appendChild(el('span', 'step-arrow', '→'));
    });
    card2.appendChild(step);

    const events = ['ORDERED', 'PRODUCING', 'QC', 'PACKED', 'SHIPPED', 'ACCEPTED'];
    const br2 = el('div', 'btn-row');
    events.forEach(ev => {
      const b2 = el('button', 'btn btn-sm', esc(L.orders['evt' + ev.charAt(0) + ev.slice(1).toLowerCase()] || ev));
      b2.onclick = () => fireEvent(ev);
      br2.appendChild(b2);
    });
    card2.appendChild(br2);

    card2.appendChild(el('div', 'card-title', esc(L.orders.timeline)));
    const tl = el('ul', 'timeline');
    curOrder.timeline.forEach(e => tl.appendChild(el('li', '', `<span class="ts">${esc(e.at)}</span><b>${esc(e.evt)}</b>`)));
    card2.appendChild(tl);
  }
  g.appendChild(card2);

  panel.appendChild(g);
  return panel;
}

function tabContracts(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.contracts.title)}</h2><p class="panel-sub">${esc(L.contracts.sub)}</p>`));
  const g = el('div', 'grid-2');

  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.contracts.typesTitle)));
  L.contracts.types.forEach(ty => {
    card1.appendChild(el('div', 'card', `<b>${esc(ty.n)}</b><p class="hint" style="margin-top:6px">${esc(ty.d)}</p>`));
  });
  g.appendChild(card1);

  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.contracts.rulesTitle)));
  const ul = el('ul', '');
  L.contracts.rules.forEach(r => ul.appendChild(el('li', '', esc(r))));
  card2.appendChild(ul);
  card2.appendChild(el('div', 'card-title', esc(L.contracts.complianceTitle)));
  card2.appendChild(el('p', 'hint', esc(L.contracts.complianceHint)));
  g.appendChild(card2);

  panel.appendChild(g);
  return panel;
}

function tabOps(L) {
  const panel = el('div', '');
  panel.appendChild(el('div', 'panel-head',
    `<h2>${esc(L.ops.title)}</h2><p class="panel-sub">${esc(L.ops.sub)}</p>`));
  const g = el('div', 'grid-2');

  const card1 = el('section', 'card');
  card1.appendChild(el('div', 'card-title', esc(L.ops.healthTitle)));
  const h = state.health.status;
  card1.appendChild(el('div', 'status-line',
    h === 'ok' ? `<span class="dot dot-ok"></span><span style="color:var(--ok)">${esc(L.ops.healthOk)}</span>` :
      h === 'bad' ? `<span class="dot dot-bad"></span><span style="color:var(--danger)">${esc(L.ops.healthBad)}</span>` :
        `<span class="dot dot-wait"></span>${esc(L.ops.healthChecking)}`));
  card1.appendChild(el('p', 'hint', esc(L.ops.healthErrorHint)));
  card1.appendChild(el('div', 'card-title', esc(L.ops.portsTitle)));
  const table = el('table', '');
  table.innerHTML = `<thead><tr><th>${esc(L.ops.colPort)}</th><th>${esc(L.ops.colUse)}</th><th>${esc(L.ops.colHow)}</th></tr></thead><tbody>` +
    L.ops.ports.map(p => `<tr><td>${esc(p[0])}</td><td>${esc(p[1])}</td><td style="color:var(--accent)">${esc(p[2])}</td></tr>`).join('') + '</tbody>';
  card1.appendChild(table);
  g.appendChild(card1);

  const card2 = el('section', 'card');
  card2.appendChild(el('div', 'card-title', esc(L.ops.verifyTitle)));
  const table2 = el('table', '');
  table2.innerHTML = '<thead><tr><th>ID</th><th>Checklist</th></tr></thead><tbody>' +
    L.ops.verify.map(v => `<tr><td><span class="badge badge-ok">${esc(v[0])}</span></td><td>${esc(v[1])}</td></tr>`).join('') + '</tbody>';
  card2.appendChild(table2);
  g.appendChild(card2);

  panel.appendChild(g);
  return panel;
}

/* ============ 样片弹窗 ============ */
function openSampleModal() {
  const L = t();
  const mask = el('div', 'modal-mask');
  const modal = el('div', 'modal');
  const head = el('div', 'modal-head');
  head.appendChild(el('span', 'modal-title', esc(L.c.sampleModalTitle)));
  const close = el('button', 'modal-close', '×');
  close.onclick = () => mask.remove();
  head.appendChild(close);
  modal.appendChild(head);
  modal.appendChild(el('p', 'hint', esc(L.c.sampleMain) + ' · ' + esc(SAMPLE_URL)));
  const video = el('video', '', '');
  video.controls = true;
  video.preload = 'metadata';
  video.src = SAMPLE_URL;
  const hiddenBox = el('div', 'sample-hidden', esc(L.c.sampleHidden));
  hiddenBox.style.display = 'none';
  let failed = false;
  video.addEventListener('error', () => {
    if (!failed) {
      failed = true;
      video.style.display = 'none';
      hiddenBox.style.display = 'block';
    }
  });
  video.addEventListener('canplay', () => {
    if (!failed) {
      failed = true; // 播放成功后不再显示占位
      hiddenBox.style.display = 'none';
    }
  });
  modal.appendChild(video);
  modal.appendChild(hiddenBox);
  const foot = el('div', 'btn-row');
  const bClose = el('button', 'btn', esc(L.c.sampleClose));
  bClose.onclick = () => mask.remove();
  foot.appendChild(bClose);
  modal.appendChild(foot);
  mask.appendChild(modal);
  mask.onclick = e => { if (e.target === mask) mask.remove(); };
  document.body.appendChild(mask);
}

/* ============ 事件绑定（渲染后） ============ */
function bindEvents() {
  if ($('#concept-industry')) {
    $('#concept-industry').onchange = () => {
      const ind = $('#concept-industry').value;
      if (!state.comps[ind]) loadComponents(ind);
    };
  }
  if ($('#b-industry')) {
    $('#b-industry').onchange = () => {
      const ind = $('#b-industry').value;
      if (!state.comps[ind]) loadComponents(ind);
    };
  }
}

/* ============ 启动 ============ */
(async function init() {
  render();
  apiHealth().then(render);
  await loadIndustries();
})();
