"""ClawHunt #1724 交付仓库 —— 三平台统一入口（跨平台，纯标准库）。

一键完成：环境检查 -> 初始化自检 -> 合规检查 -> 演示/测试/验证全量复跑 -> 汇总。

用法：
    python start.py              # 全流程
    python start.py --skip-check # 跳过 init/compliance 检查直接复跑
退出码：0=全部通过，1=存在失败项。
"""
import argparse
import json
import os
import subprocess
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))


def _run_py(script, args=None):
    cmd = [sys.executable, os.path.join(_ROOT, script)]
    if args:
        cmd.extend(args)
    proc = subprocess.run(cmd, cwd=_ROOT, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    tail = (proc.stdout or "").strip().splitlines()
    return proc.returncode, tail[-6:] if tail else []


def main():
    parser = argparse.ArgumentParser(description="ClawHunt #1724 一键运行统一入口")
    parser.add_argument("--skip-check", action="store_true",
                        help="跳过初始化/合规检查，仅复跑 demo/tests/verify")
    args = parser.parse_args()

    summary = {
        "tool": "start.py",
        "python_version": "{}.{}.{}".format(*sys.version_info[:3]),
        "steps": [],
    }
    all_ok = True

    if not args.skip_check:
        for script, label in (("scripts/init_check.py", "初始化自检"),
                              ("scripts/compliance_check.py", "合规检查")):
            code, tail = _run_py(script)
            summary["steps"].append({"step": label, "ok": code == 0,
                                     "tail": tail})
            all_ok = all_ok and code == 0

    for script, label in (("demo.py", "演示 demo"),
                          ("tests.py", "单元测试 tests"),
                          ("verify.py", "全量验证 verify")):
        code, tail = _run_py(script)
        summary["steps"].append({"step": label, "ok": code == 0, "tail": tail})
        all_ok = all_ok and code == 0

    summary["all_green"] = all_ok
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
