#!/usr/bin/env bash
# ClawHunt #1724 · 零依赖版 · Linux 一键部署脚本（Debian/Ubuntu/CentOS/Fedora 等通用）
# 用法: sudo bash deploy/install_linux.sh
# 幂等：已安装项显示 [SKIP]，可重复执行。
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
OK()  { echo -e "${GREEN}[OK]${NC}   $1"; }
SKIP(){ echo -e "${YELLOW}[SKIP]${NC} $1"; }
FAIL(){ echo -e "${RED}[FAIL]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_DIR="$SCRIPT_DIR"

# 需要 root 权限执行（缺失组件时安装）
if [ "$(id -u)" -ne 0 ]; then
  echo "提示：检测到非 root 执行，缺失组件时将尝试 sudo 安装。"
  SUDO="sudo"
else
  SUDO=""
fi

echo "================================================================"
echo " ClawHunt #1724 · 零依赖版一键部署（Linux）"
echo " 目录: $COMPOSE_DIR"
echo "================================================================"

# ---------- 1) docker（get.docker.com 自动识别 Debian/Ubuntu/CentOS/Fedora/RHEL 等） ----------
if command -v docker >/dev/null 2>&1; then
  OK "docker 已安装: $(docker --version)"
else
  echo "docker 未安装，开始安装（get.docker.com）..."
  $SUDO bash -c 'curl -fsSL https://get.docker.com | sh'
  $SUDO systemctl enable --now docker || true
  if command -v docker >/dev/null 2>&1; then
    OK "docker 安装完成: $(docker --version)"
  else
    FAIL "docker 安装失败，请手动安装后重试"
    exit 1
  fi
fi

# ---------- 2) docker compose 插件 ----------
if docker compose version >/dev/null 2>&1; then
  OK "docker compose 插件已安装: $(docker compose version --short 2>/dev/null || docker compose version)"
else
  echo "docker compose 插件未安装，开始安装（官方二进制）..."
  $SUDO mkdir -p /usr/local/lib/docker/cli-plugins
  $SUDO curl -SL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m)" \
    -o /usr/local/lib/docker/cli-plugins/docker-compose
  $SUDO chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
  if docker compose version >/dev/null 2>&1; then
    OK "docker compose 插件安装完成"
  else
    FAIL "docker compose 插件安装失败，请手动安装后重试"
    exit 1
  fi
fi

# ---------- 3) python3（零依赖版容器运行不需要宿主机 python，仅提示） ----------
if command -v python3 >/dev/null 2>&1; then
  OK "python3 已安装: $(python3 --version 2>&1)"
else
  SKIP "宿主机未安装 python3（容器内自带 python:3.11-slim，不影响部署；如需本地跑 server.py 请另行安装）"
fi

# ---------- 4) docker 组检查与 sudo 回退 ----------
if ! docker info >/dev/null 2>&1; then
  if [ -S /var/run/docker.sock ] && [ -n "$SUDO" ]; then
    echo "当前用户不在 docker 组，尝试 sudo 执行 docker compose..."
    COMPOSE_CMD=("$SUDO" docker compose)
  else
    FAIL "docker 守护进程不可用，请检查服务状态（sudo systemctl status docker）"
    exit 1
  fi
else
  COMPOSE_CMD=(docker compose)
  if [ -z "$SUDO" ] && ! id -nG | tr ' ' '\n' | grep -qx docker; then
    SKIP "当前用户不在 docker 组（可选：sudo usermod -aG docker \$USER 后重新登录）"
  fi
fi

# ---------- 5) 启动服务 ----------
cd "$COMPOSE_DIR"
echo "开始构建并启动零依赖服务（端口 8000）..."
if "${COMPOSE_CMD[@]}" up -d --build; then
  OK "docker compose up -d --build 完成"
else
  FAIL "docker compose 启动失败，请检查上方日志"
  exit 1
fi

sleep 2
if "${COMPOSE_CMD[@]}" ps; then
  OK "服务状态如上（容器名 clawhunt1724_zero_dep）"
fi

echo "--------------------------------------------------------------"
echo " 部署完成："
echo "   Web 工作台:  http://<服务器IP>:8000/"
echo "   健康检查:    http://<服务器IP>:8000/api/health"
echo "   行业接口:    http://<服务器IP>:8000/api/industries"
echo "   组件接口:    http://<服务器IP>:8000/api/components/jewelry"
echo "   样片视频:    http://<服务器IP>:8000/media/ai_demo_1080p_voice_neil_bgm_v5.mp4"
echo " 常用命令："
echo "   日志:  ${COMPOSE_CMD[@]} logs -f app"
echo "   停止:  ${COMPOSE_CMD[@]} down"
echo "   重启:  ${COMPOSE_CMD[@]} restart app"
echo "--------------------------------------------------------------"
