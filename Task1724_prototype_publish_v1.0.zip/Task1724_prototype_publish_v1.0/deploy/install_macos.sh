#!/usr/bin/env bash
# ClawHunt #1724 · 零依赖版 · macOS 一键部署脚本
# 用法: bash deploy/install_macos.sh
# 幂等：已安装项显示 [OK] / [SKIP]，可重复执行。
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
OK()  { echo -e "${GREEN}[OK]${NC}   $1"; }
SKIP(){ echo -e "${YELLOW}[SKIP]${NC} $1"; }
FAIL(){ echo -e "${RED}[FAIL]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_DIR="$SCRIPT_DIR"

echo "================================================================"
echo " ClawHunt #1724 · 零依赖版一键部署（macOS）"
echo " 目录: $COMPOSE_DIR"
echo "================================================================"

# ---------- 1) docker（macOS 通过 Docker Desktop，Homebrew 自动安装） ----------
if command -v docker >/dev/null 2>&1; then
  OK "docker 已安装: $(docker --version)"
else
  echo "docker 未安装，尝试通过 Homebrew 安装 Docker Desktop ..."
  if command -v brew >/dev/null 2>&1; then
    brew install --cask docker
    echo "请先启动 Docker Desktop（Docker 引擎就绪后）再重新运行本脚本。"
    exit 1
  else
    echo "未检测到 Homebrew。请先安装 Homebrew：https://brew.sh/ （或手动安装 Docker Desktop：https://www.docker.com/products/docker-desktop/）"
    echo "安装并启动 Docker Desktop 后重新运行本脚本。"
    exit 1
  fi
fi

# ---------- 2) docker compose 插件（Docker Desktop 自带；缺失时下载到用户级插件目录） ----------
if docker compose version >/dev/null 2>&1; then
  OK "docker compose 插件已安装: $(docker compose version --short 2>/dev/null || docker compose version)"
else
  echo "docker compose 插件未安装，开始安装（官方二进制）..."
  PLUGIN_DIR="$HOME/.docker/cli-plugins"
  mkdir -p "$PLUGIN_DIR"
  curl -SL "https://github.com/docker/compose/releases/latest/download/docker-compose-darwin-$(uname -m)" \
    -o "$PLUGIN_DIR/docker-compose"
  chmod +x "$PLUGIN_DIR/docker-compose"
  if docker compose version >/dev/null 2>&1; then
    OK "docker compose 插件安装完成"
  else
    FAIL "docker compose 插件安装失败，请手动安装后重试"
    exit 1
  fi
fi

# ---------- 3) python3（零依赖版容器运行不需要宿主机 python，仅提示） ----------
if command -v python3 >/dev/null 2>&1; then
  OK "python3 已安装: $(python3 --version 2>&1)"
else
  SKIP "宿主机未安装 python3（容器内自带 python:3.11-slim，不影响部署；如需本地跑 server.py 请另行安装）"
fi

# ---------- 4) docker 守护进程检查 ----------
if ! docker info >/dev/null 2>&1; then
  echo "请确认 Docker Desktop 已启动（菜单栏鲸鱼图标正常、引擎就绪）后重试。"
  exit 1
fi

# ---------- 5) 启动服务 ----------
cd "$COMPOSE_DIR"
echo "开始构建并启动零依赖服务（端口 8000）..."
if docker compose up -d --build; then
  OK "docker compose up -d --build 完成"
else
  FAIL "docker compose 启动失败，请检查上方日志"
  exit 1
fi

sleep 2
if docker compose ps; then
  OK "服务状态如上（容器名 clawhunt1724_zero_dep）"
fi

echo "--------------------------------------------------------------"
echo " 部署完成："
echo "   Web 工作台:  http://localhost:8000/"
echo "   健康检查:    http://localhost:8000/api/health"
echo "   行业接口:    http://localhost:8000/api/industries"
echo "   组件接口:    http://localhost:8000/api/components/jewelry"
echo "   样片视频:    http://localhost:8000/media/ai_demo_1080p_voice_neil_bgm_v5.mp4"
LOCAL_IP="$(ipconfig getifaddr en0 2>/dev/null || true)"
if [ -n "$LOCAL_IP" ]; then
  echo "   局域网访问:  http://$LOCAL_IP:8000/"
fi
echo " 常用命令："
echo "   日志:  docker compose logs -f app"
echo "   停止:  docker compose down"
echo "   重启:  docker compose restart app"
echo "--------------------------------------------------------------"
