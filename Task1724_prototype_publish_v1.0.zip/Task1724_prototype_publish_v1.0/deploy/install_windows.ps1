# ClawHunt #1724 · 零依赖版 · Windows 一键部署脚本
# 用法: powershell -ExecutionPolicy Bypass -File deploy\install_windows.ps1
# 幂等：已安装项显示 [OK] / [SKIP]，可重复执行。
$ErrorActionPreference = "Stop"
$DeployDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $DeployDir

$dockerFound = $false
if (Get-Command docker -ErrorAction SilentlyContinue) {
    $dockerFound = $true
    Write-Host ("[OK]   docker 已安装: " + (docker --version))
} else {
    Write-Host "docker 未安装，尝试通过 winget 自动安装 Docker Desktop ..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install --id Docker.DockerDesktop -e --accept-source-agreements --accept-package-agreements
        Write-Host "Docker Desktop 已安装。请先启动 Docker Desktop（等待引擎就绪）后重新运行本脚本。"
        exit 1
    } else {
        Write-Host "未检测到 winget。请手动安装 Docker Desktop：https://www.docker.com/products/docker-desktop/"
        Write-Host "安装并启动后重新运行本脚本。"
        exit 1
    }
}

# 检测 docker compose 插件（Docker Desktop 自带 compose v2；缺失时自动下载到用户级插件目录）
$composeOk = $false
try {
    docker compose version | Out-Null
    $composeOk = $true
    Write-Host "[OK]   docker compose 插件已安装: " + (docker compose version)
} catch {
    Write-Host "docker compose 插件缺失，自动下载官方二进制到用户级插件目录 ..."
    $pluginDir = Join-Path $env:USERPROFILE ".docker\cli-plugins"
    New-Item -ItemType Directory -Force -Path $pluginDir | Out-Null
    $dest = Join-Path $pluginDir "docker-compose.exe"
    Invoke-WebRequest -Uri "https://github.com/docker/compose/releases/latest/download/docker-compose-windows-x86_64.exe" -OutFile $dest
    Write-Host "[OK]   docker compose 插件已安装: $dest"
}

Write-Host "开始构建并启动零依赖服务（端口 8000）..."
docker compose up -d --build
if ($LASTEXITCODE -ne 0) { Write-Host "[FAIL] docker compose 启动失败，请检查上方日志"; exit 1 }
docker compose ps

Write-Host "--------------------------------------------------------------"
Write-Host " 部署完成："
Write-Host "   Web 工作台:  http://localhost:8000/"
Write-Host "   健康检查:    http://localhost:8000/api/health"
Write-Host "   行业接口:    http://localhost:8000/api/industries"
Write-Host "   组件接口:    http://localhost:8000/api/components/jewelry"
Write-Host "   样片视频:    http://localhost:8000/media/ai_demo_1080p_voice_neil_bgm_v5.mp4"
$ips = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -ExpandProperty IPAddress)
if ($ips) { Write-Host "   局域网访问:  http://$($ips[0]):8000/" }
Write-Host " 常用命令："
Write-Host "   日志:  docker compose logs -f app"
Write-Host "   停止:  docker compose down"
Write-Host "   重启:  docker compose restart app"
Write-Host "--------------------------------------------------------------"
