"""出海增长栈：多语言站点生成（中/英/德）+ SEO 审计 + 询盘→CRM 闭环（纯标准库、确定性）。"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os
import re
from datetime import datetime, timedelta

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_SITE_CONTENT = os.path.join(_DATA_DIR, "site_content_%s.json")
_CASES_DIR = _DATA_DIR

LOCALES = ("zh", "en", "de")
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.S | re.I)
DESC_RE = re.compile(r'<meta\s+name=["\']description["\']\s+content=["\'](.*?)["\']', re.I)
CANON_RE = re.compile(r'<link\s+rel=["\']canonical["\']\s+href=["\'](.*?)["\']', re.I)
HREFLANG_RE = re.compile(r'<link\s+rel=["\']alternate["\']\s+hreflang=["\']([^"\']+)["\']\s+href=["\']([^"\']+)["\']', re.I)
JSONLD_RE = re.compile(r'<script\s+type=["\']application/ld\+json["\']>(.*?)</script>', re.S | re.I)


class DeterministicClock:
    """确定性时钟：固定起点，每次 now() 步进固定分钟数（与 module_a 同构）。"""

    def __init__(self, start="2026-10-27T14:00:00", step_minutes=5):
        self._current = datetime.strptime(start, "%Y-%m-%dT%H:%M:%S")
        self._step = timedelta(minutes=step_minutes)

    def now(self):
        ts = self._current.strftime("%Y-%m-%dT%H:%M:%S")
        self._current += self._step
        return ts

    def now_plus(self, minutes):
        return (self._current + timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M:%S")


class SiteGenerator:
    """多语言静态站点生成：数据驱动（site_content_*.json），输出含完整 SEO 元数据。"""

    def generate(self, locale, out_dir):
        """[发布版占位] 多语言站点生成核心实现将于中标后提供。

        发布版仅生成占位页（含交付提示），完整三语站点模板 / SEO 元数据 /
        多语言内容编排中标后随完整交付提供。
        """
        if locale not in LOCALES:
            raise ValueError("不支持的语种: %s（可选 %s）" % (locale, "/".join(LOCALES)))
        site_dir = os.path.join(out_dir, "site_%s" % locale)
        os.makedirs(site_dir, exist_ok=True)
        out_path = os.path.join(site_dir, "index.html")
        placeholder = (
            "<!DOCTYPE html><html><head><meta charset=\"utf-8\"/>"
            "<title>{0}</title></head><body><h1>{0}</h1>"
            "<p>{1}</p></body></html>"
        ).format(locale, _STUB_NOTE)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(placeholder)
        return {
            "locale": locale,
            "lang_code": locale,
            "file": out_path,
            "hreflang": [],
            "seo_meta": {"title": _STUB_NOTE, "description": _STUB_NOTE},
            "stub": True,
        }
    def _render(self, content):
        base = content["base_url"]
        lang = content["lang_path"]
        hreflang_links = ""
        for code, path in (("zh-CN", "zh"), ("en-US", "en"), ("de-DE", "de")):
            hreflang_links += '<link rel="alternate" hreflang="%s" href="%s/%s/"/>' % (code, base, path)
        products = "".join(
            "<li>%s - %s</li>" % (p["name"], p["price"]) for p in content["products"]
        )
        jsonld = json.dumps({
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": content["site_title"],
            "inLanguage": content["lang_code"],
            "url": "%s/%s/" % (base, lang),
        }, ensure_ascii=False)
        return (
            "<!DOCTYPE html><html lang=\"%s\"><head>"
            "<meta charset=\"utf-8\"/>"
            "<title>%s</title>"
            "<meta name=\"description\" content=\"%s\"/>"
            "<link rel=\"canonical\" href=\"%s/%s/\"/>"
            "%s"
            "<script type=\"application/ld+json\">%s</script>"
            "</head><body>"
            "<h1>%s</h1>"
            "<ul>%s</ul>"
            "</body></html>"
        ) % (
            content["lang_code"], content["site_title"], content["description"],
            base, lang, hreflang_links, jsonld, content["slogan"], products,
        )


class SeoAuditor:
    """SEO 审计：title/description 长度、单一 H1、canonical、互指 hreflang、可解析结构化数据。"""

    def __init__(self, rules=None):
        self.rules = rules or {"title_min": 30, "title_max": 60, "desc_min": 70, "desc_max": 160}
        self.required_hreflang = ["zh-CN", "en-US", "de-DE"]

    def audit(self, html):
        """[发布版占位] SEO 审计核心实现将于中标后提供。"""

        return {"checks": [{"check": "core", "pass": False, "detail": _STUB_NOTE}],

        "overall": False, "stub": True}

class CrmEngine:
    """询盘→CRM 闭环：确定性线索打分、SLA 时钟、负责人、跟进任务、报价草稿、管线事件。"""

    def __init__(self, industry_config):
        crm = industry_config["crm"]
        self.industry = industry_config["industry"]
        self.sla_minutes = crm["sla_minutes"]
        self.owners = crm["owners"]
        self.region_priority = crm.get("region_priority", [])
        self.price_table = crm["price_table"]
        self.weights = crm["score_weights"]
        self.clock = DeterministicClock()
        self.leads = {}
        self._seq = 0

    def _event(self, record, stage, note):
        record["events"].append({"timestamp": self.clock.now(), "stage": stage, "note": note})

    def capture_inquiry(self, lead):
        self._seq += 1

        lead_id = "LEAD-%04d" % self._seq

        record = {"lead_id": lead_id, "lead": lead, "stage": "stub", "events": [],

        "note": _STUB_NOTE}

        self.leads[lead_id] = record

        return record

    def score_lead(self, record):
        record["score"] = 0

        record["qualified"] = False

        record["stage"] = "stub"

        record["note"] = _STUB_NOTE

        return {"score": 0, "qualified": False, "details": [_STUB_NOTE]}

    def create_followup(self, record):
        record["followup_task"] = {"task_id": "TASK-STUB", "owner": _STUB_NOTE,

        "created": "stub", "due": "stub", "action": _STUB_NOTE}

        return record["followup_task"]

    def draft_quote(self, record):
        return {"error": _STUB_NOTE}

    def advance(self, record, outcome):
        record["stage"] = "stub"

        return record["stage"]

def run_crm_flow(industry, lead):
    """端到端询盘→CRM 闭环：接收→打分→跟进→（达标）报价。"""
    from module_b.enterprise_service import EnterpriseService
    engine = EnterpriseService(industry).crm_engine()
    rec = engine.capture_inquiry(lead)
    score = engine.score_lead(rec)
    engine.create_followup(rec)
    quote = engine.draft_quote(rec) if score["qualified"] else None
    return {"engine": engine, "record": rec, "score": score, "quote": quote}


def load_crm_cases():
    with open(os.path.join(_CASES_DIR, "crm_cases.json"), "r", encoding="utf-8") as f:
        return json.load(f)["cases"]


def load_seo_cases():
    with open(os.path.join(_CASES_DIR, "seo_cases.json"), "r", encoding="utf-8") as f:
        return json.load(f)
