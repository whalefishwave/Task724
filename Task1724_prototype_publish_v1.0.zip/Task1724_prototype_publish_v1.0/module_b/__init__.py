"""ClawHunt #1724 模块 B：企业 AI 服务层（FDE 模式）+ 出海增长栈（纯 Python 标准库）。

包含：
- component_registry: 企业组件注册表（>=6 组件，声明行业/能力/契约/依赖/数据边界）
- enterprise_service: 行业配置加载 + 组件调度（同一代码靠配置切换行业）
- export_stack:      出海增长栈（多语言站点生成 / SEO 审计 / 询盘→CRM 闭环）
- fde_handbook:      FDE 驻企交付手册 + 一企一档样例 + 12 项上线清单 + go-live readiness
"""
