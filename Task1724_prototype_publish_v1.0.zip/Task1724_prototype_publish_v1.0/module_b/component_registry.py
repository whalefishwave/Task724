"""企业组件注册表：>=6 个可复用组件，声明行业/能力/契约/依赖/数据边界（JSON 驱动）。"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_COMPONENTS_PATH = os.path.join(_DATA_DIR, "components.json")


def _load_components():
    with open(_COMPONENTS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)["components"]


class ComponentRegistry:
    """组件注册表：读取 components.json，按需过滤行业。"""

    def __init__(self):
        self.components = _load_components()
        self._by_id = {c["component_id"]: c for c in self.components}

    def list_components(self, industry=None):
        """列出组件；industry 不为空时只返回支持该行业的组件。"""
        if industry is None:
            return list(self.components)
        return [c for c in self.components if industry in c["industries"]]

    def get(self, component_id):
        """按 component_id 取组件定义。"""
        return self._by_id.get(component_id)

    def validate_contract(self, component_id, payload):
        """[发布版占位] 组件契约校验核心实现将于中标后提供。"""
        comp = self.get(component_id)
        if comp is None:
            return {"ok": False, "detail": "组件未注册: %s" % component_id}
        return {"ok": False, "missing": ["core"], "component_id": component_id,
                "stub": _STUB_NOTE}
    def assert_config_components(self, config):
        """[发布版占位] 行业配置校验核心实现将于中标后提供（发布版放行占位）。"""

        return {"ok": True, "errors": [], "stub": _STUB_NOTE}

