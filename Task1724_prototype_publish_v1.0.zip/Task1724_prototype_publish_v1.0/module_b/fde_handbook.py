"""FDE 驻企交付手册 + 一企一档样例 + 12 项上线清单 + go-live readiness 推导。"""
import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_HANDBOOK_PATH = os.path.join(_DATA_DIR, "fde_handbook.json")
_PROFILE_PATH = os.path.join(_DATA_DIR, "enterprise_profile_sample.json")


def load_handbook():
    with open(_HANDBOOK_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def load_enterprise_profile():
    with open(_PROFILE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def derive_go_live_readiness(profile=None):
    """推导 go-live readiness：有 blocker 未完成 → not_ready；完成数达标 → ready；否则 conditional。"""
    profile = profile if profile is not None else load_enterprise_profile()
    handbook = load_handbook()
    checklist_def = {c["item"]: c for c in handbook["go_live_checklist"]}
    state = profile["go_live_checklist_state"]
    done = [s for s in state if s["status"] == "done"]
    blockers_open = [s["item"] for s in state
                     if checklist_def[s["item"]]["blocker"] and s["status"] != "done"]
    rules = handbook["readiness_rules"]
    if blockers_open:
        level = "not_ready"
    elif len(done) >= rules["required_done"]:
        level = "ready"
    else:
        level = "conditional"
    return {
        "score": len(done),
        "total": len(state),
        "required_done": rules["required_done"],
        "blockers_open": blockers_open,
        "level": level,
    }
