"""企业 AI 服务层：行业配置加载 + 组件调度。同一代码靠 industry_config 切换行业（禁止复制代码）。"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os

from module_b.component_registry import ComponentRegistry

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_CONFIG_PATH = os.path.join(_DATA_DIR, "industry_config_%s.json")
SUPPORTED_INDUSTRIES = ("jewelry", "wood")


def load_industry_config(industry):
    if industry not in SUPPORTED_INDUSTRIES:
        raise ValueError("不支持的行业: %s（可选 %s）" % (industry, "/".join(SUPPORTED_INDUSTRIES)))
    with open(_CONFIG_PATH % industry, "r", encoding="utf-8") as f:
        return json.load(f)


class EnterpriseService:
    """企业服务层：构造时加载指定行业配置，同一类代码服务不同行业。"""

    def __init__(self, industry):
        self.industry = industry
        self.config = load_industry_config(industry)
        self.registry = ComponentRegistry()
        check = self.registry.assert_config_components(self.config)
        if not check["ok"]:
            raise ValueError("行业配置校验失败: %s" % "; ".join(check["errors"]))

    # ---- knowledge_base ----
    def kb_query(self, question):
        """[发布版占位] 知识库检索核心实现将于中标后提供。"""

        return {"question": question, "industry": self.industry,

        "matched_ids": [], "answer": _STUB_NOTE, "stub": True}

    def agent_chat(self, message):
        """[发布版占位] 智能体对话核心实现将于中标后提供。"""

        return {"message": message, "industry": self.industry,

        "reply": _STUB_NOTE, "kb": {"answer": _STUB_NOTE}, "stub": True}

    def run_workflow(self, trigger):
        """[发布版占位] 自动化工作流核心实现将于中标后提供。"""

        return {"industry": self.industry, "workflow": "占位",

        "trigger": trigger, "steps_log": [], "result": "stub",

        "step_count": 0, "stub": _STUB_NOTE}

    def showcase_list(self):
        """产品场景展示：返回行业配置的展示条目。"""
        return {"industry": self.industry, "products": list(self.config.get("showcase", []))}

    # ---- analytics ----
    def analytics_report(self):
        """[发布版占位] 经营分析核心实现将于中标后提供。"""

        return {"industry": self.industry, "metrics": {}, "estimated_orders": 0,

        "estimated_revenue_usd": 0, "stub": _STUB_NOTE}

    def crm_engine(self):
        from module_b.export_stack import CrmEngine  # 延迟导入避免循环
        return CrmEngine(self.config)
