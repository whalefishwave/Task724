#!/usr/bin/env bash
# ClawHunt #1724 一键运行（macOS / Linux）
# 用法：chmod +x run.sh && ./run.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "== ClawHunt #1724 一键运行（macOS/Linux） =="
if ! command -v python3 >/dev/null 2>&1; then
    echo "错误：未找到 python3，请先安装 Python 3.7+。" >&2
    exit 1
fi
echo "Python 版本：$(python3 -c 'import sys;print("{0}.{1}.{2}".format(*sys.version_info[:3]))')"

python3 start.py
code=$?
if [ "$code" -eq 0 ]; then
    echo "== 全部通过 =="
else
    echo "== 存在失败项（退出码 $code），详见上方 JSON 汇总 ==" >&2
fi
exit "$code"
