"""模块 C②：视觉资产库。

SVG 配方数据驱动（>=6 类 IP 元素），可渲染 / 可校验；
资产清单 + 变更追溯（确定性时间戳 + sha256 校验和）；
禁止抄袭真实品牌形象（brand_terms 拦截）。
纯 Python 标准库（xml.etree / hashlib / json / re），零第三方依赖。
"""
import hashlib
import json
import os
import re
import xml.etree.ElementTree as ET

from .common import deterministic_timestamp

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_RECIPES_PATH = os.path.join(_DATA_DIR, "visual_recipes.json")
_REGISTRY_PATH = os.path.join(_DATA_DIR, "asset_registry.json")
_SAFETY_PATH = os.path.join(_DATA_DIR, "safety_words.json")


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_recipes():
    """加载 SVG 配方库。"""
    return _load_json(_RECIPES_PATH)["recipes"]


def get_recipe(recipe_id):
    for r in load_recipes():
        if r["recipe_id"] == recipe_id:
            return r
    return None


def render_recipe(recipe_id, params=None):
    """按配方渲染 SVG 文本（确定性）。返回 {ok, svg, meta, errors}。"""
    recipe = get_recipe(recipe_id)
    if recipe is None:
        return {"ok": False, "svg": "", "meta": {}, "errors": ["unknown_recipe:{}".format(recipe_id)]}
    merged = dict(recipe["default_params"])
    if params:
        merged.update(params)
    placeholders = set(re.findall(r"\{(\w+)\}", recipe["svg_template"]))
    unknown = [k for k in params or {} if k not in placeholders]
    if unknown:
        return {"ok": False, "svg": "", "meta": {}, "errors": ["unknown_param:{}".format(",".join(unknown))]}
    try:
        svg = recipe["svg_template"].format(**merged)
    except KeyError as e:
        return {"ok": False, "svg": "", "meta": {}, "errors": ["missing_param:{}".format(e)]}
    meta = {
        "recipe_id": recipe_id, "name": recipe["name"], "category": recipe["category"],
        "original_design": recipe.get("original_design", False),
        "no_external_brand": recipe.get("no_external_brand", False),
        "usage_tags": recipe.get("usage_tags", []),
    }
    return {"ok": True, "svg": svg, "meta": meta, "errors": []}


def validate_svg(svg_text):
    """SVG 渲染校验：合法 XML、根为 svg、无脚本、无外部引用、尺寸为正整数。"""
    errors = []
    try:
        root = ET.fromstring(svg_text)
    except ET.ParseError as e:
        return {"ok": False, "errors": ["xml_parse:{}".format(e)]}
    if not root.tag.endswith("svg"):
        errors.append("root_not_svg")
    if any(el.tag.endswith("script") for el in root.iter()):
        errors.append("script_forbidden")
    if "href" in svg_text or "xlink" in svg_text:
        errors.append("external_ref_forbidden")
    stripped = re.sub(r'xmlns(:\w+)?="http[^"]*"', "", svg_text)
    if "http://" in stripped or "https://" in stripped:
        errors.append("external_url_forbidden")
    m_w = re.search(r'width="(\d+)"', svg_text)
    m_h = re.search(r'height="(\d+)"', svg_text)
    if not (m_w and m_h and int(m_w.group(1)) > 0 and int(m_h.group(1)) > 0):
        errors.append("invalid_dimension")
    return {"ok": not errors, "errors": errors}


def check_brand_terms(svg_text, safety=None):
    """检查渲染文本是否命中真实品牌禁用词（禁止抄袭品牌形象）。"""
    safety = safety or _load_json(_SAFETY_PATH)
    brand = safety.get("brand_terms", [])
    low = svg_text.lower()
    return [w for w in brand if w.lower() in low]


class AssetLibrary:
    """资产库：登记 / 变更追溯。确定性：同输入两次登记结果一致。"""

    def __init__(self, registry_path=None):
        self.registry_path = registry_path or _REGISTRY_PATH
        data = _load_json(self.registry_path)
        self.assets = [dict(a) for a in data.get("assets", [])]
        self.changelog = [dict(c) for c in data.get("changelog", [])]
        self.safety = _load_json(_SAFETY_PATH)

    def add(self, recipe_id, params=None, operator="system", note=""):
        """渲染 -> 校验 -> 品牌词检查 -> 登记资产与变更日志。"""
        res = render_recipe(recipe_id, params)
        if not res["ok"]:
            return {"ok": False, "errors": res["errors"]}
        svg = res["svg"]
        v = validate_svg(svg)
        if not v["ok"]:
            return {"ok": False, "errors": v["errors"]}
        brand_hits = check_brand_terms(svg, self.safety)
        if brand_hits:
            return {"ok": False, "errors": ["brand_term:{}".format(",".join(brand_hits))]}
        seq = len(self.assets) + 1
        asset_id = "AST-{:04d}".format(seq)
        checksum = hashlib.sha256(svg.encode("utf-8")).hexdigest()
        at = deterministic_timestamp(len(self.changelog))
        asset = {
            "asset_id": asset_id, "recipe_id": recipe_id, "name": res["meta"]["name"],
            "category": res["meta"]["category"], "checksum": checksum,
            "created_at": at, "operator": operator, "note": note,
        }
        self.assets.append(asset)
        self.changelog.append({
            "seq": len(self.changelog) + 1, "at": at, "asset_id": asset_id,
            "action": "add", "recipe_id": recipe_id, "operator": operator,
            "note": note, "checksum": checksum,
        })
        return {"ok": True, "asset": asset, "svg": svg, "checksum": checksum}

    def get(self, asset_id):
        for a in self.assets:
            if a["asset_id"] == asset_id:
                return a
        return None

    def list_assets(self):
        return [dict(a) for a in self.assets]

    def list_changelog(self):
        return [dict(c) for c in self.changelog]

    def persist(self, path=None):
        target = path or self.registry_path
        with open(target, "w", encoding="utf-8") as f:
            json.dump({"registry_id": "IP-REG-001", "schema_version": "1.0",
                       "assets": self.assets, "changelog": self.changelog},
                      f, ensure_ascii=False, indent=2)
        return target
