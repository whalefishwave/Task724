"""模块 C④：IP 授权文档 + 衍生品规范 + 内容审核（安全词表/合规过滤/审核日志）。

- 授权矩阵：类型 / 范围 / 期限 / 版税 / 审批门禁（JSON 驱动）
- 衍生品规范：珠宝吊饰 / 鞋服联名 / 木雕收藏品 / 文创礼赠 四类
- 内容审核：安全词表（banned/safe/brand_terms）、合规过滤、审核日志
"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os
import uuid

from .common import deterministic_timestamp

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def _load_json(name):
    with open(os.path.join(_DATA_DIR, name), "r", encoding="utf-8") as f:
        return json.load(f)


def load_matrix():
    """[发布版占位] IP 授权矩阵核心实现将于中标后提供。"""
    return {
        "matrix_id": "stub",
        "non_exclusive_clause": _STUB_NOTE,
        "ai_generated_marking_required": False,
        "license_matrix": [],
        "derivative_specs": [],
        "approval_workflow": [],
        "stub": True,
    }
def load_safety_words():
    """加载内容审核安全词表。"""
    return _load_json("safety_words.json")


def get_license(license_type):
    """按类型取授权条目（ip_license / merchandise_license / event_license）。"""
    for lic in load_matrix()["license_matrix"]:
        if lic["license_type"] == license_type:
            return lic
    return None


def list_derivative_specs():
    """列出四类衍生品规范。"""
    return load_matrix()["derivative_specs"]


def render_license_contract(license_type, licensee, purpose, owner="委托方（脱敏）"):
    """[发布版占位] 授权合同渲染核心实现将于中标后提供。"""
    return (
        "# IP 授权合同模板（发布版占位，核心实现将于中标后提供）\n"
        "\n"
        "- 授权类型：{}（完整授权矩阵中标后提供）\n"
        "- 被授权方：{}\n"
        "- 授权用途：{}\n"
        "- 授权区域/渠道/媒介/期限/版税/审批门禁：{}（中标后提供）\n"
        "\n"
        "本仓库为演示骨架，完整核心交付中标后提供。"
    ).format(license_type, licensee, purpose, _STUB_NOTE)
def review_content(text, safety=None, meta=None):
    """[发布版占位] 内容审核核心实现将于中标后提供（发布版放行占位）。"""
    return {
        "ok": True, "decision": "pass", "hits": [], "brand_hits": [],
        "safe_hits": [], "marking_ok": True,
        "note": _STUB_NOTE, "log_id": "RVW-STUB",
        "stub": True,
    }
class ReviewLog:
    """内容审核日志（确定性时间戳，可落盘）。"""

    def __init__(self):
        self.entries = []

    def add(self, text, result, context=""):
        entry = {
            "seq": len(self.entries) + 1,
            "at": deterministic_timestamp(len(self.entries)),
            "context": context,
            "text_preview": text[:40],
            "decision": result["decision"],
            "hits": result["hits"],
            "brand_hits": result["brand_hits"],
            "marking_ok": result["marking_ok"],
            "log_id": result["log_id"],
        }
        self.entries.append(entry)
        return entry

    def dump(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"entries": self.entries}, f, ensure_ascii=False, indent=2)
        return path
