"""模块 C①：IP 双守护角色设定（内容守护 + 技术守护），JSON 驱动。

角色规则与审查清单全部来自 module_c/data/characters.json，
非程序员可维护。设定明确"传统文化原型与宗教场所名称不被声明为独占权利"。
"""
import json
import os

_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "characters.json")


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_characters():
    """加载完整角色设定手册。"""
    return _load_json(_DATA_PATH)


def get_character(duty):
    """按守护职责（content / technical）取角色。"""
    data = load_characters()
    for c in data["characters"]:
        if c["duty"] == duty:
            return c
    return None


def list_rules(duty=None):
    """列出角色规则；duty 为空时返回全部。"""
    chars = load_characters()["characters"]
    out = []
    for c in chars:
        if duty is None or c["duty"] == duty:
            for r in c["rules"]:
                out.append({"character_id": c["character_id"], "name": c["name"], **r})
    return out


def list_checklist(duty=None):
    """列出审查清单；duty 为空时返回全部。"""
    chars = load_characters()["characters"]
    out = []
    for c in chars:
        if duty is None or c["duty"] == duty:
            for chk in c["review_checklist"]:
                out.append({"character_id": c["character_id"], "name": c["name"], **chk})
    return out


def verify_handbook():
    """校验设定手册完整性：双角色、字段齐全、非独占声明、AI 标识、规则可执行。"""
    data = load_characters()
    errors = []
    chars = data.get("characters", [])
    if len(chars) != 2:
        errors.append("expected_2_characters")
    if not data.get("non_exclusive_clause"):
        errors.append("missing_non_exclusive_clause")
    if not data.get("ai_generated_note"):
        errors.append("missing_ai_generated_note")
    duties = {c.get("duty") for c in chars}
    if "content" not in duties or "technical" not in duties:
        errors.append("missing_duty_role")
    for c in chars:
        for key in ("character_id", "name", "duty", "motto", "personality",
                    "relationship", "taboos", "rules", "review_checklist"):
            if key not in c:
                errors.append("missing_field:{}:{}".format(c.get("character_id"), key))
        for r in c.get("rules", []):
            for key in ("rule_id", "domain", "statement", "action"):
                if key not in r:
                    errors.append("missing_rule_field:{}".format(key))
        if not c.get("review_checklist"):
            errors.append("empty_checklist:{}".format(c.get("character_id")))
    return {"ok": not errors, "errors": errors, "character_count": len(chars)}
