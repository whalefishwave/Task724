"""模块 C③：短剧工作流：剧本→分镜→角色资产→渲染→内容审核→成片。

- 全链路状态机（>=5 环节，含返工分支 REWORK）
- 剧本到分镜的确定性推导规则（R1-R5）
- 产出可校验的 SVG 帧序列（纯标准库生成，禁止第三方图像库）
- 内容审核拦截违规对白时自动进入返工并净化，工作流日志完整
"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os
import re
import xml.sax.saxutils as saxutils

from .assets import AssetLibrary, render_recipe, validate_svg
from .common import deterministic_timestamp
from .license import ReviewLog, load_safety_words, review_content

# 状态机：>=5 个正向环节 + 返工分支
STATES = ("SCRIPT_REVIEW", "STORYBOARD", "ASSET_PICK", "RENDER", "CONTENT_REVIEW",
          "REWORK", "PUBLISH")

TRANSITIONS = {
    "SCRIPT_REVIEW": {"pass": "STORYBOARD", "rework": "REWORK"},
    "STORYBOARD": {"pass": "ASSET_PICK", "rework": "REWORK"},
    "ASSET_PICK": {"pass": "RENDER", "rework": "REWORK"},
    "RENDER": {"pass": "CONTENT_REVIEW", "rework": "REWORK"},
    "CONTENT_REVIEW": {"pass": "PUBLISH", "reject": "REWORK"},
    "REWORK": {"to_script": "SCRIPT_REVIEW", "to_storyboard": "STORYBOARD",
               "to_asset": "ASSET_PICK", "to_render": "RENDER", "to_review": "CONTENT_REVIEW"},
    "PUBLISH": {},
}

TAG_TO_RECIPE = {
    "lantern": "ip-element-lantern", "wave": "ip-element-wave",
    "shield": "ip-element-shield", "knot": "ip-element-knot",
    "beacon": "ip-element-beacon", "eye": "ip-element-eye",
    "shell": "ip-element-shell", "compass": "ip-element-compass",
}
SHOT_SIZES = ("远景", "中景", "近景")


class InvalidTransitionError(Exception):
    pass


class PipelineMachine:
    """短剧工作流状态机。"""

    def __init__(self, start="SCRIPT_REVIEW"):
        self.state = start
        self.history = []

    def apply(self, event, note=""):
        allowed = TRANSITIONS.get(self.state, {})
        if event not in allowed:
            raise InvalidTransitionError("{} -> {} 非法转换".format(self.state, event))
        old = self.state
        self.state = allowed[event]
        self.history.append({"from": old, "to": self.state, "event": event, "note": note})
        return self.state

    @property
    def positive_forward_states(self):
        return [e["to"] for e in self.history]


def derive_storyboard(script):
    """[发布版占位] 剧本→分镜确定性推导（R1-R5）核心实现将于中标后提供。"""
    return [{
        "shot_no": 1, "scene_id": "stub", "shot_type": "establish",
        "shot_size": "远景", "duration_s": 0,
        "caption": _STUB_NOTE, "speaker": "旁白",
        "element_refs": ["ip-element-shield"],
    }]
def compose_frame(shot, recipe_svg, width=320, height=240):
    """[发布版占位] SVG 帧合成核心实现将于中标后提供。"""
    return (
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{0}\" height=\"{1}\">"
        "<text>{2}</text></svg>"
    ).format(width, height, _STUB_NOTE)
def _purge_line(line, safety):
    """合规过滤：命中禁用词时整句替换为净化提示（保留叙事梗概）。"""
    low = line.lower()
    banned = safety.get("banned", [])
    brand = safety.get("brand_terms", [])
    hit = [w for w in banned if w.lower() in low] + [w for w in brand if w.lower() in low]
    if hit:
        return safety.get("replacement_hint", "内容经守护审核净化，保留叙事梗概"), hit
    return line, []


def _purge_script(script, safety, review_log):
    """净化剧本全部对白，逐条过内容审核并写审核日志。返回 (净化后剧本, violations)。"""
    purged = json.loads(json.dumps(script))
    violations = []
    for scene in purged["scenes"]:
        for d in scene["dialogue"]:
            r = review_content(d["line"], safety=safety, meta={"ai_marking": True})
            review_log.add(d["line"], r, context="script_review:{}:{}".format(scene["scene_id"], d["speaker"]))
            if not r["ok"]:
                new_line, hit_words = _purge_line(d["line"], safety)
                violations.append({
                    "scene_id": scene["scene_id"], "speaker": d["speaker"],
                    "original": d["line"], "hits": r["hits"] or [(w, 1) for w in hit_words],
                    "purged_to": new_line,
                })
                d["line"] = new_line
    return purged, violations


def run_auto(script, out_dir, safety=None, registry_path=None):
    """[发布版占位] 短剧样片生成核心实现将于中标后提供。

    完整工作流（剧本审核→分镜→资产→渲染→内容审核→成片发布、返工分支、
    SVG 帧序列）中标后随完整交付提供；发布版仅返回占位结果。
    """
    return {
        "ok": False, "episode_id": script.get("episode_id", "STUB"),
        "title": script.get("title", "STUB"),
        "storyboard": [], "storyboard_file": None,
        "frames": [], "log": [], "log_file": None,
        "rework_events": [], "review_log_file": None,
        "states_visited": ["STUB"], "final_state": "STUB",
        "stub": _STUB_NOTE,
    }
