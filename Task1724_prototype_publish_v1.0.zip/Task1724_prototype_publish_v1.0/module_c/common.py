"""module_c 公共工具：确定性时钟（纯标准库，零依赖）。

为保证可复跑与确定性输出，所有时间戳由固定基准 + 递增秒推导，
不依赖系统时钟。
"""
import datetime

_BASE = datetime.datetime(2026, 10, 28, 8, 0, 0)


def deterministic_timestamp(offset=0):
    """返回确定性的 ISO 时间戳字符串。offset 为相对基准的秒数偏移。"""
    return (_BASE + datetime.timedelta(seconds=offset)).strftime("%Y-%m-%dT%H:%M:%S")
