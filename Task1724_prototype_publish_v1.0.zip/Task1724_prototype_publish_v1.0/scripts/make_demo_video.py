"""ClawHunt #1724 投标演示样片 v2 —— 路演叙事线「区域特色产业 AI 赋能一期」。

用法：python scripts/make_demo_video.py [--theme pitch]
输出：output/demo_video/demo_v2.gif（16:9 横屏 960x540，23 帧循环动画）
      output/demo_video/frames_v2_notes.json（逐帧英文字幕 + 中文旁白）

主题叙事线（7 段场景）：
  S1 开场（项目定位标题）→ S2 产业数字化（珠宝+木作、工艺规则、可制造性 10/10、授权 PASS）
  → S3 企业 AI 服务层（6 组件、一企一档、FDE 手册）→ S4 出海增长栈（三语站点、SEO、询盘→CRM 闭环）
  → S5 文化 IP 管线（文鉴+工衡、原创资产、短剧样片、授权矩阵）→ S6 赛事传播（3 赛道、评审、KPI）
  → S7 结尾（125 TESTS ALL GREEN、零依赖、离线确定性、三平台一键安装）

实现：纯 Python 标准库。SVG 光栅化复用 legacy 渲染器（将模块 C 短剧帧缩小嵌入），
点阵文字复用 legacy 内置 5x7 ASCII 字体，GIF89a 编码器自实现（全局色表 + LZW + Netscape 循环）。
场景间使用交叉淡化过渡帧。零第三方依赖、离线、确定性。

旧版 320x240 拼接样片保留于 scripts/make_demo_video_legacy.py（生成 demo.gif）。
"""
import json
import os
import re
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
import make_demo_video_legacy as legacy  # 复用 _Svg 光栅化器 / _draw_text 点阵字体

_draw_text = legacy._draw_text
W, H = 960, 540
_BG = (13, 26, 46)
_GOLD = (242, 193, 78)
_WHITE = (255, 255, 255)
_GRAY = (200, 214, 234)
_GREEN = (140, 255, 170)
_BLUE = (66, 165, 245)
_RED = (211, 47, 47)
_DARK = (8, 16, 28)


def _blank(bg=_BG):
    return [[list(bg) for _ in range(W)] for _ in range(H)]


def _px(c, x, y, color):
    if 0 <= x < W and 0 <= y < H:
        c[y][x] = list(color)


def _fill_rect(c, x0, y0, x1, y1, color):
    for yy in range(max(0, y0), min(H - 1, y1) + 1):
        for xx in range(max(0, x0), min(W - 1, x1) + 1):
            c[yy][xx] = list(color)


def _disc(c, cx, cy, r, color):
    for yy in range(cy - r, cy + r + 1):
        for xx in range(cx - r, cx + r + 1):
            if (xx - cx) ** 2 + (yy - cy) ** 2 <= r * r:
                _px(c, xx, yy, color)


def _bar(c, x, y, w, h, color):
    _fill_rect(c, x, y, x + w, y + h, color)


def _header(c, title, right="#1724 PHASE-1"):
    _fill_rect(c, 0, 0, W - 1, 56, (10, 20, 38))
    _draw_text(c, 24, 16, title, _GOLD, 2)
    if right:
        _draw_text(c, 700, 24, right, _GRAY, 1)


def _subtitle_bar(c, caption, frame_no, scene_no):
    _fill_rect(c, 0, 486, W - 1, H - 1, _DARK)
    _draw_text(c, 24, 502, caption, _WHITE, 1)
    _draw_text(c, 700, 502, "FRAME {}  SCENE {}".format(frame_no, scene_no), _GRAY, 1)


def _card(c, x0, y0, x1, y1, fill, border=_WHITE, bw=3):
    _fill_rect(c, x0, y0, x1, y1, fill)
    for i in range(bw):
        _fill_rect(c, x0 + i, y0 + i, x0 + i, y1 - i, border)
        _fill_rect(c, x1 - i, y0 + i, x1 - i, y1 - i, border)
        _fill_rect(c, x0 + i, y0 + i, x1 - i, y0 + i, border)
        _fill_rect(c, x0 + i, y1 - i, x1 - i, y1 - i, border)


def _blend(a, b, t):
    out = _blank()
    for yy in range(H):
        for xx in range(W):
            pa, pb = a[yy][xx], b[yy][xx]
            out[yy][xx] = [int(round(pa[i] * (1 - t) + pb[i] * t)) for i in range(3)]
    return out


def _scale_down(src, tw, th):
    sh = len(src)
    sw = len(src[0])
    out = [[(0, 0, 0) for _ in range(tw)] for _ in range(th)]
    for yy in range(th):
        sy = min(sh - 1, int(yy * sh / th))
        for xx in range(tw):
            sx = min(sw - 1, int(xx * sw / tw))
            out[yy][xx] = tuple(src[sy][sx])
    return out


# ---------------------------------------------------------------- 7 段场景
def _s1_open_1():
    c = _blank()
    _header(c, "TITLE")
    _draw_text(c, 336, 140, "#1724", _GOLD, 8)
    t = "REGIONAL INDUSTRY AI ENABLEMENT"
    _draw_text(c, (W - 6 * 3 * len(t)) // 2, 258, t, _WHITE, 3)
    t2 = "PHASE-1 DEMO PROTOTYPE"
    _draw_text(c, (W - 6 * 2 * len(t2)) // 2, 330, t2, _GRAY, 2)
    t3 = "CULTURE x CRAFT x C2M"
    _draw_text(c, (W - 6 * 2 * len(t3)) // 2, 396, t3, _GOLD, 2)
    _subtitle_bar(c, "REGIONAL INDUSTRY AI ENABLEMENT PHASE-1", 1, 1)
    return c


def _s1_open_2():
    c = _blank()
    _header(c, "TWO INDUSTRIES")
    # 珠宝卡
    _card(c, 110, 110, 450, 360, (64, 30, 44))
    _disc(c, 280, 200, 64, (242, 193, 78))
    _disc(c, 280, 200, 40, (64, 30, 44))
    _draw_text(c, 230, 290, "JEWELRY", _WHITE, 3)
    # 木作卡
    _card(c, 510, 110, 850, 360, (52, 40, 32))
    _bar(c, 580, 170, 40, 80, (168, 120, 72))
    _bar(c, 640, 190, 40, 60, (196, 146, 92))
    _bar(c, 700, 150, 40, 100, (168, 120, 72))
    _draw_text(c, 640, 290, "WOOD", _WHITE, 3)
    _draw_text(c, 300, 420, "DUAL-INDUSTRY PROFILES", _GREEN, 2)
    _subtitle_bar(c, "TWO INDUSTRIES  JEWELRY + WOOD", 2, 1)
    return c


def _s2_digital_1():
    c = _blank()
    _header(c, "INDUSTRY DIGITALIZATION")
    # 左配置卡
    _card(c, 90, 100, 460, 420, (20, 40, 66))
    _draw_text(c, 130, 130, "JEWELRY CONFIG", _GOLD, 2)
    _bar(c, 130, 180, 280, 16, (66, 165, 245))
    _bar(c, 130, 220, 240, 16, (66, 165, 245))
    _bar(c, 130, 260, 300, 16, (66, 165, 245))
    _draw_text(c, 130, 300, "MOTIF AUTH / EQUIP / RULES", _GRAY, 1)
    # 右配置卡
    _card(c, 500, 100, 870, 420, (36, 32, 24))
    _draw_text(c, 540, 130, "WOOD CONFIG", _GOLD, 2)
    _bar(c, 540, 180, 280, 16, (242, 193, 78))
    _bar(c, 540, 220, 230, 16, (242, 193, 78))
    _bar(c, 540, 260, 260, 16, (242, 193, 78))
    _draw_text(c, 540, 300, "EQUIP / RULES / CRAFT", _GRAY, 1)
    _draw_text(c, 340, 446, "1-CLICK SWITCH", _GREEN, 2)
    _subtitle_bar(c, "DUAL-INDUSTRY PROFILES  JEWELRY / WOOD", 3, 2)
    return c


def _s2_digital_2():
    c = _blank()
    _header(c, "CRAFT RULES")
    rules = ["R1  MOTIF AUTHORIZATION CHECK", "R2  EQUIPMENT CAPABILITY LIMIT", "R3  CRAFT PROCESS RULES"]
    for i, rtext in enumerate(rules):
        y0 = 130 + i * 90
        _bar(c, 120, y0, 50, 44, _BLUE)
        _draw_text(c, 134, y0 + 10, "R{}".format(i + 1), _WHITE, 2)
        _card(c, 190, y0, 840, y0 + 44, (22, 42, 66), _GRAY, 2)
        _draw_text(c, 220, y0 + 14, rtext, _WHITE, 2)
    _draw_text(c, 300, 430, "RULES + EQUIPMENT AS DATA", _GREEN, 2)
    _subtitle_bar(c, "CRAFT RULES  MFG + EQUIPMENT AS DATA", 4, 2)
    return c


def _s2_digital_3():
    c = _blank()
    _header(c, "MFG 10/10 + AUTH PASS")
    # 可制造性条形图
    for i in range(10):
        hh = 60 + (i % 3) * 18
        _bar(c, 120 + i * 68, 360 - hh, 40, hh, _GREEN if i < 10 else _RED)
    _draw_text(c, 150, 380, "MFG SCORE", _WHITE, 2)
    _draw_text(c, 300, 430, "10 / 10", _GREEN, 3)
    # 授权校验 PASS 徽章
    _card(c, 620, 160, 860, 300, (18, 70, 44), _GREEN, 3)
    _draw_text(c, 700, 200, "AUTH PASS", _GREEN, 3)
    _draw_text(c, 660, 252, "MOTIF LICENSE VALID", _WHITE, 1)
    _subtitle_bar(c, "MFG 10/10  MOTIF AUTH PASS", 5, 2)
    return c


def _s3_enterprise_1():
    c = _blank()
    _header(c, "ENTERPRISE AI SERVICE LAYER")
    names = ["REG", "SVC", "EXP", "FDE", "CFG", "PRO"]
    for i, n in enumerate(names):
        row, col = divmod(i, 3)
        x0 = 100 + col * 270
        y0 = 120 + row * 160
        _card(c, x0, y0, x0 + 210, y0 + 120, (22, 42, 66), _GRAY, 2)
        _draw_text(c, x0 + 30, y0 + 30, n, _GOLD, 4)
        _draw_text(c, x0 + 30, y0 + 80, "COMPONENT", _GRAY, 1)
    _draw_text(c, 330, 440, "6-COMPONENT REGISTRY", _GREEN, 2)
    _subtitle_bar(c, "AI SERVICE LAYER  6 COMPONENT REGISTRY", 6, 3)
    return c


def _s3_enterprise_2():
    c = _blank()
    _header(c, "PROFILE + FDE HANDBOOK")
    # 一企一档
    _card(c, 100, 120, 460, 400, (20, 40, 66), _GRAY, 2)
    _draw_text(c, 130, 150, "ONE-ENTERPRISE-ONE-PROFILE", _GOLD, 2)
    _bar(c, 130, 220, 280, 16, _BLUE)
    _bar(c, 130, 260, 220, 16, _BLUE)
    _bar(c, 130, 300, 250, 16, _BLUE)
    _draw_text(c, 130, 340, "PROFILE / ASSETS / SLO", _GRAY, 1)
    # FDE 手册
    _card(c, 500, 120, 860, 400, (52, 40, 32), _GRAY, 2)
    _draw_text(c, 530, 150, "FDE HANDBOOK", _GOLD, 2)
    _bar(c, 530, 220, 300, 16, _GREEN)
    _bar(c, 530, 260, 240, 16, _GREEN)
    _bar(c, 530, 300, 270, 16, _GREEN)
    _draw_text(c, 530, 340, "5 CH  /  12 CHECKLIST", _GRAY, 1)
    _subtitle_bar(c, "ONE-ENTERPRISE-ONE-PROFILE + FDE HANDBOOK", 7, 3)
    return c


def _s4_export_1():
    c = _blank()
    _header(c, "GO-GLOBAL SITES")
    sites = [("ZH", _RED), ("EN", _BLUE), ("DE", (255, 193, 7))]
    for i, (name, color) in enumerate(sites):
        x0 = 90 + i * 270
        _card(c, x0, 120, x0 + 220, 420, (18, 34, 56), _GRAY, 2)
        _fill_rect(c, x0 + 12, 132, x0 + 208, 168, color)
        _draw_text(c, x0 + 70, 142, name, _WHITE, 2)
        _draw_text(c, x0 + 24, 186, "LANG SITE", _WHITE, 1)
        _bar(c, x0 + 24, 220, 160, 12, _GRAY)
        _bar(c, x0 + 24, 250, 130, 12, _GRAY)
        _bar(c, x0 + 24, 280, 170, 12, _GRAY)
        _bar(c, x0 + 24, 330, 90, 12, _GREEN)
        _draw_text(c, x0 + 24, 352, "SEO READY", _GREEN, 1)
    _subtitle_bar(c, "3-LANG SITES  ZH / EN / DE", 8, 4)
    return c


def _s4_export_2():
    c = _blank()
    _header(c, "SEO PASS")
    _draw_text(c, 180, 190, "SEO", _GOLD, 8)
    rows = [("SEARCH", 300), ("META", 240), ("MOBILE", 260)]
    for i, (name, rw) in enumerate(rows):
        y0 = 150 + i * 90
        _draw_text(c, 420, y0 + 8, name, _WHITE, 2)
        _bar(c, 560, y0, rw, 36, _BLUE)
        _draw_text(c, 560 + rw + 16, y0 + 8, "OK", _GREEN, 2)
    _card(c, 760, 300, 900, 360, (18, 70, 44), _GREEN, 2)
    _draw_text(c, 800, 320, "PASS", _GREEN, 2)
    _subtitle_bar(c, "SEO PASS  SEARCH / META / MOBILE", 9, 4)
    return c


def _s4_export_3():
    c = _blank()
    _header(c, "INQUIRY -> CRM CLOSED LOOP")
    nodes = ["INQUIRY", "SCORE", "SLA", "QUOTE"]
    colors = [_BLUE, _GOLD, _GREEN, _RED]
    for i, (n, color) in enumerate(zip(nodes, colors)):
        x0 = 90 + i * 210
        _card(c, x0, 180, x0 + 150, 260, (22, 42, 66), color, 2)
        _draw_text(c, x0 + 18, 210, n, color, 2)
        if i < 3:
            for xx in range(x0 + 152, x0 + 202):
                _px(c, xx, 220, _WHITE)
            _px(c, x0 + 198, 214, _WHITE)
            _px(c, x0 + 198, 226, _WHITE)
    _draw_text(c, 210, 330, "AUTO SCORE  SLA TRACK  QUOTE FLOW", _GRAY, 1)
    _draw_text(c, 300, 430, "CLOSED-LOOP CRM", _GREEN, 2)
    _subtitle_bar(c, "INQUIRY -> SCORE -> SLA -> QUOTE", 10, 4)
    return c


def _s5_ip_1():
    c = _blank()
    _header(c, "CULTURAL IP PIPELINE")
    # 文鉴
    _card(c, 110, 110, 450, 380, (20, 40, 66), _BLUE, 3)
    _draw_text(c, 150, 140, "WENJIAN", _BLUE, 3)
    _draw_text(c, 150, 200, "CONTENT GUARD", _WHITE, 2)
    _bar(c, 150, 250, 240, 14, _BLUE)
    _bar(c, 150, 280, 190, 14, _BLUE)
    # 工衡
    _card(c, 510, 110, 850, 380, (18, 56, 40), _GREEN, 3)
    _draw_text(c, 550, 140, "GONGHENG", _GREEN, 3)
    _draw_text(c, 550, 200, "TECH GUARD", _WHITE, 2)
    _bar(c, 550, 250, 240, 14, _GREEN)
    _bar(c, 550, 280, 200, 14, _GREEN)
    _draw_text(c, 330, 430, "DUAL GUARDIAN ROLES", _GOLD, 2)
    _subtitle_bar(c, "DUAL GUARDIANS  WENJIAN + GONGHENG", 11, 5)
    return c


def _s5_ip_2():
    c = _blank()
    _header(c, "EPISODE DEMO")
    # 嵌入 module_c 短剧帧（frame_004 缩小）
    svg_text = open(os.path.join(
        os.path.dirname(_SCRIPT_DIR),
        "output", "episode_demo", "frame_004.svg"), encoding="utf-8").read()
    small = legacy._Svg(svg_text).render()
    thumb = _scale_down(small, 360, 270)
    for yy in range(270):
        for xx in range(360):
            _px(c, 90 + xx, 130 + yy, thumb[yy][xx])
    _card(c, 520, 150, 850, 380, (22, 42, 66), _GRAY, 2)
    _draw_text(c, 560, 200, "SHORT DRAMA", _GOLD, 3)
    _draw_text(c, 560, 270, "FRAME 004", _WHITE, 2)
    _draw_text(c, 560, 310, "ORIGINAL ASSETS", _GREEN, 2)
    _subtitle_bar(c, "SHORT DRAMA EPISODE  ORIGINAL VISUAL ASSETS", 12, 5)
    return c


def _s5_ip_3():
    c = _blank()
    _header(c, "LICENSE MATRIX")
    lic = [("IP", _BLUE), ("DERIVATIVE", _GOLD), ("CONTEST", _GREEN)]
    for i, (name, color) in enumerate(lic):
        x0 = 100 + i * 270
        _card(c, x0, 140, x0 + 220, 320, (22, 42, 66), color, 3)
        _draw_text(c, x0 + 30, 190, name, color, 2)
        _draw_text(c, x0 + 30, 250, "LICENSED", _WHITE, 2)
        _draw_text(c, x0 + 30, 290, "MET", _GREEN, 2)
    _draw_text(c, 300, 380, "3 LICENSE TYPES  ALL MET", _GREEN, 2)
    _subtitle_bar(c, "LICENSE MATRIX  IP / DERIVATIVE / CONTEST", 13, 5)
    return c


def _s6_contest_1():
    c = _blank()
    _header(c, "CONTEST 3 TRACKS")
    tracks = [("T1", "DESIGN", 250), ("T2", "CRAFT", 220), ("T3", "STORY", 240)]
    for i, (t, sub, hh) in enumerate(tracks):
        x0 = 110 + i * 260
        _bar(c, x0, 320 - hh, 180, hh, [_BLUE, _GOLD, _GREEN][i])
        _draw_text(c, x0 + 60, 330, t, _WHITE, 3)
        _draw_text(c, x0 + 50, 360, sub, _WHITE, 2)
    _draw_text(c, 320, 430, "3 TRACKS  SCORE + GATE", _GREEN, 2)
    _subtitle_bar(c, "CONTEST 3 TRACKS  SCORE / GATE", 14, 6)
    return c


def _s6_contest_2():
    c = _blank()
    _header(c, "REVIEW BOARD + KPI")
    # 评审表
    _card(c, 90, 120, 500, 400, (20, 40, 66), _GRAY, 2)
    heads = ["ID", "SCORE", "GATE"]
    for j, htxt in enumerate(heads):
        _fill_rect(c, 100 + j * 135, 130, 100 + j * 135 + 128, 162, (30, 60, 90))
        _draw_text(c, 140 + j * 135, 138, htxt, _WHITE, 1)
    rows = [("E1", "92", "PASS"), ("E2", "88", "PASS"), ("E3", "85", "PASS")]
    for i, (a, b, g) in enumerate(rows):
        yy = 176 + i * 62
        _draw_text(c, 130, yy, a, _WHITE, 1)
        _draw_text(c, 250, yy, b, _WHITE, 1)
        _draw_text(c, 380, yy, g, _GREEN, 1)
    # KPI 条形图
    kpis = [("T1", 96), ("T2", 130), ("T3", 78)]
    for i, (name, hh) in enumerate(kpis):
        x0 = 600 + i * 110
        _bar(c, x0, 400 - hh, 60, hh, [_BLUE, _GOLD, _GREEN][i])
        _draw_text(c, x0 + 18, 406, name, _WHITE, 1)
    _draw_text(c, 600, 424, "KPI MET", _GREEN, 2)
    _subtitle_bar(c, "REVIEW BOARD  SCORE / GATE / KPI", 15, 6)
    return c


def _s7_end_1():
    c = _blank()
    _header(c, "FINAL")
    _draw_text(c, 300, 150, "ALL GREEN", _GREEN, 6)
    _draw_text(c, 280, 260, "125 TESTS  0 FAIL", _WHITE, 3)
    _draw_text(c, 170, 330, "0-DEP  OFFLINE  DETERMINISTIC", _GOLD, 2)
    _subtitle_bar(c, "125 TESTS ALL GREEN  0-DEP / OFFLINE / DETERMINISTIC", 16, 7)
    return c


def _s7_end_2():
    c = _blank()
    _header(c, "ONE-CLICK INSTALL")
    plats = [("WIN", "POWERSHELL", _BLUE), ("MAC", "BASH", _GREEN), ("LINUX", "BASH", _GOLD)]
    for i, (name, cmd, color) in enumerate(plats):
        x0 = 100 + i * 270
        _card(c, x0, 150, x0 + 220, 330, (22, 42, 66), color, 3)
        _draw_text(c, x0 + 70, 200, name, color, 3)
        _draw_text(c, x0 + 50, 270, cmd, _WHITE, 2)
    _draw_text(c, 300, 400, "run.ps1 / run.sh", _GREEN, 2)
    _subtitle_bar(c, "WIN / MAC / LINUX  ONE-CLICK INSTALL", 17, 7)
    return c


# ---------------------------------------------------------------- 场景编排
SCENES = [
    # (绘制函数, 场景号, 场景名, 英文字幕, 中文旁白)
    (_s1_open_1, 1, "OPENING", "REGIONAL INDUSTRY AI ENABLEMENT PHASE-1",
     "以区域特色产业 AI 赋能为主线，聚焦珠宝与木作两大行业。"),
    (_s1_open_2, 1, "OPENING", "TWO INDUSTRIES  JEWELRY + WOOD",
     "开场确立双行业定位：珠宝与木作。"),
    (_s2_digital_1, 2, "INDUSTRY DIGITALIZATION", "DUAL-INDUSTRY PROFILES  JEWELRY / WOOD",
     "双行业配置一键切换：珠宝与木作的工艺规则、设备能力沉淀为数据。"),
    (_s2_digital_2, 2, "INDUSTRY DIGITALIZATION", "CRAFT RULES  MFG + EQUIPMENT AS DATA",
     "工艺规则与设备能力以数据表达，支撑可制造性判定。"),
    (_s2_digital_3, 2, "INDUSTRY DIGITALIZATION", "MFG 10/10  MOTIF AUTH PASS",
     "可制造性评估 10/10 通过，纹样授权校验 PASS。"),
    (_s3_enterprise_1, 3, "ENTERPRISE AI SERVICE LAYER", "AI SERVICE LAYER  6 COMPONENT REGISTRY",
     "企业 AI 服务层：六大组件注册表。"),
    (_s3_enterprise_2, 3, "ENTERPRISE AI SERVICE LAYER", "ONE-ENTERPRISE-ONE-PROFILE + FDE HANDBOOK",
     "一企一档企业档案，FDE 驻企手册五章十二项上线清单。"),
    (_s4_export_1, 4, "GO-GLOBAL GROWTH STACK", "3-LANG SITES  ZH / EN / DE",
     "出海增长栈：中英德三语站点生成。"),
    (_s4_export_2, 4, "GO-GLOBAL GROWTH STACK", "SEO PASS  SEARCH / META / MOBILE",
     "SEO 检查全部 PASS。"),
    (_s4_export_3, 4, "GO-GLOBAL GROWTH STACK", "INQUIRY -> SCORE -> SLA -> QUOTE",
     "询盘进入 CRM 闭环：自动打分、SLA 追踪、报价流程。"),
    (_s5_ip_1, 5, "CULTURAL IP PIPELINE", "DUAL GUARDIANS  WENJIAN + GONGHENG",
     "文化 IP 管线：文鉴内容守护、工衡技术守护。"),
    (_s5_ip_2, 5, "CULTURAL IP PIPELINE", "SHORT DRAMA EPISODE  ORIGINAL VISUAL ASSETS",
     "短剧样片帧，原创视觉资产。"),
    (_s5_ip_3, 5, "CULTURAL IP PIPELINE", "LICENSE MATRIX  IP / DERIVATIVE / CONTEST",
     "授权矩阵三类授权全部达标。"),
    (_s6_contest_1, 6, "CONTEST COMMUNICATION", "CONTEST 3 TRACKS  SCORE / GATE",
     "赛事传播：设计、工艺、故事三赛道。"),
    (_s6_contest_2, 6, "CONTEST COMMUNICATION", "REVIEW BOARD  SCORE / GATE / KPI",
     "评审计分、打样门禁与 KPI 看板全达标。"),
    (_s7_end_1, 7, "CLOSING", "125 TESTS ALL GREEN  0-DEP / OFFLINE / DETERMINISTIC",
     "125 项测试全绿，零第三方依赖、离线、确定性。"),
    (_s7_end_2, 7, "CLOSING", "WIN / MAC / LINUX  ONE-CLICK INSTALL",
     "三平台一键安装，交付即用。"),
]

_CONTENT_DELAY = 700
_TRANS_DELAY = 250


def main():
    root = os.path.dirname(_SCRIPT_DIR)
    out_dir = os.path.join(root, "output", "demo_video")
    os.makedirs(out_dir, exist_ok=True)

    frames = []
    delays = []
    notes = []

    # 内容帧 + 场景间交叉淡化过渡帧
    for idx, (fn, scene, scene_name, caption, zh) in enumerate(SCENES):
        canvas = fn()
        frames.append(canvas)
        delays.append(_CONTENT_DELAY)
        notes.append({
            "frame": len(frames),
            "kind": "content",
            "scene": scene,
            "scene_name": scene_name,
            "caption": caption,
            "zh": zh,
        })
        if idx < len(SCENES) - 1:
            nxt = SCENES[idx + 1][0]()
            frames.append(_blend(canvas, nxt, 0.5))
            delays.append(_TRANS_DELAY)
            notes.append({
                "frame": len(frames),
                "kind": "transition",
                "scene": scene,
                "scene_name": scene_name,
                "caption": caption,
                "zh": zh,
            })

    gif = _gif_encode(frames, delays)
    gif_path = os.path.join(out_dir, "demo_v2.gif")
    with open(gif_path, "wb") as f:
        f.write(gif)

    meta = {
        "title": "ClawHunt #1724 路演演示样片 v2（区域特色产业 AI 赋能一期）",
        "tool": "make_demo_video.py --theme pitch",
        "width": W,
        "height": H,
        "frames": len(frames),
        "gif_bytes": len(gif),
        "scene_count": 7,
        "notes": notes,
    }
    notes_path = os.path.join(out_dir, "frames_v2_notes.json")
    with open(notes_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(json.dumps({"gif_path": gif_path, "bytes": len(gif), "frames": len(frames),
                      "notes_path": notes_path}, ensure_ascii=False))
    return 0 if len(gif) > 0 else 1


# ---------------------------------------------------------------- GIF89a 编码（960x540 参数化）
def _gif_encode(frames, delays):
    all_colors = set()
    for fr in frames:
        for row in fr:
            for px in row:
                all_colors.add(tuple(px))

    if len(all_colors) <= 256:
        palette = sorted(all_colors)
        lut = {c: i for i, c in enumerate(palette)}
    else:
        buckets = {}
        for color in all_colors:
            key = ((color[0] >> 5) << 5) | ((color[1] >> 5) << 2) | (color[2] >> 6)
            buckets.setdefault(key, color)
        palette = [buckets[k] for k in sorted(buckets)]
        rep_idx = {c: i for i, c in enumerate(palette)}
        lut = {}
        for color in all_colors:
            key = ((color[0] >> 5) << 5) | ((color[1] >> 5) << 2) | (color[2] >> 6)
            lut[color] = rep_idx[buckets[key]]
    palette = (palette + [(0, 0, 0)] * 256)[:256]

    out = bytearray()
    out += b"GIF89a"
    out += W.to_bytes(2, "little") + H.to_bytes(2, "little")
    out += bytes([0xF7, 0, 0])
    for color in palette:
        out += bytes(color)
    out += bytes([0x21, 0xFF, 0x0B]) + b"NETSCAPE2.0" + bytes([3, 1, 0, 0]) + bytes([0])

    for fr, delay in zip(frames, delays):
        out += bytes([0x21, 0xF9, 0x04, 0x00])
        out += int(round(delay / 10)).to_bytes(2, "little")
        out += bytes([0x00, 0x00])
        out += bytes([0x2C])
        out += (0).to_bytes(2, "little") + (0).to_bytes(2, "little")
        out += W.to_bytes(2, "little") + H.to_bytes(2, "little")
        out += bytes([0x00])
        indices = [lut[tuple(px)] for row in fr for px in row]
        out += bytes([8])
        out += _lzw_pack(indices)
    out += bytes([0x3B])
    return bytes(out)


def _lzw_pack(indices):
    """经典前缀表 LZW（每步 O(1)），键为 (prefix_code, next_char)。"""
    min_code = 8
    clear = 1 << min_code
    end = clear + 1
    code_size = min_code + 1
    table = {}
    next_code = end + 1
    bitbuf = 0
    bitcnt = 0
    raw = bytearray()

    def emit(code):
        nonlocal bitbuf, bitcnt
        bitbuf |= code << bitcnt
        bitcnt += code_size
        while bitcnt >= 8:
            raw.append(bitbuf & 0xFF)
            bitbuf >>= 8
            bitcnt -= 8

    emit(clear)
    code = indices[0]
    for b in indices[1:]:
        key = (code, b)
        nxt = table.get(key)
        if nxt is not None:
            code = nxt
        else:
            emit(code)
            if next_code < 4096:
                table[key] = next_code
                next_code += 1
                if next_code > (1 << code_size) and code_size < 12:
                    code_size += 1
                if next_code >= 4096:
                    emit(clear)
                    table = {}
                    next_code = end + 1
                    code_size = min_code + 1
            code = b
    emit(code)
    emit(end)
    if bitcnt > 0:
        raw.append(bitbuf & 0xFF)
    out = bytearray()
    for i in range(0, len(raw), 255):
        chunk = raw[i:i + 255]
        out.append(len(chunk))
        out += chunk
    out.append(0)
    return bytes(out)


if __name__ == "__main__":
    sys.exit(main())
