# -*- coding: utf-8 -*-
"""ClawHunt #1724 零依赖版发布包生成脚本（从原版 prototype 重新生成去核心化发布版）。

用法:
    python scripts/make_publish.py

流程（保证发布版与原版只差“去核心”一层变换，避免手工复制差错）:
    1. 若目标 prototype_publish 已存在，先整体移动为 prototype_publish.bak_<时间戳>（不删除）；
    2. 从 prototype 全量复制到 prototype_publish（排除 __pycache__/temp/.pytest_cache/publish_stubs/*.pyc）；
    3. 剔除发布版不含的样片（Neil 换声版、demo_v2 系列、tts_voices_neil 目录）；
    4. 用 scripts/publish_stubs/ 覆盖 9 个核心模块文件为占位桩（授权强校验/可制造性/C2M 状态机/
       企业 AI 服务层/出海栈/IP 授权/样片管线/赛事判定等，均标注「中标后提供」）；
    5. 在 README.md 与 VERIFICATION.md 的 H1 标题后注入双语发布声明（带标记防重复注入）；
    6. 打包 Task1724_prototype_publish_v1.0.zip 到上级目录（zip 内顶层目录同名）。
"""
from __future__ import annotations

import fnmatch
import json
import os
import shutil
import sys
import time
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../prototype
PARENT = os.path.dirname(ROOT)                                       # .../Task1724
PUB = os.path.join(PARENT, "prototype_publish")
STUBS = os.path.join(ROOT, "scripts", "publish_stubs")
ZIP_PATH = os.path.join(PARENT, "Task1724_prototype_publish_v1.0.zip")
TOP = "Task1724_prototype_publish_v1.0"

EXCLUDE_DIRS = {"__pycache__", "temp", ".pytest_cache", "publish_stubs", ".git", ".idea"}
EXCLUDE_EXT = {".pyc"}

# 发布版剔除的样片/中间产物（相对 output/demo_video）
# 本轮按用户要求：保留正式样片 ai_demo_1080p_voice_neil_bgm_v5.mp4（供样片查看功能演示），
# 剔除 demo_v2 系列、历史版本样片、关键帧/拼接片段/拼接中间产物及私有配音。
REMOVE_GLOBS = [
    "ai_demo_1080p_voice.mp4",
    "ai_demo_1080p_voice_bgm.mp4",
    "ai_demo_1080p_voice_neil_bgm.mp4",
    "ai_demo_1080p_voice_neil_bgm_v2.mp4",
    "ai_demo_1080p_voice_neil_bgm_v3.mp4",
    "ai_demo_1080p_voice_neil_bgm_v4.mp4",
    "ai_demo_cloud.mp4",
    "demo_v2.gif",
    "demo_v2.mp4",
    "demo_v2.srt",
]
REMOVE_DIRS = ["ai_frames", "ai_frames_1080p", "temp_clips", "tts_voices", "tts_voices_neil", "_1080p_work"]

NOTICE_MARKER = "<!-- PUBLISH-NOTICE -->"

README_NOTICE = """<!-- PUBLISH-NOTICE -->
> ⚠️ **发布版声明 / PUBLISH BUILD NOTICE（防白嫖 / anti-freeloading）**：本目录为**去核心化的演示骨架（GitHub 发布版）**，与完整版（`../prototype`，本地备份基线）分离。
> This directory is a **de-cored demonstration skeleton (GitHub publish build)**, kept separate from the full build (`../prototype`, the local backup baseline).
> 已移除全部核心商业实现并替换为占位桩（stub）：授权字段强校验、可制造性评估引擎、C2M 订单状态机、企业 AI 服务层、三语站点生成/SEO/CRM 闭环、IP 授权矩阵、短剧样片生成管线、赛事评分/KPI 判定等核心逻辑**均将于中标后提供**（代码注释与运行时输出统一标注「核心实现将于中标后提供 / full implementation provided after award」）。
> All core commercial implementations have been removed and replaced with stubs: authorization field validation, manufacturability engine, C2M order state machine, enterprise AI service layer, trilingual site generation/SEO/CRM loop, IP licensing matrix, short-drama sample pipeline, contest scoring/KPI logic — **all will be provided after award** (code comments and runtime output are uniformly marked "full implementation provided after award").
> 本发布版保证可正常导入、可跑演示骨架流程，但业务结果不真实、验收指标不再全绿（tests 核心用例、verify all_green、合规六项中的审核/授权项将按预期失败）。
> This publish build is guaranteed to import cleanly and run the demo skeleton flow, but business results are not real and verification indicators are no longer all-green (core test cases, verify all_green, and the compliance audit/licensing items are expected to fail as designed).
> 约束仍为：**纯 Python 标准库 / 零第三方依赖 / 离线可运行 / 确定性输出**；全部数据为合成脱敏样例。
> Constraints remain: **pure Python standard library / zero third-party dependencies / offline deterministic runs**; all data is synthetic and anonymized.
"""

VERIFY_NOTICE = """<!-- PUBLISH-NOTICE -->
> ⚠️ **发布版声明 / PUBLISH BUILD NOTICE（防白嫖 / anti-freeloading）**：本目录为**去核心化的演示骨架（GitHub 发布版）**，完整版见 `../prototype`（本地备份基线，不随发布版分发）。
> This directory is a **de-cored demonstration skeleton (GitHub publish build)**; see `../prototype` for the full build (local backup baseline, not distributed with this publish build).
> 核心商业实现（授权强校验 / 可制造性引擎 / C2M 状态机 / 企业 AI 服务层 / 三语站点与 SEO / CRM 闭环 / IP 授权矩阵 / 短剧样片管线 / 赛事评分与 KPI）已替换为占位桩，代码注释与运行时输出统一标注「核心实现将于中标后提供 / full implementation provided after award」。
> Core commercial implementations (authorization validation / manufacturability engine / C2M state machine / enterprise AI service layer / trilingual site & SEO / CRM loop / IP licensing matrix / short-drama sample pipeline / contest scoring & KPI) have been replaced with stubs, uniformly marked "full implementation provided after award" in code comments and runtime output.
> 因此发布版验收指标不再全绿：tests 核心用例、verify all_green、合规审核/授权项按预期失败；依赖合规与文档一致性保持通过。
> Verification indicators in this publish build are therefore no longer all-green: core test cases, verify all_green, and compliance audit/licensing items fail as expected; dependency compliance and documentation consistency remain passing.
> 完整版基线记录保留在下方，供中标后对照验收。
> Full-build baseline records are kept below for post-award acceptance comparison.

### 发布版实测（2026-10-29，prototype_publish 去核心化后实跑）
### Publish Build Verification (2026-10-29, after de-coring prototype_publish)

| 序号 | 命令 | 退出码 | 发布版实测结果 |
|---|---|---|---|
| 1 | `python scripts/init_check.py` | 0 | ✅ 自检通过：29 个 py 扫描 / 第三方导入=0 / 联网导入=0 / 22 个 JSON 完整 |
| 2 | `python scripts/compliance_check.py` | 1 | ⚠️ 4/6 PASS：零第三方依赖、数据边界、开源许可、文档一致性通过；安全词表与审核拦截、IP 授权矩阵合规按预期 FAIL |
| 3 | `python demo.py` | 1 | ⚠️ 演示骨架可完整运行，核心项显示占位（评分待定 / 门禁拦截 / KPI 未达标 / 中标后提供） |
| 4 | `python tests.py` | 1 | ⚠️ Ran 125 tests：**63 通过 / 57 失败 / 5 错误**（失败为核心实现用例，按预期） |
| 5 | `python verify.py` | 1 | ⚠️ `all_green: false`：可制造性 0/10、SEO false、CRM 0/3、样片帧 0、KPI false（核心占位） |
| 6 | `python start.py` | — | 未列入发布版实测（统一入口，行为同 demo/tests 汇总） |
| 7 | `python server.py --host 0.0.0.0 --port 8000` | 0 | ✅ 服务实测（2026-10-31）：/api/health、/api/industries、/api/components/jewelry、/、/assets/*、/media/ai_demo_1080p_voice_neil_bgm_v5.mp4 全部 200；web 工作台 7 页签与三语切换正常 |
| 8 | `python scripts/make_publish.py` | 0 | ✅ 重生成发布版（2026-10-31）：保留正式样片 v5，剔除 demo_v2/拼接中间产物/私有配音；zip 107 文件 / 15,625,990 字节 |

| # | Command | Exit | Publish build result |
|---|---|---|---|
| 1 | `python scripts/init_check.py` | 0 | ✅ Init check passed: 29 py files scanned / third-party imports=0 / network imports=0 / 22 JSONs valid |
| 2 | `python scripts/compliance_check.py` | 1 | ⚠️ 4/6 PASS: zero third-party deps, data boundary, open-source license, doc consistency pass; sensitive-word/audit block and IP licensing matrix FAIL as expected |
| 3 | `python demo.py` | 1 | ⚠️ Demo skeleton runs fully; core items show placeholders (score pending / gate blocked / KPI unmet / provided after award) |
| 4 | `python tests.py` | 1 | ⚠️ Ran 125 tests: **63 passed / 57 failed / 5 errors** (failures are core-implementation cases, as expected) |
| 5 | `python verify.py` | 1 | ⚠️ `all_green: false`: manufacturability 0/10, SEO false, CRM 0/3, sample frames 0, KPI false (core placeholders) |
| 6 | `python start.py` | — | Not included in the publish-build run (unified entry; behaves as demo/tests summary) |
| 7 | `python server.py --host 0.0.0.0 --port 8000` | 0 | ✅ Server measurement (2026-10-31): /api/health, /api/industries, /api/components/jewelry, /, /assets/*, /media/ai_demo_1080p_voice_neil_bgm_v5.mp4 all 200; web workbench 7 tabs and tri-lingual switching OK |
| 8 | `python scripts/make_publish.py` | 0 | ✅ Publish build regenerated (2026-10-31): keeps official sample v5, excludes demo_v2/stitch intermediates/private voices; zip 107 files / 15,625,990 bytes |
"""


def _should_ignore(full: str, is_dir: bool, demo_root: str | None) -> bool:
    """单个条目是否应排除（目录名 / 扩展名 / 样片剔除规则）。"""
    if is_dir:
        if os.path.basename(full) in EXCLUDE_DIRS:
            return True
        if demo_root:
            rel = os.path.relpath(full, demo_root)
            if not rel.startswith("..") and rel.split(os.sep)[0] in REMOVE_DIRS:
                return True
        return False
    if os.path.splitext(full)[1] in EXCLUDE_EXT:
        return True
    if demo_root:
        rel = os.path.relpath(full, demo_root)
        if not rel.startswith("..") and any(fnmatch.fnmatch(os.path.basename(full), pat) for pat in REMOVE_GLOBS):
            return True
    return False


def _ignore(src, names):
    """copytree 忽略规则（含样片剔除）。"""
    ignored = []
    demo_root = os.path.join(ROOT, "output", "demo_video")
    for n in names:
        full = os.path.join(src, n)
        if _should_ignore(full, os.path.isdir(full), demo_root):
            ignored.append(n)
    return set(ignored)


def rebuild_publish() -> str | None:
    """重建 prototype_publish。返回备份目录名（若无备份返回 None）。"""
    backup = None
    if os.path.exists(PUB):
        backup = PUB + ".bak_" + time.strftime("%Y%m%d_%H%M%S")
        shutil.move(PUB, backup)
    shutil.copytree(ROOT, PUB, ignore=_ignore)
    return backup


def apply_stubs() -> list[str]:
    """用 scripts/publish_stubs/ 覆盖核心模块为占位桩。"""
    applied = []
    for base, _dirs, files in os.walk(STUBS):
        for f in sorted(files):
            src = os.path.join(base, f)
            rel = os.path.relpath(src, STUBS)
            dst = os.path.join(PUB, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            applied.append(rel.replace(os.sep, "/"))
    return applied


def inject_notice(rel_path: str, notice: str):
    """在中英双 H1 标题之后注入发布声明（已含标记则跳过）。"""
    full = os.path.join(PUB, rel_path)
    if not os.path.isfile(full):
        return False
    text = open(full, encoding="utf-8").read()
    if NOTICE_MARKER in text:
        return False
    lines = text.splitlines(keepends=True)
    idx = None
    for i, line in enumerate(lines):
        if line.startswith("# "):
            idx = i
            break
    if idx is None:
        return False
    # 若下一行也是同级 H1（英文标题），插入点放到其后
    insert_at = idx + 1
    if insert_at < len(lines) and lines[insert_at].startswith("# "):
        insert_at += 1
    while insert_at < len(lines) and lines[insert_at].strip() == "":
        insert_at += 1
    block = notice + "\n"
    lines.insert(insert_at, block)
    open(full, "w", encoding="utf-8", newline="").writelines(lines)
    return True


def pack_zip() -> dict:
    count = 0
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for base, dirs, files in os.walk(PUB):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in sorted(files):
                if os.path.splitext(f)[1] in EXCLUDE_EXT:
                    continue
                full = os.path.join(base, f)
                arc = os.path.join(TOP, os.path.relpath(full, PUB))
                zf.write(full, arc)
                count += 1
    return {"zip_path": ZIP_PATH, "bytes": os.path.getsize(ZIP_PATH), "files": count}


PUBLISH_SAMPLES_SECTION = """### 8.1 发布版样片（正式样片保留）
### 8.1 Publish-Edition Sample (Official Sample Kept)

- **产物（保留正式样片）**：
  **Artifacts (official sample kept)**:
  - `output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4`：**正式演示样片（发布版保留）**，1920x1080、H.264（yuv420p、faststart）、AI 配音、约 15 MB；Web 工作台 C 页签"申请查看样片（演示）"弹窗播放 `/media/ai_demo_1080p_voice_neil_bgm_v5.mp4`（部署后经 8000 端口访问）。
    - `output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4`: **official demo sample (kept in publish edition)**, 1920x1080, H.264 (yuv420p, faststart), AI voice-over, ~15 MB; tab C "Request Sample (Demo)" modal plays `/media/ai_demo_1080p_voice_neil_bgm_v5.mp4` (served on port 8000 after deployment).
- **剔除项（发布版不含）**：demo_v2 系列（demo_v2.gif/mp4/srt）、历史版本样片（无版本号及 v2/v3/v4 等 neil 版、voice/bgm/cloud 版）、关键帧（ai_frames/、ai_frames_1080p/）、拼接片段（temp_clips/）、拼接中间产物（_1080p_work/）、私有配音（tts_voices/、tts_voices_neil/）一律不进入发布版；若样片缺失，前端显示"演示样片按防白嫖约定隐藏，中标后提供"占位。
  **Excluded (not in publish edition)**: demo_v2 series (demo_v2.gif/mp4/srt), historical sample versions (unversioned and v2/v3/v4 neil builds, voice/bgm/cloud builds), keyframes (ai_frames/, ai_frames_1080p/), stitching clips (temp_clips/), stitching intermediates (_1080p_work/), private voices (tts_voices/, tts_voices_neil/) — none enter the publish edition; if a sample is missing, the frontend shows the "demo samples hidden per anti-free-ride agreement; provided after award" placeholder.
- **说明**：本轮按用户要求调整防白嫖约定——发布版**保留正式样片**（供样片查看功能演示），其余私有资产仍全部剔除；完整版（含全部样片与私有资产）本地保留，绝不对外发布。
  **Notes**: per this round's client request, the anti-free-ride convention is adjusted — the publish edition **keeps the official sample** (for the sample-viewing feature) while all other private assets remain excluded; the full edition (all samples & private assets) stays local and is never published.

### 8.2 发布压缩包
### 8.2 Release Archive

- **产物**：`D:\\projects\\clawhunt\\03_proposal\\Task1724\\Task1724_prototype_publish_v1.0.zip`（zip 内顶层目录 `Task1724_prototype_publish_v1.0/`，去核心化发布版，含正式样片 v5）。
  **Artifacts**: `D:\\projects\\clawhunt\\03_proposal\\Task1724\\Task1724_prototype_publish_v1.0.zip` (top-level directory inside the zip: `Task1724_prototype_publish_v1.0/`, de-cored publish build including official sample v5).
- **生成方式**：`python scripts/make_publish.py`（从 `../prototype` 原版重新生成，保证发布版与原版只差去核心化 + 资产剔除一层变换）。
  **Generation**: `python scripts/make_publish.py` (regenerated from the `../prototype` full build, ensuring the publish build differs from the full build only by the de-coring + asset-exclusion transform).
- **样片说明**：发布包内样片为 **`output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4`（1920x1080 AI 配音正式样片）**；demo_v2 系列及历史版本已移除，不再分发。
  **Sample notes**: the sample inside the publish package is **`output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4` (1920x1080, AI voice-over, official)**; the demo_v2 series and historical versions have been removed and are no longer distributed.

*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
"""


def rewrite_samples_section(rel_path: str = "README.md") -> bool:
    """将发布版 README 第 8 章（样片/发布包说明）替换为发布版专属双语章节。"""
    full = os.path.join(PUB, rel_path)
    if not os.path.isfile(full):
        return False
    text = open(full, encoding="utf-8").read()
    lines = text.splitlines(keepends=True)
    start = None
    for i, line in enumerate(lines):
        if line.startswith("### 8.1"):
            start = i
            break
    if start is None:
        return False
    new_lines = lines[:start] + [PUBLISH_SAMPLES_SECTION]
    open(full, "w", encoding="utf-8", newline="").writelines(new_lines)
    return True


def main() -> int:
    backup = rebuild_publish()
    applied = apply_stubs()
    readme_injected = inject_notice("README.md", README_NOTICE)
    verify_injected = inject_notice("VERIFICATION.md", VERIFY_NOTICE)
    samples_rewritten = rewrite_samples_section("README.md")
    pkg = pack_zip()
    print(json.dumps({
        "backup": backup,
        "stubs_applied": applied,
        "readme_notice": readme_injected,
        "verification_notice": verify_injected,
        "samples_rewritten": samples_rewritten,
        "package": pkg,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
