"""ClawHunt #1724 交付仓库 —— 合规检查（纯标准库，离线，确定性）。

对齐验收 10（合规）。检查项：
1. 零第三方依赖复核（复用 init_check 扫描结果）。
2. 安全词表与审核拦截：module_c 审核链路正反例。
3. IP 授权矩阵合规：授权类型/衍生品/非独占声明/AI 标识/审批门禁。
4. 数据边界与隐私声明：数据文件脱敏声明、真实 PII 正则扫描。
5. 开源许可声明：README 声明零第三方依赖与开源许可。
6. 文档一致性：README 中列举的入口命令与仓库实现一一对应。

用法：python scripts/compliance_check.py
"""
import json
import os
import re
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import scripts.init_check as init_check  # noqa: E402


def _check_dependencies(report):
    py_files = init_check._collect_py_files(_ROOT)
    third_party, network_hits, problems = init_check._scan_imports(py_files)
    ok = not third_party and not network_hits and not problems
    report["items"].append({
        "check": "零第三方依赖与离线",
        "ok": ok,
        "detail": "第三方导入={}，联网导入={}，源码问题={}".format(
            sorted(third_party), sorted(network_hits), len(problems)),
    })
    return ok


def _check_safety_review(report):
    from module_c.license import load_safety_words, review_content
    sw = load_safety_words()
    passed = 0
    checks = []
    banned_hit = review_content("开光保平安", safety=sw, meta={"ai_marking": True})
    checks.append(("禁用词拦截", banned_hit["ok"] is False and bool(banned_hit["hits"])))
    passed += checks[-1][1]
    brand = review_content("联名 nike swoosh 风格", safety=sw, meta={"ai_marking": True})
    checks.append(("品牌词拦截", brand["ok"] is False and bool(brand["brand_hits"])))
    passed += checks[-1][1]
    no_mark = review_content("灯塔故事", safety=sw, meta={})
    checks.append(("AI 标识门禁", no_mark["ok"] is False and no_mark["marking_ok"] is False))
    passed += checks[-1][1]
    marked = review_content("灯塔故事。AI 生成。", safety=sw, meta={"ai_marking": True})
    checks.append(("合规内容放行", marked["ok"] is True and marked["marking_ok"] is True))
    passed += checks[-1][1]
    ok = passed == len(checks)
    report["items"].append({
        "check": "安全词表与审核拦截",
        "ok": ok,
        "detail": "; ".join("{}:{}".format(n, "PASS" if v else "FAIL") for n, v in checks),
    })
    return ok


def _check_license_matrix(report):
    from module_c.license import load_matrix, list_derivative_specs
    matrix = load_matrix()
    checks = []
    checks.append(("非独占声明", bool(matrix.get("non_exclusive_clause"))))
    checks.append(("AI 标识要求", bool(matrix.get("ai_generated_marking_required"))))
    licenses = matrix.get("license_matrix", [])
    checks.append(("授权类型数=3", len(licenses) == 3))
    license_ok = all(
        isinstance(l, dict) and {"name", "scope", "term_months", "royalty_rate",
                                 "approval_gate"} <= set(l.keys())
        for l in licenses
    )
    checks.append(("授权条目字段完整", license_ok))
    deriv = list_derivative_specs()
    checks.append(("衍生品四类", len(deriv) == 4))
    deriv_ok = all(isinstance(d, dict) and "category" in d and "ai_marking" in d
                   for d in deriv)
    checks.append(("衍生品字段完整", deriv_ok))
    checks.append(("审批工作流存在", bool(matrix.get("approval_workflow"))))
    ok = all(v for _n, v in checks)
    report["items"].append({
        "check": "IP 授权矩阵合规",
        "ok": ok,
        "detail": "; ".join("{}:{}".format(n, "PASS" if v else "FAIL") for n, v in checks),
    })
    return ok


_PII_PATTERNS = [
    ("手机号", re.compile(r"1[3-9]\d{9}")),
    ("身份证", re.compile(r"\d{17}[\dXx]")),
    ("银行卡", re.compile(r"\d{16,19}")),
    ("邮箱", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
]


def _check_data_boundary(report):
    from module_c.characters import load_characters
    from module_b.fde_handbook import load_enterprise_profile
    chars = load_characters()
    profile = load_enterprise_profile()
    checks = []
    text = str(chars.get("non_exclusive_clause", ""))
    checks.append(("IP 原型非独占声明",
                   "非独占" in text or "不被声明为独占权利" in text
                   or ("不" in text and "独占" in text)))
    checks.append(("AI 生成标识声明", bool(chars.get("ai_generated_note"))))
    checks.append(("一企一档脱敏名", "脱敏" in profile.get("enterprise_name", "")))
    checks.append(("一企一档数据边界", bool(profile.get("data_boundaries"))))

    pii_hits = {}
    for root, _dirs, files in os.walk(os.path.join(_ROOT, "module_a"),
                                      topdown=True):
        for name in files:
            if not name.endswith(".json"):
                continue
            text = open(os.path.join(root, name), encoding="utf-8").read()
            for label, pat in _PII_PATTERNS:
                if pat.search(text):
                    pii_hits.setdefault(label, []).append(name)
    checks.append(("无真实 PII 样例", not pii_hits))
    ok = all(v for _n, v in checks)
    report["items"].append({
        "check": "数据边界与隐私声明",
        "ok": ok,
        "detail": "; ".join("{}:{}".format(n, "PASS" if v else "FAIL") for n, v in checks)
                  + ("；PII 命中={}".format(pii_hits) if pii_hits else ""),
    })
    return ok


def _check_license_statement(report):
    readme = os.path.join(_ROOT, "README.md")
    checks = []
    if os.path.exists(readme):
        text = open(readme, encoding="utf-8").read()
        checks.append(("开源许可章节", ("开源许可" in text or "许可" in text)))
        checks.append(("零第三方依赖声明", "零第三方依赖" in text or "纯标准库" in text))
        checks.append(("离线声明", "离线" in text))
        checks.append(("脱敏/合成数据声明", "脱敏" in text or "合成" in text))
    else:
        checks.append(("README 存在", False))
    ok = all(v for _n, v in checks)
    report["items"].append({
        "check": "开源许可与声明",
        "ok": ok,
        "detail": "; ".join("{}:{}".format(n, "PASS" if v else "FAIL") for n, v in checks),
    })
    return ok


def _check_doc_consistency(report):
    readme = os.path.join(_ROOT, "README.md")
    problems = []
    if not os.path.exists(readme):
        problems.append("README.md 缺失")
    else:
        text = open(readme, encoding="utf-8").read()
        # README 代码块中出现的 python <脚本> 形式命令
        cmds = re.findall(r"python(?:3)?\s+([\w./\\-]+\.py)", text)
        cmds = sorted(set(cmds))
        for cmd in cmds:
            p = os.path.join(_ROOT, cmd.replace("/", os.sep))
            if not os.path.exists(p):
                problems.append("README 提及但缺失: {}".format(cmd))
        # README 提及的入口脚本应全部存在
        for entry in ("start.py", "run.ps1", "run.sh"):
            if entry in text and not os.path.exists(os.path.join(_ROOT, entry)):
                problems.append("README 提及但缺失: {}".format(entry))
        if not cmds:
            problems.append("README 未列出可复跑命令（python <脚本>.py）")
    ok = not problems
    report["items"].append({
        "check": "文档一致性（README 与实现对应）",
        "ok": ok,
        "detail": "命令数={}；问题={}".format(len(cmds), problems or "无"),
    })
    return ok


def main():
    report = {
        "tool": "compliance_check",
        "python_version": "{}.{}.{}".format(*sys.version_info[:3]),
        "items": [],
    }
    results = [
        _check_dependencies(report),
        _check_safety_review(report),
        _check_license_matrix(report),
        _check_data_boundary(report),
        _check_license_statement(report),
        _check_doc_consistency(report),
    ]
    report["all_green"] = all(results)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["all_green"] else 1


if __name__ == "__main__":
    sys.exit(main())
