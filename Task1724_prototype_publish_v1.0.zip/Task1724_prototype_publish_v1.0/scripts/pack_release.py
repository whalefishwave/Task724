"""ClawHunt #1724 prototype 发布打包脚本（纯标准库，离线，确定性）。

把仓库根目录打包为 Task1724_prototype_v1.0.zip（zip 内顶层目录同名），
输出到上一级目录（D:\\projects\\clawhunt\\03_proposal\\Task1724\\）。

排除规则：__pycache__ 目录、*.pyc、名为 temp 的目录。
其余内容（含 output/demo_video 样片）全部保留。
"""
import json
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOP = "Task1724_prototype_v1.0"
ZIP_PATH = os.path.join(os.path.dirname(ROOT), TOP + ".zip")
EXCLUDE_DIRS = {"__pycache__", "temp"}
EXCLUDE_EXT = {".pyc"}


def main():
    count = 0
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for base, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in sorted(files):
                if os.path.splitext(f)[1] in EXCLUDE_EXT:
                    continue
                full = os.path.join(base, f)
                arc = os.path.join(TOP, os.path.relpath(full, ROOT))
                zf.write(full, arc)
                count += 1
    size = os.path.getsize(ZIP_PATH)
    print(json.dumps({"zip_path": ZIP_PATH, "bytes": size, "files": count}))
    return 0 if count > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
