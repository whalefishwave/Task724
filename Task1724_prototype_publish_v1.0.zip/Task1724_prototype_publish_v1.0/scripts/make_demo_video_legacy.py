"""ClawHunt #1724 投标演示样片生成器（纯标准库，离线，确定性）。

输入：output/episode_demo/frame_001..008.svg（模块 C 短剧 8 帧）。
输出：output/demo_video/demo.gif（GIF89a 动画）+ frames_notes.json（帧说明）。

流程：
1. 手写 SVG 光栅化器（rect/circle/polygon/path 直线/text-ASCII/g transform），
   把 SVG 帧渲染为 320x240 RGB 位图（零第三方依赖）。
2. 追加模块 A/B/D 转场帧与结尾帧（像素级绘制 + 内置 5x7 ASCII 点阵标题）。
3. 手写 GIF89a 编码器（全局色表 + LZW 压缩 + Netscape 循环），合成动画。

确定性：无随机源；帧顺序、延迟、调色板完全由输入决定。
"""
import json
import os
import re
import sys

_WIDTH = 320
_HEIGHT = 240
_BG = (15, 28, 46)  # #0f1c2e


# ---------------------------------------------------------------- SVG 光栅化
def _parse_num(s):
    return float(s)


class _Svg:
    def __init__(self, text):
        self.text = text
        self.els = self._parse(text)

    def _parse(self, text):
        els = []
        transforms = [None]
        for m in re.finditer(
            r"<(\w+)([^>]*?)(/>|>)", text, re.S
        ):
            tag, attrs_txt, closing = m.group(1), m.group(2), m.group(3)
            attrs = dict(re.findall(r"([\w:-]+)=\"([^\"]*)\"", attrs_txt))
            if tag == "g":
                t = attrs.get("transform", "")
                tm = re.match(r"translate\(([\d.+-]+)[,\s]+([\d.+-]+)\)\s*scale\(([\d.+-]+)\)", t)
                if tm:
                    transforms.append((float(tm.group(1)), float(tm.group(2)), float(tm.group(3))))
                else:
                    transforms.append(None)
                continue
            if tag in ("rect", "circle", "polygon", "path", "text"):
                if tag == "text":
                    body = re.search(r"<text[^>]*>([^<]*)</text>", text[m.end():]) if closing == ">" else None
                    content = body.group(1) if body else ""
                else:
                    content = ""
                els.append((tag, attrs, content, transforms[-1]))
        return els

    def render(self, w=_WIDTH, h=_HEIGHT):
        canvas = [[_BG for _ in range(w)] for _ in range(h)]
        for tag, attrs, content, tr in self.els:
            dx = dy = 1.0
            if tr:
                dx, dy, sc = tr
            else:
                sc = 1.0
            if tag == "rect":
                self._rect(canvas, attrs, dx, dy, sc)
            elif tag == "circle":
                self._circle(canvas, attrs, dx, dy, sc)
            elif tag == "polygon":
                self._polygon(canvas, attrs, dx, dy, sc)
            elif tag == "path":
                self._path(canvas, attrs, dx, dy, sc)
            elif tag == "text":
                self._text(canvas, attrs, content, dx, dy, sc)
        return canvas

    @staticmethod
    def _color(attrs, key, default=None):
        val = attrs.get(key, default)
        if val is None:
            return None
        if val.startswith("#"):
            v = val[1:]
            if len(v) == 3:
                return (int(v[0], 16) * 17, int(v[1], 16) * 17, int(v[2], 16) * 17)
            return (int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))
        m = re.match(r"rgba\((\d+)[,\s]+(\d+)[,\s]+(\d+)[,\s]+([\d.]+)\)", val)
        if m:
            return tuple([int(m.group(1)), int(m.group(2)), int(m.group(3)), float(m.group(4))])
        return (255, 255, 255)

    @staticmethod
    def _blend(base, fg):
        if len(fg) == 4:
            a = fg[3]
            return tuple(int(round(base[i] * (1 - a) + fg[i] * a)) for i in range(3))
        return fg[:3]

    def _set(self, canvas, x, y, fg, dx, dy, sc):
        px = int(round(x * sc + dx))
        py = int(round(y * sc + dy))
        if 0 <= px < _WIDTH and 0 <= py < _HEIGHT:
            canvas[py][px] = self._blend(canvas[py][px], fg)

    def _rect(self, canvas, attrs, dx, dy, sc):
        x0, y0 = _parse_num(attrs["x"]), _parse_num(attrs["y"])
        w, h = _parse_num(attrs["width"]), _parse_num(attrs["height"])
        rx = _parse_num(attrs.get("rx", "0"))
        fill = self._color(attrs, "fill", None)
        stroke = self._color(attrs, "stroke", None)
        sw = _parse_num(attrs.get("stroke-width", "1"))
        x1, y1 = x0 + w, y0 + h
        for yy in range(int(y0), int(y1) + 1):
            for xx in range(int(x0), int(x1) + 1):
                # 圆角内缩判断
                if rx > 0:
                    cx = min(max(xx, x0 + rx), x1 - rx)
                    cy = min(max(yy, y0 + rx), y1 - rx)
                    if (xx - cx) ** 2 + (yy - cy) ** 2 > rx * rx:
                        continue
                inside = (x0 + sw / 2 <= xx <= x1 - sw / 2 and y0 + sw / 2 <= yy <= y1 - sw / 2)
                if fill is not None and inside:
                    self._set(canvas, xx, yy, fill, dx, dy, sc)
                if stroke is not None and not inside and (
                    abs(xx - x0) <= sw / 2 or abs(xx - x1) <= sw / 2
                    or abs(yy - y0) <= sw / 2 or abs(yy - y1) <= sw / 2
                ):
                    self._set(canvas, xx, yy, stroke, dx, dy, sc)

    def _circle(self, canvas, attrs, dx, dy, sc):
        cx, cy = _parse_num(attrs["cx"]), _parse_num(attrs["cy"])
        r = _parse_num(attrs["r"])
        fill = self._color(attrs, "fill", None)
        stroke = self._color(attrs, "stroke", None)
        sw = _parse_num(attrs.get("stroke-width", "1"))
        for yy in range(int(cy - r), int(cy + r) + 1):
            for xx in range(int(cx - r), int(cx + r) + 1):
                d2 = (xx - cx) ** 2 + (yy - cy) ** 2
                if fill is not None and d2 <= (r - sw / 2) ** 2:
                    self._set(canvas, xx, yy, fill, dx, dy, sc)
                if stroke is not None and (r - sw / 2) ** 2 < d2 <= (r + sw / 2) ** 2:
                    self._set(canvas, xx, yy, stroke, dx, dy, sc)

    def _line(self, canvas, x0, y0, x1, y1, color, sw, dx, dy, sc):
        steps = max(int(abs(x1 - x0)), int(abs(y1 - y0)), 1) * 2
        for i in range(steps + 1):
            t = i / steps
            x, y = x0 + (x1 - x0) * t, y0 + (y1 - y0) * t
            for oy in range(-int(sw / 2), int(sw / 2) + 1):
                for ox in range(-int(sw / 2), int(sw / 2) + 1):
                    self._set(canvas, x + ox, y + oy, color, dx, dy, sc)

    def _polygon(self, canvas, attrs, dx, dy, sc):
        pts = [float(v) for v in re.split(r"[\s,]+", attrs["points"].strip())]
        xs = pts[0::2]
        ys = pts[1::2]
        fill = self._color(attrs, "fill", None)
        stroke = self._color(attrs, "stroke", None)
        sw = _parse_num(attrs.get("stroke-width", "1"))
        xmin, xmax = int(min(xs)), int(max(xs))
        ymin, ymax = int(min(ys)), int(max(ys))
        n = len(xs)
        if fill is not None:
            for yy in range(ymin, ymax + 1):
                ins = 0
                crossings = []
                for i in range(n):
                    xa, ya = xs[i], ys[i]
                    xb, yb = xs[(i + 1) % n], ys[(i + 1) % n]
                    if (ya <= yy < yb) or (yb <= yy < ya):
                        tx = xa + (yy - ya) * (xb - xa) / (yb - ya)
                        crossings.append(tx)
                crossings.sort()
                for k in range(0, len(crossings) - 1, 2):
                    for xx in range(int(crossings[k]), int(crossings[k + 1]) + 1):
                        self._set(canvas, xx, yy, fill, dx, dy, sc)
        if stroke is not None:
            for i in range(n):
                self._line(canvas, xs[i], ys[i], xs[(i + 1) % n], ys[(i + 1) % n], stroke, sw, dx, dy, sc)

    def _path(self, canvas, attrs, dx, dy, sc):
        d = attrs.get("d", "")
        stroke = self._color(attrs, "stroke", None)
        sw = _parse_num(attrs.get("stroke-width", "1"))
        if stroke is None:
            return
        cmds = re.findall(r"([ML])\s*([\d.+-]+)[\s,]+([\d.+-]+)", d)
        for i in range(1, len(cmds)):
            if cmds[i - 1][0] in "ML" and cmds[i][0] in "ML":
                self._line(canvas, float(cmds[i - 1][1]), float(cmds[i - 1][2]),
                           float(cmds[i][1]), float(cmds[i][2]), stroke, sw, dx, dy, sc)

    # 5x7 ASCII 点阵（A-Z, 0-9, 空格, . - / + : · |）
    _FONT = {
        'A': ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
        'B': ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
        'C': ["01111", "10000", "10000", "10000", "10000", "10000", "01111"],
        'D': ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
        'E': ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
        'F': ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
        'G': ["01111", "10000", "10000", "10111", "10001", "10001", "01111"],
        'H': ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
        'I': ["11111", "00100", "00100", "00100", "00100", "00100", "11111"],
        'J': ["00111", "00010", "00010", "00010", "00010", "10010", "01100"],
        'K': ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
        'L': ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
        'M': ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
        'N': ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
        'O': ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
        'P': ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
        'Q': ["01110", "10001", "10001", "10001", "10101", "10010", "01101"],
        'R': ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
        'S': ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
        'T': ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
        'U': ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
        'V': ["10001", "10001", "10001", "10001", "10001", "01010", "00100"],
        'W': ["10001", "10001", "10001", "10101", "10101", "11011", "10001"],
        'X': ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
        'Y': ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
        'Z': ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
        '0': ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
        '1': ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
        '2': ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
        '3': ["11111", "00010", "00100", "00010", "00001", "10001", "01110"],
        '4': ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
        '5': ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
        '6': ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
        '7': ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
        '8': ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
        '9': ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
        ' ': ["00000", "00000", "00000", "00000", "00000", "00000", "00000"],
        '.': ["00000", "00000", "00000", "00000", "00000", "00110", "00110"],
        '-': ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
        '/': ["00001", "00010", "00010", "00100", "01000", "01000", "10000"],
        '+': ["00000", "00100", "00100", "11111", "00100", "00100", "00000"],
        ':': ["00000", "00110", "00110", "00000", "00110", "00110", "00000"],
        '|': ["00100", "00100", "00100", "00100", "00100", "00100", "00100"],
        '·': ["00000", "00000", "00000", "00110", "00110", "00000", "00000"],
        '_': ["00000", "00000", "00000", "00000", "00000", "00000", "11111"],
    }

    def _text(self, canvas, attrs, content, dx, dy, sc):
        # 中文字幕整行跳过（内置点阵仅支持 ASCII，字幕文本记录于 frames_notes.json）
        if any(ord(ch) > 127 for ch in content):
            return
        fill = self._color(attrs, "fill", (255, 255, 255))
        fs = _parse_num(attrs.get("font-size", "10"))
        scale = max(1, int(round(fs / 7)))
        anchor = attrs.get("text-anchor", "start")
        x = _parse_num(attrs.get("x", "0"))
        y = _parse_num(attrs.get("y", "0"))
        glyph_w = 5 * scale
        step = (5 + 1) * scale
        text_w = sum(step for ch in content) - 1
        if anchor == "middle":
            x -= text_w / 2
        elif anchor == "end":
            x -= text_w
        cx = 0
        for ch in content:
            pat = self._FONT.get(ch.upper(), self._FONT[' '])
            for r in range(7):
                for c in range(5):
                    if pat[r][c] == '1':
                        self._set(canvas, x + cx + c * scale, y - 6 * scale + r * scale, fill, dx, dy, sc)
            cx += step
        # 忽略中文字符（不渲染，字幕文本记录于 frames_notes.json）


# ---------------------------------------------------------------- 像素级帧绘制
def _px(canvas, x, y, color):
    if 0 <= x < _WIDTH and 0 <= y < _HEIGHT:
        canvas[y][x] = color


def _fill_rect(canvas, x0, y0, x1, y1, color):
    for yy in range(y0, min(y1, _HEIGHT - 1) + 1):
        for xx in range(x0, min(x1, _WIDTH - 1) + 1):
            if xx >= 0 and yy >= 0:
                canvas[yy][xx] = color


def _draw_text(canvas, x, y, text, color, scale=2):
    """ASCII 点阵文本（x,y 为左上角）。"""
    step = 6 * scale
    cx = 0
    for ch in text:
        pat = _Svg._FONT.get(ch.upper(), _Svg._FONT[' '])
        for r in range(7):
            for c in range(5):
                if pat[r][c] == '1':
                    for oy in range(scale):
                        for ox in range(scale):
                            _px(canvas, x + cx + c * scale + ox, y + r * scale + oy, color)
        cx += step


def _new_canvas(bg=_BG):
    return [[list(bg) for _ in range(_WIDTH)] for _ in range(_HEIGHT)]


def _transition_a():
    """模块 A：C2M 订单状态机。"""
    c = _new_canvas()
    _fill_rect(c, 0, 0, _WIDTH - 1, 46, (9, 19, 32))
    _draw_text(c, 14, 14, "MODULE A", (242, 193, 78), 2)
    _draw_text(c, 132, 22, "C2M ORDER FLOW", (200, 214, 234), 1)
    nodes = ["AUTH", "MFG", "ORDER", "PAY", "PROD", "DELIVER"]
    colors = [(76, 175, 80), (76, 175, 80), (66, 165, 245), (255, 152, 0), (66, 165, 245), (76, 175, 80)]
    for i, name in enumerate(nodes):
        row = i // 3
        col = i % 3
        x0 = 24 + col * 96
        y0 = 74 + row * 72
        _fill_rect(c, x0, y0, x0 + 62, y0 + 40, colors[i])
        _draw_text(c, x0 + 8, y0 + 9, name, (255, 255, 255), 1)
        if i % 3 != 2:
            for xx in range(x0 + 64, x0 + 90):
                _px(c, xx, y0 + 20, (255, 255, 255))
            _px(c, x0 + 88, y0 + 16, (255, 255, 255))
            _px(c, x0 + 88, y0 + 24, (255, 255, 255))
        elif row == 0:
            for yy in range(y0 + 42, y0 + 66):
                _px(c, x0 + 30, yy, (255, 255, 255))
            _px(c, x0 + 26, y0 + 64, (255, 255, 255))
            _px(c, x0 + 34, y0 + 64, (255, 255, 255))
    _fill_rect(c, 0, 196, _WIDTH - 1, 239, (10, 20, 35))
    _draw_text(c, 90, 206, "TRACEABLE LEDGER  REFUND  DISPUTE", (140, 200, 255), 1)
    return c


def _transition_b():
    """模块 B：三语出海站点 + SEO / CRM / FDE。"""
    c = _new_canvas()
    _fill_rect(c, 0, 0, _WIDTH - 1, 46, (9, 19, 32))
    _draw_text(c, 14, 14, "MODULE B", (242, 193, 78), 2)
    _draw_text(c, 132, 22, "GO-GLOBAL STACK", (200, 214, 234), 1)
    sites = [("ZH", (211, 47, 47)), ("EN", (33, 150, 243)), ("DE", (255, 193, 7))]
    for i, (name, color) in enumerate(sites):
        x0 = 20 + i * 102
        _fill_rect(c, x0, 70, x0 + 84, 150, color)
        _draw_text(c, x0 + 26, 102, name, (255, 255, 255), 3)
        _draw_text(c, x0 + 6, 132, "SITE", (255, 255, 255), 1)
        _draw_text(c, x0 + 6, 144, "HTML", (255, 255, 255), 1)
    _fill_rect(c, 0, 168, _WIDTH - 1, 178, (10, 20, 35))
    _draw_text(c, 20, 204, "SEO PASS  CRM 3/3  FDE 12 CHECKLIST", (140, 255, 170), 1)
    return c


def _transition_d():
    """模块 D：赛事 KPI 条形图。"""
    c = _new_canvas()
    _fill_rect(c, 0, 0, _WIDTH - 1, 46, (9, 19, 32))
    _draw_text(c, 14, 14, "MODULE D", (242, 193, 78), 2)
    _draw_text(c, 132, 22, "CONTEST KPI BOARD", (200, 214, 234), 1)
    bars = [("T1", 96), ("T2", 130), ("T3", 78)]
    base_y = 184
    for i, (name, height) in enumerate(bars):
        x0 = 34 + i * 92
        _fill_rect(c, x0, base_y - height, x0 + 44, base_y, (66, 165, 245))
        _draw_text(c, x0 + 12, 196, name, (255, 255, 255), 1)
        _draw_text(c, x0 + 8, 210, str(height), (242, 193, 78), 1)
    _fill_rect(c, 12, base_y, 308, base_y + 3, (200, 214, 234))
    _fill_rect(c, 0, 216, _WIDTH - 1, 239, (10, 20, 35))
    _draw_text(c, 60, 222, "SCORE 85+  SHORTLIST  KPI MET", (140, 255, 170), 1)
    return c


def _transition_end():
    """结尾帧。"""
    c = _new_canvas((18, 60, 44))
    _draw_text(c, 70, 86, "ALL GREEN", (255, 255, 255), 4)
    _draw_text(c, 46, 136, "#1724 DEMO PROTOTYPE", (242, 193, 78), 2)
    _draw_text(c, 70, 158, "125 TESTS  0 FAIL", (200, 214, 234), 2)
    return c


# ---------------------------------------------------------------- GIF89a 编码
def _gif_encode(frames, delays):
    """frames: list of 2D RGB; delays: ms 延迟列表。返回 GIF 字节。"""
    # 收集全局调色板（精确 <=256 色，否则 3-3-2 量化）
    all_colors = set()
    for fr in frames:
        for row in fr:
            for px in row:
                all_colors.add(tuple(px))
    palette = sorted(all_colors)
    if len(palette) > 256:
        # 3-3-2 量化兜底
        buckets = {}
        for color in all_colors:
            idx = ((color[0] >> 5) << 5) | ((color[1] >> 5) << 2) | (color[2] >> 6)
            buckets.setdefault(idx, color)
        palette = [buckets[i] for i in sorted(buckets)]
    palette = (palette + [(0, 0, 0)] * 256)[:256]

    def to_index(color):
        q = ((color[0] >> 5) << 5) | ((color[1] >> 5) << 2) | (color[2] >> 6)
        cand = [(abs(palette[i][0] - color[0]) + abs(palette[i][1] - color[1])
                 + abs(palette[i][2] - color[2]), i) for i in range(256)]
        return min(cand)[1]

    out = bytearray()
    out += b"GIF89a"
    # 逻辑屏幕描述符
    out += _WIDTH.to_bytes(2, "little") + _HEIGHT.to_bytes(2, "little")
    out += bytes([0xF7])  # 全局色表 256 色
    out += bytes([0, 0])
    for color in palette:
        out += bytes(color)
    # Netscape 循环扩展
    out += bytes([0x21, 0xFF, 0x0B]) + b"NETSCAPE2.0" + bytes([3, 1, 0, 0]) + bytes([0])

    for fr, delay in zip(frames, delays):
        # 图形控制扩展
        out += bytes([0x21, 0xF9, 0x04, 0x00])
        out += int(round(delay / 10)).to_bytes(2, "little")
        out += bytes([0x00, 0x00])
        # 图像描述符（全局色表）
        out += bytes([0x2C])
        out += (0).to_bytes(2, "little") + (0).to_bytes(2, "little")
        out += _WIDTH.to_bytes(2, "little") + _HEIGHT.to_bytes(2, "little")
        out += bytes([0x00])
        # LZW 数据
        indices = [to_index(px) for row in fr for px in row]
        out += bytes([8])  # 最小码长
        out += _lzw_pack(indices)

    out += bytes([0x3B])
    return bytes(out)


def _lzw_pack(indices):
    """GIF LZW 编码，输出子块。"""
    min_code = 8
    clear = 1 << min_code
    end = clear + 1
    code_size = min_code + 1

    def reset_dict():
        d = {bytes([i]): i for i in range(256)}
        return d

    table = reset_dict()
    next_code = end + 1
    bitbuf = 0
    bitcnt = 0
    raw = bytearray()

    def emit(code):
        nonlocal bitbuf, bitcnt
        bitbuf |= code << bitcnt
        bitcnt += code_size
        while bitcnt >= 8:
            raw.append(bitbuf & 0xFF)
            bitbuf >>= 8
            bitcnt -= 8

    emit(clear)
    cur = bytes([indices[0]])
    for b in indices[1:]:
        seq = cur + bytes([b])
        if seq in table:
            cur = seq
        else:
            emit(table[cur])
            if next_code < 4096:
                table[seq] = next_code
                next_code += 1
                if next_code == (1 << code_size) and code_size < 12:
                    code_size += 1
                if next_code >= 4096:
                    emit(clear)
                    table = reset_dict()
                    next_code = end + 1
                    code_size = min_code + 1
            cur = bytes([b])
    emit(table[cur])
    emit(end)
    # 收尾补位
    if bitcnt > 0:
        raw.append(bitbuf & 0xFF)
    # 子块打包
    out = bytearray()
    for i in range(0, len(raw), 255):
        chunk = raw[i:i + 255]
        out.append(len(chunk))
        out += chunk
    out.append(0)
    return bytes(out)


# ---------------------------------------------------------------- 主流程
def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ep_dir = os.path.join(root, "output", "episode_demo")
    out_dir = os.path.join(root, "output", "demo_video")
    os.makedirs(out_dir, exist_ok=True)

    frames = []
    notes = []
    delays = []
    for i in range(1, 9):
        svg_path = os.path.join(ep_dir, "frame_{:03d}.svg".format(i))
        text = open(svg_path, encoding="utf-8").read()
        canvas = _Svg(text).render()
        frames.append(canvas)
        captions = re.findall(r"<text[^>]*>([^<]+)</text>", text)
        notes.append({
            "index": len(frames),
            "kind": "module_c_episode",
            "source": os.path.relpath(svg_path, root),
            "captions": captions,
        })
        delays.append(450)

    for fn, kind, label in [
        (_transition_a, "module_a_transition", "C2M 订单链路"),
        (_transition_b, "module_b_transition", "三语出海站点 + SEO/CRM/FDE"),
        (_transition_d, "module_d_transition", "赛事 KPI 看板"),
    ]:
        frames.append(fn())
        notes.append({"index": len(frames), "kind": kind, "captions": [label]})
        delays.append(700)
    frames.append(_transition_end())
    notes.append({"index": len(frames), "kind": "end_title", "captions": ["ALL GREEN"]})
    delays.append(1200)

    gif = _gif_encode(frames, delays)
    gif_path = os.path.join(out_dir, "demo.gif")
    with open(gif_path, "wb") as f:
        f.write(gif)

    meta = {
        "tool": "make_demo_video",
        "width": _WIDTH,
        "height": _HEIGHT,
        "frames": len(frames),
        "gif_bytes": len(gif),
        "palette_colors": None,
        "notes": notes,
    }
    notes_path = os.path.join(out_dir, "frames_notes.json")
    with open(notes_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print(json.dumps({"gif_path": gif_path, "bytes": len(gif), "frames": len(frames),
                      "notes_path": notes_path}, ensure_ascii=False))
    return 0 if len(gif) > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
