#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_demo_mp4.py — ClawHunt #1724 投标演示样片 v2 → 1080p MP4 封装脚本

职责：
  1. 读取 demo_v2.gif 的逐帧延迟（GCE 块，1/100 秒），与 frames_v2_notes.json 的
     帧注释（caption 英文）对齐，构建帧级时间轴；
  2. 连续相同 caption 合并为一条字幕条目，生成 SRT 字幕文件（demo_v2.srt）；
  3. 调用本机 ffmpeg（路径常量 FFMPEG_EXE，需含 libx264 / libass / libfreetype）
     将 GIF 合成为 1080p MP4：
        fps=30 稳定帧率 → scale=1920:1080(lanczos) → yuv420p → subtitles 烧录
        → libx264 (crf 18, faststart) → 无音频源，纯视频轨；
  4. 调用 ffprobe 自检：时长 / 分辨率 / 编码 / 体积。

纯标准库实现（GIF GCE 解析不依赖 Pillow），零第三方依赖。

用法：
  python make_demo_mp4.py                # 生成 SRT + 合成 MP4 + ffprobe 自检
  python make_demo_mp4.py --no-check     # 跳过 ffprobe 自检
  python make_demo_mp4.py --srt-only     # 仅生成 SRT
"""

import argparse
import json
import os
import subprocess
import sys

# ---------------------------------------------------------------------------
# 路径常量（按本机实际环境）
# ---------------------------------------------------------------------------
FFMPEG_EXE = r"C:\Users\Administrator\AppData\Local\ffmpeg\ffmpeg-9.0.2-essentials_build\bin\ffmpeg.exe"
FFPROBE_EXE = r"C:\Users\Administrator\AppData\Local\ffmpeg\ffmpeg-9.0.2-essentials_build\bin\ffprobe.exe"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # prototype/
OUT_DIR = os.path.join(BASE_DIR, "output", "demo_video")
GIF_PATH = os.path.join(OUT_DIR, "demo_v2.gif")
NOTES_PATH = os.path.join(OUT_DIR, "frames_v2_notes.json")
SRT_PATH = os.path.join(OUT_DIR, "demo_v2.srt")
MP4_PATH = os.path.join(OUT_DIR, "demo_v2.mp4")

# 字幕样式（1080p 坐标）：白色文字 + 黑描边 + 底部留白，清晰不遮挡主体
SUBTITLE_STYLE = (
    "FontName=Arial,"
    "FontSize=42,"
    "PrimaryColour=&H00FFFFFF,"
    "OutlineColour=&H00000000,"
    "BorderStyle=1,"
    "Outline=2,"
    "Shadow=1,"
    "MarginV=48"
)
FONTS_DIR = r"C:\Windows\Fonts"


def read_gif_delays(gif_path):
    """纯标准库解析 GIF GCE 块，返回每帧延迟（毫秒）。"""
    with open(gif_path, "rb") as f:
        data = f.read()
    # 头部(6) + 逻辑屏幕描述符(7)，第 10 字节为全局标志
    flags = data[10]
    gct_size = 3 * (2 ** ((flags & 0x07) + 1)) if (flags & 0x80) else 0
    pos = 13 + gct_size
    delays = []
    while pos < len(data):
        b = data[pos]
        if b == 0x3B:  # trailer
            break
        if b == 0x21:  # extension
            label = data[pos + 1]
            pos += 2
            if label == 0xF9:  # Graphic Control Extension
                sz = data[pos]  # 固定 4
                delay = data[pos + 2] | (data[pos + 3] << 8)  # 1/100 s
                delays.append(delay * 10)  # -> ms
                pos += sz + 2  # 数据 + 终止符 0x00
            else:
                while True:
                    sz = data[pos]
                    pos += 1
                    if sz == 0:
                        break
                    pos += sz
        elif b == 0x2C:  # image descriptor
            pos += 10
            iflags = data[pos - 1]
            if iflags & 0x80:  # 局部色表
                pos += 3 * (2 ** ((iflags & 0x07) + 1))
            pos += 1  # LZW 最小码宽
            while True:
                sz = data[pos]
                pos += 1
                if sz == 0:
                    break
                pos += sz
        else:
            pos += 1
    return delays


def build_srt(notes_path, gif_path, srt_path):
    """按 GIF 帧延迟映射时间轴，从 notes 英文 caption 生成 SRT（连续相同字幕合并）。"""
    with open(notes_path, encoding="utf-8") as f:
        notes = json.load(f)
    arr = notes["notes"]
    delays = read_gif_delays(gif_path)
    if len(delays) != len(arr):
        raise RuntimeError(
            f"帧数不匹配：GIF GCE={len(delays)}，notes={len(arr)}"
        )

    # 帧级时间轴
    timeline = []
    t = 0
    for i, (n, d) in enumerate(zip(arr, delays)):
        timeline.append({
            "frame": n["frame"],
            "scene": n["scene"],
            "caption": (n.get("caption") or "").strip(),
            "start_ms": t,
            "end_ms": t + d,
        })
        t += d

    # 连续相同 caption 合并（消除 250ms 过渡帧字幕闪烁）
    merged = []
    for item in timeline:
        if merged and merged[-1]["caption"] == item["caption"]:
            merged[-1]["end_ms"] = item["end_ms"]
            merged[-1]["frames"].append(item["frame"])
        else:
            merged.append({**item, "frames": [item["frame"]]})

    def fmt(ms):
        h = ms // 3600000
        m = (ms % 3600000) // 60000
        s = (ms % 60000) // 1000
        milli = ms % 1000
        return f"{h:02d}:{m:02d}:{s:02d},{milli:03d}"

    lines = []
    for idx, item in enumerate(merged, 1):
        lines.append(str(idx))
        lines.append(f"{fmt(item['start_ms'])} --> {fmt(item['end_ms'])}")
        lines.append(item["caption"])
        lines.append("")

    with open(srt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return merged, t


def run_ffmpeg(gif_path, srt_path, mp4_path):
    """GIF → 1080p MP4：fps 稳定 + 2x 整数倍缩放 + yuv420p + 字幕烧录 + libx264。"""
    # 工作目录切到输出目录，SRT 用相对文件名，规避 Windows 路径转义
    workdir = os.path.dirname(srt_path)
    srt_rel = os.path.basename(srt_path)

    fontsdir_escaped = FONTS_DIR.replace(":", r"\:")
    vf = (
        "fps=30,"
        "scale=1920:1080:flags=lanczos,"
        "format=yuv420p,"
        f"subtitles={srt_rel}:"
        f"force_style='{SUBTITLE_STYLE}':"
        f"fontsdir='{fontsdir_escaped}'"
    )
    cmd = [
        FFMPEG_EXE, "-y",
        "-i", gif_path,
        "-vf", vf,
        "-c:v", "libx264",
        "-preset", "medium",
        "-crf", "18",
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        "-an",
        mp4_path,
    ]
    print("[ffmpeg] " + " ".join(cmd))
    proc = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise RuntimeError(f"ffmpeg 合成失败，exit={proc.returncode}")
    return mp4_path


def run_ffprobe(mp4_path):
    """ffprobe 自检：时长 / 分辨率 / 编码 / 体积。"""
    cmd = [
        FFPROBE_EXE, "-v", "error",
        "-select_streams", "v:0",
        "-show_entries",
        "stream=codec_name,width,height,nb_frames,avg_frame_rate,duration",
        "-show_entries", "format=duration,size",
        "-of", "default=noprint_wrappers=1",
        mp4_path,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError("ffprobe 自检失败：" + proc.stderr)
    print("--- ffprobe 自检 ---")
    print(proc.stdout.strip())
    size = os.path.getsize(mp4_path)
    print(f"file_size={size} bytes ({size / 1024:.1f} KiB)")
    return proc.stdout


def main():
    ap = argparse.ArgumentParser(description="ClawHunt #1724 demo_v2.gif -> 1080p MP4")
    ap.add_argument("--no-check", action="store_true", help="跳过 ffprobe 自检")
    ap.add_argument("--srt-only", action="store_true", help="仅生成 SRT 字幕文件")
    args = ap.parse_args()

    if not os.path.isfile(FFMPEG_EXE):
        sys.exit(f"ffmpeg 不存在：{FFMPEG_EXE}")
    if not os.path.isfile(GIF_PATH):
        sys.exit(f"缺少输入 GIF：{GIF_PATH}")
    if not os.path.isfile(NOTES_PATH):
        sys.exit(f"缺少帧注释：{NOTES_PATH}")

    os.makedirs(OUT_DIR, exist_ok=True)

    merged, total_ms = build_srt(NOTES_PATH, GIF_PATH, SRT_PATH)
    print(f"[SRT] {SRT_PATH}")
    print(f"[SRT] {len(merged)} 条字幕（33 帧合并后），总时长 {total_ms / 1000:.2f}s")

    if args.srt_only:
        return

    run_ffmpeg(GIF_PATH, SRT_PATH, MP4_PATH)
    print(f"[MP4] {MP4_PATH}")

    if not args.no_check:
        run_ffprobe(MP4_PATH)


if __name__ == "__main__":
    main()
