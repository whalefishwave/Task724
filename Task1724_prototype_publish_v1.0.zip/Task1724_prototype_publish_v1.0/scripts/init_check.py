"""ClawHunt #1724 交付仓库 —— 初始化自检（纯标准库，离线，确定性）。

一键安装/运行脚本（run.ps1 / run.sh / start.py）的初始化环节调用本脚本，
输出 JSON 摘要并给出退出码（0=全部通过）。

检查项：
1. 环境检查：python3 版本 >= 3.7（与 README 声明一致）。
2. 零第三方依赖复核：AST 扫描仓库全部 .py 源码的 import 语句，
   仅允许 Python 标准库与仓库内部模块。
3. JSON 配置/数据完整性：各模块 data 关键 JSON 可解析，必填键齐全。
4. 离线可运行：源码中不出现网络访问类调用（socket/http/urllib/requests 等）。

用法：python scripts/init_check.py
"""
import ast
import json
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 关键数据文件 -> 必填顶层键（与各模块代码实际读取契约一致）
REQUIRED_JSON_KEYS = {
    "module_a/data/mfg_cases.json": ["cases", "negative_case_ids", "score_target"],
    "module_a/data/mfg_rules_jewelry.json": ["industry", "rules"],
    "module_a/data/mfg_rules_wood.json": ["industry", "rules"],
    "module_a/data/equipment_capabilities.json": ["workshops"],
    "module_a/data/pattern_samples.json": ["required_fields", "valid_usage_scopes",
                                           "valid_license_types", "samples"],
    "module_b/data/components.json": ["components"],
    "module_b/data/crm_cases.json": ["cases"],
    "module_b/data/enterprise_profile_sample.json": ["profile_id", "enterprise_name",
                                                     "industry", "components_enabled",
                                                     "data_boundaries", "owners",
                                                     "go_live_checklist_state"],
    "module_b/data/fde_handbook.json": ["handbook", "readiness_rules", "go_live_checklist"],
    "module_b/data/industry_config_jewelry.json": ["industry", "display_name",
                                                   "enabled_components", "prompt_templates",
                                                   "kb_fallback", "field_mapping",
                                                   "kb_assets", "showcase", "workflow",
                                                   "crm", "analytics"],
    "module_b/data/industry_config_wood.json": ["industry", "display_name",
                                                "enabled_components", "prompt_templates",
                                                "kb_fallback", "field_mapping",
                                                "kb_assets", "showcase", "workflow",
                                                "crm", "analytics"],
    "module_b/data/seo_cases.json": ["rules", "required_hreflang", "cases"],
    "module_b/data/site_content_zh.json": ["locale", "lang_code", "lang_path", "site_title",
                                           "slogan", "description", "products", "base_url"],
    "module_b/data/site_content_en.json": ["locale", "lang_code", "lang_path", "site_title",
                                           "slogan", "description", "products", "base_url"],
    "module_b/data/site_content_de.json": ["locale", "lang_code", "lang_path", "site_title",
                                           "slogan", "description", "products", "base_url"],
    "module_c/data/characters.json": ["ip_title", "handbook_id", "origin_declaration",
                                      "non_exclusive_clause", "ai_generated_note",
                                      "characters"],
    "module_c/data/license_matrix.json": ["matrix_id", "non_exclusive_clause",
                                          "ai_generated_marking_required",
                                          "license_matrix", "derivative_specs",
                                          "approval_workflow"],
    "module_c/data/safety_words.json": ["safety_list_id", "note", "banned", "safe",
                                        "brand_terms", "ai_marking_term",
                                        "replacement_hint"],
    "module_c/data/visual_recipes.json": ["library_id", "note", "recipes"],
    "module_c/data/asset_registry.json": ["registry_id", "schema_version", "assets",
                                          "changelog"],
    "module_c/data/script_sample.json": ["episode_id", "title", "ai_generated_marking",
                                         "purpose", "scenes"],
    "module_d/data/contest_config.json": ["contest_id", "name", "note", "tracks",
                                          "review_criteria", "scorecard",
                                          "sampling_flow", "promotion_matrix",
                                          "kpi_targets", "kpi_currents", "sample_entries"],
}

# 允许出现但属于“联网类”的模块名（标准库），用于离线检查
_NETWORK_MODULES = {
    "socket", "http", "http.client", "http.server", "urllib", "urllib.request",
    "urllib.parse", "ftplib", "imaplib", "poplib", "smtplib", "telnetlib",
    "xmlrpc", "xmlrpc.client", "xmlrpc.server", "requests", "httpx", "aiohttp",
    "websockets", "selenium", "playwright",
}


def _collect_py_files(root):
    py_files = []
    for dirpath, _dirnames, filenames in os.walk(root):
        if os.sep + "output" in dirpath + os.sep:
            continue
        for name in filenames:
            if name.endswith(".py"):
                py_files.append(os.path.join(dirpath, name))
    return sorted(py_files)


def _internal_top_levels():
    """仓库内部模块集合：仓库内所有目录名与 .py 文件基名。

    仓库自身不引入第三方依赖，因此仓库内出现的任何模块名（含 package
    内子模块，如 module_c/assets.py 被 `from assets import ...` 引用）都
    视为内部模块，不计入第三方依赖。
    """
    tops = set()
    for dirpath, dirnames, filenames in os.walk(_ROOT):
        if os.sep + "output" in dirpath + os.sep:
            continue
        for d in dirnames:
            tops.add(d)
        for name in filenames:
            if name.endswith(".py"):
                tops.add(name[:-3])
    return tops


def _scan_imports(py_files):
    """返回 (第三方导入集合, 联网模块导入集合, 问题列表)。

    仓库内部模块（module_a/module_b/module_c/module_d/scripts/demo/tests 等）
    不计入第三方依赖。
    """
    internal = _internal_top_levels()
    third_party = set()
    network_hits = set()
    problems = []
    for path in py_files:
        # 根目录 server.py：本地 HTTP 服务端（不主动出网），豁免联网模块判定
        local_server = os.path.basename(path) == "server.py" and \
            os.path.dirname(path).replace("\\", "/") == _ROOT.replace("\\", "/")
        try:
            with open(path, "r", encoding="utf-8") as f:
                tree = ast.parse(f.read(), filename=path)
        except (SyntaxError, UnicodeDecodeError) as exc:
            problems.append("无法解析 {}: {}".format(os.path.relpath(path, _ROOT), exc))
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top in internal:
                        continue
                    if not _is_stdlib(top):
                        third_party.add(alias.name)
                    if not local_server and (alias.name in _NETWORK_MODULES or top in _NETWORK_MODULES):
                        network_hits.add(alias.name)
            elif isinstance(node, ast.ImportFrom):
                mod = node.module or ""
                top = mod.split(".")[0]
                if top in internal:
                    continue
                if not _is_stdlib(top):
                    third_party.add(mod)
                if not local_server and (mod in _NETWORK_MODULES or top in _NETWORK_MODULES):
                    network_hits.add(mod)
    return third_party, network_hits, problems


_STDLIB_FALLBACK = frozenset({
    "abc", "argparse", "array", "ast", "asyncio", "base64", "binascii", "bisect",
    "calendar", "cmath", "collections", "configparser", "contextlib", "copy", "csv",
    "ctypes", "datetime", "decimal", "difflib", "dis", "email", "enum", "errno",
    "functools", "gc", "getpass", "glob", "gzip", "hashlib", "heapq", "hmac",
    "html", "http", "importlib", "inspect", "io", "itertools", "json", "logging",
    "math", "multiprocessing", "numbers", "operator", "os", "pathlib", "pickle",
    "platform", "pprint", "queue", "random", "re", "select", "shutil", "signal",
    "socket", "sqlite3", "ssl", "statistics", "string", "struct", "subprocess",
    "sys", "tempfile", "threading", "time", "traceback", "types", "typing",
    "unicodedata", "unittest", "urllib", "uuid", "venv", "warnings", "weakref",
    "xml", "xmlrpc", "zipfile", "zoneinfo",
})


def _is_stdlib(top):
    try:
        std = getattr(sys, "stdlib_module_names", None)
    except Exception:
        std = None
    if std is not None:
        return top in std
    return top in _STDLIB_FALLBACK or top in sys.builtin_module_names


def _check_json_integrity():
    """校验关键 JSON 文件可解析且必填键齐全。返回 (问题列表, 文件数)。"""
    problems = []
    count = 0
    for rel, required in REQUIRED_JSON_KEYS.items():
        path = os.path.join(_ROOT, rel)
        count += 1
        if not os.path.exists(path):
            problems.append("缺失数据文件: {}".format(rel))
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            problems.append("JSON 解析失败 {}: {}".format(rel, exc))
            continue
        if not isinstance(data, dict):
            problems.append("JSON 顶层应为对象: {}".format(rel))
            continue
        missing = [k for k in required if k not in data]
        if missing:
            problems.append("{} 缺少必填键: {}".format(rel, ",".join(missing)))
    return problems, count


def main():
    report = {
        "tool": "init_check",
        "python_version": "{}.{}.{}".format(*sys.version_info[:3]),
        "python_ok": bool(sys.version_info >= (3, 7)),
        "py_files_scanned": 0,
        "third_party_imports": [],
        "network_imports": [],
        "json_files_checked": 0,
        "problems": [],
    }
    py_files = _collect_py_files(_ROOT)
    report["py_files_scanned"] = len(py_files)
    third_party, network_hits, scan_problems = _scan_imports(py_files)
    report["third_party_imports"] = sorted(third_party)
    report["network_imports"] = sorted(network_hits)
    report["problems"].extend(scan_problems)
    json_problems, json_count = _check_json_integrity()
    report["json_files_checked"] = json_count
    report["problems"].extend(json_problems)

    report["all_green"] = (
        report["python_ok"]
        and not report["third_party_imports"]
        and not report["network_imports"]
        and not report["problems"]
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["all_green"] else 1


if __name__ == "__main__":
    sys.exit(main())
