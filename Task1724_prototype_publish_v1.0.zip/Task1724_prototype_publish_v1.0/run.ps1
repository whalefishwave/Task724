# ClawHunt #1724 一键运行（Windows PowerShell）
# 用法：右键“使用 PowerShell 运行”，或在此目录执行  .\run.ps1
$ErrorActionPreference = "Stop"
$RepoRoot = $PSScriptRoot
Write-Host "== ClawHunt #1724 一键运行（Windows） ==" -ForegroundColor Cyan

$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) {
    Write-Error "未找到 python，请先安装 Python 3.7+（勾选 Add to PATH）。"
    exit 1
}
$ver = python -c "import sys;print('{0}.{1}.{2}'.format(*sys.version_info[:3]))"
Write-Host "Python 版本：$ver"

python "$RepoRoot\start.py"
$code = $LASTEXITCODE
if ($code -eq 0) {
    Write-Host "== 全部通过 ==" -ForegroundColor Green
} else {
    Write-Host "== 存在失败项（退出码 $code），详见上方 JSON 汇总 ==" -ForegroundColor Red
}
exit $code
