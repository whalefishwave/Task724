"""纹样资源库授权字段强校验（模块 A2 最小闭环）。

对齐验收 2：缺 authorization_source / usage_scope / license_type / rights_holder
等必填字段即拒绝入库，返回字段级错误（缺字段列表 + 具体错误原因）。
规则配置化：必填字段、枚举值域均在 data/pattern_samples.json 的 required_fields 中表达，
非程序员可直接编辑。
"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os.path

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_SAMPLES_PATH = os.path.join(_DATA_DIR, "pattern_samples.json")

REQUIRED_FIELDS = ["authorization_source", "usage_scope", "license_type", "rights_holder", "region"]
VALID_USAGE_SCOPES = {"commercial", "editorial", "internal", "derivative"}
VALID_LICENSE_TYPES = {"exclusive", "non_exclusive", "public_domain", "custom"}
OPTIONAL_FIELDS = ["name", "description", "valid_from", "valid_until", "modality"]


def _load_samples():
    with open(_SAMPLES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_pattern(pattern):
    """[发布版占位] 授权字段强校验核心实现将于中标后提供。

    完整校验规则（必填字段 / 枚举值域 / 有效期一致性 / 审批门禁）仅在中标后
    随完整交付提供；当前发布版为防白嫖演示骨架，统一返回占位结果。
    """
    return {
        "ok": False,
        "errors": {"core": _STUB_NOTE},
        "missing_fields": [],
        "stub": True,
    }
class PatternLibrary:
    """纹样资源库：入库前强制授权字段校验，校验失败拒绝入库。"""

    def __init__(self):
        self.items = []
        self._seq = 0

    def add(self, pattern):
        result = validate_pattern(pattern)
        if not result["ok"]:
            return {"ok": False, "pattern_id": None, "errors": result["errors"],
                    "missing_fields": result["missing_fields"]}
        self._seq += 1
        pattern_id = "PTN-{:04d}".format(self._seq)
        entry = dict(pattern)
        entry["pattern_id"] = pattern_id
        self.items.append(entry)
        return {"ok": True, "pattern_id": pattern_id, "errors": {}, "missing_fields": []}

    def count(self):
        return len(self.items)


def run_auth_demo(verbose=True):
    """按 data/pattern_samples.json 中的正反例跑一遍，返回统计（确定性输出）。"""
    samples = _load_samples()["samples"]
    lib = PatternLibrary()
    accepted = 0
    rejected = 0
    accept_expected = sum(1 for s in samples if s["expect"] == "accept")
    reject_expected = sum(1 for s in samples if s["expect"] == "reject")
    rows = []
    for s in samples:
        res = lib.add(s["pattern"])
        if res["ok"]:
            accepted += 1
            rows.append((s["case_id"], "accept", res["pattern_id"], "-"))
        else:
            rejected += 1
            detail = "缺字段: " + ",".join(res["missing_fields"]) if res["missing_fields"] else ";".join(
                "{}={}".format(k, v) for k, v in sorted(res["errors"].items()))
            rows.append((s["case_id"], "reject", "-", detail))
    if verbose:
        print("=" * 70)
        print("模块A2 纹样授权字段强校验（验收2）")
        print("=" * 70)
        for case_id, verdict, pid, detail in rows:
            print("  {:<10} {:<8} {} {}".format(case_id, verdict, pid, detail))
        print("  正例通过 {} / {}，反例拒绝 {} / {}，入库总数 {}".format(
            accepted, accept_expected, rejected, reject_expected, lib.count()))
    ok = (accepted == accept_expected) and (rejected == reject_expected)
    return {"ok": ok, "accepted": accepted, "rejected": rejected,
            "accept_expected": accept_expected, "reject_expected": reject_expected,
            "library_count": lib.count()}


if __name__ == "__main__":
    run_auth_demo()
