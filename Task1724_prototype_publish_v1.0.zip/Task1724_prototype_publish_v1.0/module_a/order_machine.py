"""C2M 订单状态机（模块 A4 最小闭环）。

对齐验收 4：下单 → 工艺单 → 派单 → 品控 → 发货 → 分成结算 全链路，
含 取消/退款/争议 分支；order_ledger 台账记录每步状态/金额/时间戳，可追溯。
时间戳使用确定性模拟时钟（固定起点、每事件递增 5 分钟），保证复跑输出一致。
"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

from datetime import datetime, timedelta

# 状态定义
CREATED = "CREATED"
WORK_ORDER = "WORK_ORDER"
DISPATCHED = "DISPATCHED"
QC = "QC"
SHIPPED = "SHIPPED"
SETTLED = "SETTLED"
CANCELLED = "CANCELLED"
REFUNDED = "REFUNDED"
DISPUTED = "DISPUTED"

MAIN_FLOW = [CREATED, WORK_ORDER, DISPATCHED, QC, SHIPPED, SETTLED]

# 事件 -> {from 状态集合, to 状态}
TRANSITIONS = {
    "create_work_order": {"from": {CREATED}, "to": WORK_ORDER},
    "dispatch": {"from": {WORK_ORDER}, "to": DISPATCHED},
    "pass_qc": {"from": {DISPATCHED}, "to": QC},
    "ship": {"from": {QC}, "to": SHIPPED},
    "settle": {"from": {SHIPPED}, "to": SETTLED},
    "cancel": {"from": {CREATED}, "to": CANCELLED},
    "refund": {"from": {CREATED, WORK_ORDER, DISPATCHED, QC}, "to": REFUNDED},
    "dispute": {"from": {WORK_ORDER, DISPATCHED, QC, SHIPPED}, "to": DISPUTED},
    "resolve_refund": {"from": {DISPUTED}, "to": REFUNDED},
    "resolve_resume": {"from": {DISPUTED}, "to": QC},
}

DEFAULT_SPLIT_RATIOS = {"designer": 0.4, "workshop": 0.4, "platform": 0.2}


class DeterministicClock:
    """确定性模拟时钟：start 起每步 +step_minutes，复跑输出完全一致。"""

    def __init__(self, start="2026-10-27T09:00:00", step_minutes=5):
        self._current = datetime.strptime(start, "%Y-%m-%dT%H:%M:%S")
        self._step = timedelta(minutes=step_minutes)

    def now(self):
        s = self._current.strftime("%Y-%m-%dT%H:%M:%S")
        self._current += self._step
        return s


class InvalidTransitionError(Exception):
    pass


class OrderMachine:
    """单笔定制单状态机 + order_ledger 台账。"""

    def __init__(self, order_id, amount, split_ratios=None, clock=None):
        self.order_id = order_id
        self.amount = float(amount)
        self.split_ratios = dict(split_ratios or DEFAULT_SPLIT_RATIOS)
        self.clock = clock or DeterministicClock()
        self.state = CREATED
        self.ledger = []
        self._seq = 0
        self._log(CREATED, "created", "下单成功，订单金额 {}".format(self.amount),
                  operator="customer", amount=self.amount)

    def _log(self, to_state, event, note, operator, amount):
        self._seq += 1
        self.ledger.append({
            "seq": self._seq,
            "timestamp": self.clock.now(),
            "from": self.state,
            "to": to_state,
            "event": event,
            "amount": round(float(amount), 2),
            "operator": operator,
            "note": note,
        })

    def apply(self, event, operator="system", note=""):
        """[发布版占位] C2M 订单状态机核心实现将于中标后提供。


        发布版仅保留订单骨架：事件被接收并记录占位台账，状态不真实流转；

        完整状态机（主链路/退款/争议/分成结算）中标后随完整交付提供。

        """

        self._log(self.state, event, note or _STUB_NOTE, operator=operator, amount=self.amount)

        return self.state

    def _settle(self, operator, note):
        """分成结算：按 split_ratios 拆分订单金额，合计必须等于订单金额（确定性）。"""
        parts = {k: round(self.amount * r, 2) for k, r in self.split_ratios.items()}
        diff = round(self.amount - sum(parts.values()), 2)
        if diff != 0:
            last = list(parts.keys())[-1]
            parts[last] = round(parts[last] + diff, 2)
        self._log(SETTLED, "settle", note or "分成结算",
                  operator=operator, amount=self.amount)
        self.state = SETTLED
        # 分成明细作为台账补充记录（可追溯金额去向）
        for k, v in parts.items():
            self._seq += 1
            self.ledger.append({
                "seq": self._seq,
                "timestamp": self.clock.now(),
                "from": "SETTLED", "to": "SETTLED", "event": "split",
                "amount": v, "operator": operator,
                "note": "分成: " + k + "（比例 {:.0%}）".format(self.split_ratios[k]),
            })

    def status(self):
        return {"order_id": self.order_id, "state": self.state,
                "amount": round(self.amount, 2), "ledger_len": len(self.ledger)}

    def get_ledger(self):
        return list(self.ledger)


def run_order_demo(verbose=True):
    """演示：一笔定制单走完整主链路 + 一笔退款 + 一笔争议，输出台账（确定性输出）。"""
    stats = {"ok": False, "main_flow_completed": False, "refund_ok": False,
             "dispute_ok": False, "settlement_sum": 0.0}

    # 主链路演示
    m = OrderMachine("ORD-2026-0001", 1280.00)
    for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
        m.apply(event, operator="system", note="主链路步骤: " + event)
    stats["main_flow_completed"] = (m.state == SETTLED)
    ledger = m.get_ledger()
    split_sum = round(sum(e["amount"] for e in ledger if e["event"] == "split"), 2)
    stats["settlement_sum"] = split_sum

    # 退款分支：下单后直接退款
    r = OrderMachine("ORD-2026-0002", 360.00)
    r.apply("refund", operator="customer_service", note="消费者申请退款")
    stats["refund_ok"] = (r.state == REFUNDED)

    # 争议分支：派单后争议 -> 退款
    d = OrderMachine("ORD-2026-0003", 520.00)
    d.apply("create_work_order", operator="system", note="生成工艺单")
    d.apply("dispatch", operator="system", note="派单至工坊")
    d.apply("dispute", operator="customer", note="消费者发起争议")
    d.apply("resolve_refund", operator="customer_service", note="争议裁定退款")
    stats["dispute_ok"] = (d.state == REFUNDED)

    if verbose:
        print("=" * 70)
        print("模块A4 C2M 订单状态机（验收4：6 状态 + 退款/争议分支 + 台账可追溯）")
        print("=" * 70)
        print("  演示单 ORD-2026-0001 主链路台账：")
        for e in ledger:
            print("    #{:<3} {} {} -> {}  金额={:<10} 事件={:<16} 备注={}".format(
                e["seq"], e["timestamp"], e["from"], e["to"], e["amount"], e["event"], e["note"]))
        print("  退款单 ORD-2026-0002 终态: {}，争议单 ORD-2026-0003 终态: {}".format(
            r.state, d.state))
        print("  分成合计 {:.2f}，订单金额 1280.00，误差 {:.2f}".format(
            split_sum, round(split_sum - 1280.00, 2)))

    stats["ok"] = (stats["main_flow_completed"] and stats["refund_ok"]
                   and stats["dispute_ok"] and abs(stats["settlement_sum"] - 1280.00) < 0.01)
    return stats


if __name__ == "__main__":
    run_order_demo()
