"""ClawHunt #1724 模块 A 最小可运行闭环原型（纯 Python 标准库实现）。

包含三个子模块：
- auth_fields:        纹样资源库授权字段强校验
- manufacturability:  可制造性判定规则引擎（珠宝/木作两行业）
- order_machine:      C2M 订单状态机（含退款/争议分支，台账可追溯）
"""
