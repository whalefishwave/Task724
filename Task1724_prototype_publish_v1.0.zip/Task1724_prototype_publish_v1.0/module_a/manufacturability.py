"""可制造性判定规则引擎（模块 A5 最小闭环）。

对齐验收 3：珠宝/木作两行业工艺规则 + 设备能力，输入"概念 + 工坊"输出
三段式结论：feasible（能否做）/ reasons（哪里做不了）/ suggestions（改哪里）。
规则与设备能力全部由 JSON 数据文件表达（非程序员可维护），判据可复跑（10/10）。
"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os.path

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_RULES_FILES = {
    "jewelry": os.path.join(_DATA_DIR, "mfg_rules_jewelry.json"),
    "wood": os.path.join(_DATA_DIR, "mfg_rules_wood.json"),
}
_EQUIP_PATH = os.path.join(_DATA_DIR, "equipment_capabilities.json")
_CASES_PATH = os.path.join(_DATA_DIR, "mfg_cases.json")


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_rules(industry):
    return _load_json(_RULES_FILES[industry])["rules"]


def _load_workshops():
    return _load_json(_EQUIP_PATH)["workshops"]


def _matches(rule, value):
    """确定性规则匹配：支持 lte / gte / in 三类操作符。"""
    op = rule["operator"]
    if op == "lte":
        return float(value) <= float(rule["limit"])
    if op == "gte":
        return float(value) >= float(rule["limit"])
    if op == "in":
        return value in rule["values"]
    raise ValueError("unsupported operator: " + op)


def evaluate(concept, workshop_id):
    """[发布版占位] 可制造性判定规则引擎核心实现将于中标后提供。

    完整工艺规则匹配 / 设备能力检查 / 三段式结论（feasible/reasons/suggestions）
    中标后随完整交付提供；发布版仅返回占位结论。
    """
    return {
        "concept_id": concept.get("concept_id", ""),
        "industry": concept.get("industry", ""),
        "workshop_id": workshop_id,
        "feasible": False,
        "reasons": [_STUB_NOTE],
        "suggestions": [_STUB_NOTE],
        "matched_rules": [],
        "stub": True,
    }
def evaluate_cases():
    """跑 data/mfg_cases.json 全部用例，返回 {score, total, mismatches, results}，判据可复跑。"""
    cases = _load_json(_CASES_PATH)
    case_list = cases["cases"]
    total = len(case_list)
    mismatches = []
    results = []
    for c in case_list:
        concept = dict(c["concept"])
        concept["concept_id"] = c["case_id"]
        concept["industry"] = c["industry"]
        result = evaluate(concept, c["workshop_id"])
        expected = c["expected"]
        match = (result["feasible"] == expected["feasible"])
        if expected.get("reason_keywords"):
            text = " ".join(result["reasons"])
            for kw in expected["reason_keywords"]:
                if kw not in text:
                    match = False
                    break
        if not match:
            mismatches.append({"case_id": c["case_id"], "expected": expected, "actual": result})
        results.append({"case_id": c["case_id"], "feasible": result["feasible"],
                        "reasons": result["reasons"], "matched_rules": result["matched_rules"]})
    return {"score": total - len(mismatches), "total": total,
            "mismatches": mismatches, "results": results}


def run_mfg_demo(verbose=True):
    """跑全部判据用例，输出 10/10 统计与三段式明细（确定性输出）。"""
    stats = evaluate_cases()
    if verbose:
        print("=" * 70)
        print("模块A5 可制造性判定规则引擎（验收3：10/10 判据可复跑）")
        print("=" * 70)
        for r in stats["results"]:
            verdict = "可制造" if r["feasible"] else "不可制造"
            print("  {:<8} {:<6} 规则:{}  结论:{}".format(
                r["case_id"], verdict, ",".join(r["matched_rules"]) if r["matched_rules"] else "-",
                r["reasons"][0] if r["reasons"] else "-"))
        print("  判定得分 {}/{}".format(stats["score"], stats["total"]))
        if stats["mismatches"]:
            print("  不一致项:")
            for m in stats["mismatches"]:
                print("    ", m)
    ok = stats["score"] == stats["total"] and stats["total"] >= 10
    stats["ok"] = ok
    return stats


if __name__ == "__main__":
    run_mfg_demo()
