---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 1fcf3b7f0441803325c1c7498ed7e993_80759a2ad2a111f18460525400393706
    ReservedCode1: swBsGebprUolIrR6YTWMY0w9ULEPtGEjtEG/e1ZywjxRPc85MFVBpe5fRNoHRtxvC+vCWWNivzZaQQfH4BTeQoyRrtMmaXGpEic2JcXVIplJKFOdEgWSsL1JC9UjaeLOii3nEPTRulv3tnoORKGNrZqvLueTze4DlZnnN0BBk3QW1+TgXVvNyvC4Mrs=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 1fcf3b7f0441803325c1c7498ed7e993_80759a2ad2a111f18460525400393706
    ReservedCode2: swBsGebprUolIrR6YTWMY0w9ULEPtGEjtEG/e1ZywjxRPc85MFVBpe5fRNoHRtxvC+vCWWNivzZaQQfH4BTeQoyRrtMmaXGpEic2JcXVIplJKFOdEgWSsL1JC9UjaeLOii3nEPTRulv3tnoORKGNrZqvLueTze4DlZnnN0BBk3QW1+TgXVvNyvC4Mrs=
---





# ClawHunt #1724 一期成品仓库（模块 A + B + C + D + 交付工程）
# ClawHunt #1724 Phase-1 Deliverable Repository (Modules A + B + C + D + Delivery Engineering)

<!-- PUBLISH-NOTICE -->
> ⚠️ **发布版声明 / PUBLISH BUILD NOTICE（防白嫖 / anti-freeloading）**：本目录为**去核心化的演示骨架（GitHub 发布版）**，与完整版（`../prototype`，本地备份基线）分离。
> This directory is a **de-cored demonstration skeleton (GitHub publish build)**, kept separate from the full build (`../prototype`, the local backup baseline).
> 已移除全部核心商业实现并替换为占位桩（stub）：授权字段强校验、可制造性评估引擎、C2M 订单状态机、企业 AI 服务层、三语站点生成/SEO/CRM 闭环、IP 授权矩阵、短剧样片生成管线、赛事评分/KPI 判定等核心逻辑**均将于中标后提供**（代码注释与运行时输出统一标注「核心实现将于中标后提供 / full implementation provided after award」）。
> All core commercial implementations have been removed and replaced with stubs: authorization field validation, manufacturability engine, C2M order state machine, enterprise AI service layer, trilingual site generation/SEO/CRM loop, IP licensing matrix, short-drama sample pipeline, contest scoring/KPI logic — **all will be provided after award** (code comments and runtime output are uniformly marked "full implementation provided after award").
> 本发布版保证可正常导入、可跑演示骨架流程，但业务结果不真实、验收指标不再全绿（tests 核心用例、verify all_green、合规六项中的审核/授权项将按预期失败）。
> This publish build is guaranteed to import cleanly and run the demo skeleton flow, but business results are not real and verification indicators are no longer all-green (core test cases, verify all_green, and the compliance audit/licensing items are expected to fail as designed).
> 约束仍为：**纯 Python 标准库 / 零第三方依赖 / 离线可运行 / 确定性输出**；全部数据为合成脱敏样例。
> Constraints remain: **pure Python standard library / zero third-party dependencies / offline deterministic runs**; all data is synthetic and anonymized.

> 以 `../proposal_Task1724.md` 为蓝本的一期交付成品：四模块全绿 + 三平台一键安装/运行 + 100+ 测试 + 验证记录 + 合规检查。
> Phase-1 deliverable built against `../proposal_Task1724.md`: all four modules green + one-click install/run on three platforms + 100+ tests + verification records + compliance checks.
> 约束：**纯 Python 标准库 / 零第三方依赖 / 离线可运行 / 确定性输出**；全部数据为合成脱敏样例。
> Constraints: **pure Python standard library / zero third-party dependencies / offline-runnable / deterministic output**; all data are synthetic, anonymized samples.

## 一、项目简介
## 1. Project Overview

本仓库是 ClawHunt #1724「AI 自产自测」试点的一期成品：
This repository is the Phase-1 deliverable of the ClawHunt #1724 "AI self-production & self-verification" pilot:
以文化 IP 纹样（灯彩/木作题材）为样本，交付 **模块 A（授权强校验 + 可制造性 + C2M 订单）**、
**模块 B（企业 AI 服务层 + 出海增长栈 + FDE 手册）**、**模块 C（文化 IP 管线）**、
**模块 D（赛事包）**，以及完整交付工程（一键安装/运行、测试套件、验证记录、合规检查）。
Using cultural-IP motif samples (lantern craft / woodworking themes), it delivers **Module A (strict authorization validation + manufacturability + C2M orders)**, **Module B (enterprise AI service layer + export growth stack + FDE handbook)**, **Module C (cultural IP pipeline)**, **Module D (contest package)**, plus the complete delivery engineering (one-click install/run, test suite, verification records, compliance checks).

三条主命令可复跑、输出确定：
The three primary commands are re-runnable and produce deterministic output:
- `python demo.py`：一键演示四模块典型场景；
  - `python demo.py`: one-click demo of typical scenarios across all four modules;
- `python tests.py`：单元测试（当前 125 例，全绿）；
  - `python tests.py`: unit tests (currently 125 cases, all green);
- `python verify.py`：全量验证（demo 关键断言 + 全部测试，输出 JSON 快照，退出码 0=全绿）。
  - `python verify.py`: full verification (demo key assertions + all tests, outputs a JSON snapshot, exit code 0 = all green).

## 二、目录结构
## 2. Directory Structure

```
prototype/
├── README.md                  # 本文件（项目简介 / 快速开始 / 验收映射 / 验证记录 / 合规声明）
├── VERIFICATION.md            # 验证记录文件（命令、结果、测试/断言数、verify 快照）
├── server.py                  # 零依赖 HTTP 服务（标准库 ThreadingHTTPServer，Web 工作台 + API + 样片静态服务）
├── start.py                   # 跨平台统一入口：环境检查→初始化自检→合规检查→复跑 demo/tests/verify
├── run.ps1                    # Windows 一键运行（PowerShell）
├── run.sh                     # macOS / Linux 一键运行（Bash）
├── demo.py                    # 演示命令（四模块典型场景）
├── tests.py                   # 自动化测试命令（unittest，125 例）
├── verify.py                  # 全量验证命令（JSON 结果 + 退出码）
├── scripts/
│   ├── init_check.py          # 初始化自检：环境/零三方依赖 AST 扫描/JSON 完整性/离线
│   └── compliance_check.py    # 合规检查：依赖/安全词审核/IP 授权/数据边界/许可/文档一致性
├── module_a/                  # 验收 2/3/4：授权字段校验 / 可制造性 / C2M 订单
│   ├── auth_fields.py
│   ├── manufacturability.py
│   ├── order_machine.py
│   └── data/                  # pattern_samples / mfg_rules_* / equipment_capabilities / mfg_cases
├── module_b/                  # 验收 5/6：企业 AI 服务层 / 出海增长栈 / FDE
│   ├── component_registry.py
│   ├── enterprise_service.py
│   ├── export_stack.py
│   ├── fde_handbook.py
│   └── data/                  # components / industry_config_* / site_content_* / seo_cases / crm_cases / fde_handbook / enterprise_profile_sample
├── module_c/                  # 验收 7：文化 IP 管线（角色 / 资产 / 内容管线 / 授权与审核）
│   ├── characters.py
│   ├── assets.py
│   ├── pipeline.py
│   ├── license.py
│   └── data/                  # characters / visual_recipes / asset_registry / safety_words / license_matrix / script_sample
├── module_d/                  # 赛事包（赛道 / 评审计分 / 打样流程 / 传播 KPI）
│   ├── contest.py
│   └── data/contest_config.json
└── output/                    # 演示生成产物
    ├── episode_demo/          # 模块 C 分镜帧（SVG/PNG）+ review_log
    └── sites/                 # 模块 B 三语站点（zh/en/de）
```

## 三、三平台快速开始（干净机器，零安装）
## 3. Quick Start on Three Platforms (Clean Machine, Zero Installation)

要求：仅需 Python 3.7+（本仓库只使用标准库，无需 `pip install` 任何包）。
Requirement: Python 3.7+ only (this repository uses only the standard library; no `pip install` of any package is required).

| 平台 | 一键命令 |
|---|---|
| Windows | `.\run.ps1`（或右键“使用 PowerShell 运行”） |
| macOS / Linux | `chmod +x run.sh && ./run.sh` |
| 任意平台（含无 Shell 场景） | `python start.py` |

| Platform | One-command entry |
|---|---|
| Windows | `.\run.ps1` (or right-click "Run with PowerShell") |
| macOS / Linux | `chmod +x run.sh && ./run.sh` |
| Any platform (including shell-less environments) | `python start.py` |

`run.ps1` / `run.sh` / `start.py` 会依次执行：**环境检查（python3 存在与版本）→ 初始化自检（零第三方依赖、JSON 配置/数据完整性、离线）→ 合规检查 → 一键复跑 demo/tests/verify → 汇总 JSON**，最终退出码 0 表示全绿。
`run.ps1` / `run.sh` / `start.py` run, in order: **environment check (python3 presence and version) → initialization self-check (zero third-party dependencies, JSON config/data integrity, offline) → compliance check → one-click re-run of demo/tests/verify → aggregated JSON**; a final exit code of 0 means everything is green.

手动分步执行：
Manual step-by-step execution:

```bash
python scripts/init_check.py       # 初始化自检（退出码 0=通过）
python scripts/compliance_check.py # 合规检查（退出码 0=通过）
python demo.py                     # 演示四模块典型场景
python tests.py                    # 单元测试 125 例
python verify.py                   # 全量验证 JSON 快照
```

## 四、命令说明
## 4. Command Reference

| 命令 | 作用 | 退出码语义 |
|---|---|---|
| `start.py` | 统一入口：检查+复跑+汇总 | 0=全绿 |
| `run.ps1` / `run.sh` | 平台一键脚本（调用 start.py） | 0=全绿 |
| `server.py` | 零依赖 HTTP 服务：Web 工作台 + /api/* + /media/* 样片 | 启动后 0=正常 |
| `demo.py` | 演示授权正反例 / 10/10 判据 / 订单台账 / 模块 B/C/D 场景 | 0=正常 |
| `tests.py` | unittest 套件（125 例，覆盖 A/B/C/D 规则边界） | 0=全过 |
| `verify.py` | demo 关键断言 + 全部测试，输出 JSON（含 `all_green`） | 0=全绿 |
| `scripts/init_check.py` | 环境 / 零三方依赖 AST 扫描 / 22 个 JSON 完整性 / 离线 | 0=通过 |
| `scripts/compliance_check.py` | 验收 10 六项合规检查 | 0=通过 |

| Command | Purpose | Exit-code semantics |
|---|---|---|
| `start.py` | Unified entry: checks + re-run + summary | 0 = all green |
| `run.ps1` / `run.sh` | Platform one-click scripts (invoke start.py) | 0 = all green |
| `server.py` | Zero-dep HTTP server: workbench + /api/* + /media/* samples | 0 = normal once serving |
| `demo.py` | Demos positive/negative authorization cases / 10/10 criteria / order ledger / Module B/C/D scenarios | 0 = normal |
| `tests.py` | unittest suite (125 cases covering A/B/C/D rule boundaries) | 0 = all passed |
| `verify.py` | Demo key assertions + all tests, outputs JSON (incl. `all_green`) | 0 = all green |
| `scripts/init_check.py` | Environment / zero third-party dependency AST scan / 22 JSON integrity / offline | 0 = passed |
| `scripts/compliance_check.py` | Acceptance-10 six-item compliance checks | 0 = passed |

### 4.1 零依赖 HTTP 服务与 Web 工作台（server.py）
### 4.1 Zero-Dependency HTTP Server and Web Workbench (server.py)

`server.py` 基于 Python 标准库 `http.server.ThreadingHTTPServer`，零第三方依赖、离线可运行，同时提供 API、前端工作台与样片静态服务：
`server.py` is built on the Python stdlib `http.server.ThreadingHTTPServer` — zero third-party dependencies, offline-runnable — serving APIs, the front-end workbench, and sample videos at once:

| 路由 Route | 说明 Description |
|---|---|
| `/api/health` | 健康检查：返回版本 / 技术栈 / 模块状态（真实接口）Health: version / stack / module status (real endpoint) |
| `/api/industries` | 可配置行业列表：jewelry / wood（真实接口，读 module_b 配置）Configurable industries: jewelry / wood (real endpoint, reads module_b config) |
| `/api/components/{industry}` | 行业组件清单（真实接口，调 `module_b.enterprise_service` / `component_registry`）Industry components (real endpoint, via module_b) |
| `/media/*` | 样片视频静态服务（output/demo_video，支持 Range 断点）Sample video static service (output/demo_video, Range supported) |
| `/` | Web 工作台（web/ 静态站点，index.html / assets/*）Web workbench (web/ static site) |

启动方式（任一平台，Python 3.7+）：
Start it on any platform (Python 3.7+):

```bash
python server.py                       # 默认 127.0.0.1:8000
python server.py --host 0.0.0.0 --port 8000   # 局域网/容器内访问
```

- 目录缺失时自动创建（output/demo_video、web），避免启动失败；`output` 由 `demo.py` / `verify.py` 生成，若尚未生成可先运行 `python start.py` 或 `python demo.py`。
  Missing directories are auto-created to avoid startup failure; run `python start.py` / `python demo.py` first if `output` is not yet generated.

Web 工作台（`web/`）为**原生 HTML/CSS/JS，零构建链（无 React/Vite/npm）**，复刻重技术栈版 7 页签工作台：**A 创意工作台 / B 企业AI服务层 / C IP工作室 / D 赛事包 / 订单与工厂 / 契约与规则 / 验收与部署**，深色主题（#0a1220 / #2dd4bf），三语切换 **zh / en / de**；A/B/验收页签数据驱动真实调用 `/api/*`，C 页签含"申请查看样片（演示）"弹窗播放 `/media/ai_demo_1080p_voice_neil_bgm_v5.mp4`（404 时显示"演示样片按防白嫖约定隐藏，中标后提供"占位），验收页含 G1-G10 自检清单与端口表；订单/询盘/报名等交互演示仅在前端本地台账，不编造后端端点。
The workbench (`web/`) is **native HTML/CSS/JS with no build chain (no React/Vite/npm)**, mirroring the heavy-stack 7-tab workbench: **A Studio / B Enterprise AI / C IP Studio / D Contest / Orders & Factory / Contracts & Rules / Acceptance & Deploy**, dark theme (#0a1220 / #2dd4bf), trilingual switch **zh / en / de**; tabs A/B/acceptance are data-driven with real `/api/*` calls; tab C includes a "Request Sample (Demo)" modal playing `/media/ai_demo_1080p_voice_neil_bgm_v5.mp4` (404 shows the "demo samples hidden per anti-free-ride agreement" placeholder); the acceptance tab lists the G1-G10 checklist and port table; order/inquiry/registration demos live in the frontend ledger only and invent no backend endpoints.

### 4.2 一键部署（Docker Compose / 三平台一键脚本）
### 4.2 One-Click Deployment (Docker Compose / Cross-Platform One-Click Scripts)

`deploy/` 提供容器化一键部署，镜像基于 `python:3.11-slim`，COPY 仓库并 `python server.py --host 0.0.0.0 --port 8000`，暴露 8000 端口；`output` 通过卷挂载（`../output:/app/output`），样片更新无需重建镜像。
`deploy/` provides containerized one-click deployment: image `python:3.11-slim`, copies the repo and runs `python server.py --host 0.0.0.0 --port 8000`, exposing port 8000; `output` is volume-mounted (`../output:/app/output`) so sample updates need no image rebuild.

三平台一键部署脚本（幂等，自动检测并安装缺失的 docker / docker compose；无需 npm）：
Cross-platform one-click deployment scripts (idempotent; auto-detect and install missing docker / docker compose; no npm needed):

| 平台 / Platform | 一键命令 / One-click command |
|---|---|
| Windows | `powershell -ExecutionPolicy Bypass -File deploy\install_windows.ps1` |
| Linux（通用，含 Ubuntu / Debian / CentOS / Fedora） / Linux (generic: Ubuntu / Debian / CentOS / Fedora) | `sudo bash deploy/install_linux.sh` |
| macOS | `bash deploy/install_macos.sh` |
| Ubuntu（专版，含干净机器） / Ubuntu (dedicated, incl. clean machine) | `sudo bash deploy/install_ubuntu_onekey.sh` |

平台说明：
Platform notes:
- Windows：未装 docker 时自动用 winget 安装 Docker Desktop（装完需先启动 Docker Desktop 再重跑）；compose 插件缺失时自动下载官方二进制到用户级插件目录。
  If docker is missing, installs Docker Desktop via winget automatically (start Docker Desktop and re-run afterwards); downloads the official compose binary to the user-level plugin dir if missing.
- Linux：未装 docker 时用官方 get.docker.com 自动识别发行版安装；compose 插件缺失时下载官方二进制到 /usr/local/lib/docker/cli-plugins。
  If docker is missing, installs via official get.docker.com with auto distro detection; downloads the official compose binary to /usr/local/lib/docker/cli-plugins if missing.
- macOS：未装 docker 时用 Homebrew 安装 Docker Desktop（`brew install --cask docker`），装完启动后重跑；compose 插件缺失时下载到 ~/.docker/cli-plugins。
  If docker is missing, installs Docker Desktop via Homebrew (`brew install --cask docker`), start it and re-run; downloads the official compose binary to ~/.docker/cli-plugins if missing.
- Ubuntu 专版脚本行为同 Linux 通用版：检测并安装 docker / docker compose、docker 组检查与 sudo 回退、`docker compose up -d --build`、打印访问地址。
  The Ubuntu-specific script behaves like the generic Linux script: detects & installs docker / docker compose, docker-group check with sudo fallback, `docker compose up -d --build`, prints access URLs.

脚本行为（`set -euo pipefail`，输出 `[OK]` / `[SKIP]` / `[FAIL]` 状态）：检测并安装 docker（get.docker.com）→ 检测并安装 docker compose 插件 → 检测 python3（容器内自带，仅提示）→ docker 组检查与 sudo 回退 → `docker compose up -d --build` → 打印访问地址。
The script (`set -euo pipefail`, prints `[OK]` / `[SKIP]` / `[FAIL]`) detects and installs docker (get.docker.com) → docker compose plugin → checks python3 (containerized, informational only) → docker-group check with sudo fallback → `docker compose up -d --build` → prints access URLs.

手动执行 Docker Compose：
Or run Docker Compose manually:

```bash
cd deploy
docker compose up -d --build     # 服务名 app，端口 8000:8000
docker compose logs -f app
docker compose down
```

`.dockerignore` 排除 `__pycache__` / `.pytest_cache` / `temp` / `output` / `prototype_publish` / `node_modules` 等，镜像只含运行所需。
`.dockerignore` excludes `__pycache__` / `.pytest_cache` / `temp` / `output` / `prototype_publish` / `node_modules`, keeping only runtime essentials in the image.

## 五、验收标准 0-10 逐条映射
## 5. Acceptance Criteria 0-10 Mapped Item by Item

| # | 验收标准 | 实现位置 | 验证方式 |
|---|---|---|---|
| 0 | 成果优先，可复跑闭环 | `demo.py` / `tests.py` / `verify.py` / `start.py` | 三条命令退出码 0，`verify.py` 输出 `all_green: true` |
| 1 | 一键启动 | `run.ps1` / `run.sh` / `start.py` | 环境检查 → 初始化 → 复跑 → 汇总，退出码 0 |
| 2 | 授权字段强校验 | `module_a/auth_fields.py` + `pattern_samples.json` | `TestAuthFields` / `TestAuthEdgeCases`（逐字段缺失反例） |
| 3 | 可制造性 10/10 | `module_a/manufacturability.py` + `mfg_cases.json`（10 例含 3 反例） | `verify.py` `manufacturability.score=10/10` |
| 4 | C2M 订单链路可追溯 | `module_a/order_machine.py` | `TestOrderMachine` / `TestOrderEdgeCases`（6 状态、台账字段、非法转换） |
| 5 | 企业 AI 服务层 | `module_b/enterprise_service.py` + 2 行业配置 | `TestEnterpriseService` / `TestServiceEdgeCases`（行业切换、知识库兜底） |
| 6 | 出海增长栈 | `module_b/export_stack.py`（三语站点/SEO/CRM） | `TestSiteGeneration` / `TestSeoAudit` / `TestCrmFlow` / `TestExportEdgeCases` |
| 7 | IP 样片与管线 | `module_c/`（角色/资产/管线/授权/审核）+ `module_d/`（赛事包） | `TestModuleC*` / `TestModuleD*`（授权门禁、审核拦截、评分边界） |
| 8 | 单测 ≥100 | `tests.py` | 125 例全绿（覆盖 A/B/C/D 正反例、配置损坏/缺失、行业切换、多语言、CRM SLA、IP 授权门禁、审核拦截、赛事评分边界） |
| 9 | 文档一致 | `README.md` / `VERIFICATION.md` | `scripts/compliance_check.py` 文档一致性检查：README 提及命令与实现一一对应 |
| 10 | 合规 | `scripts/compliance_check.py` | 六项合规全 PASS（依赖/审核/IP/数据/许可/文档） |

| # | Acceptance criterion | Implementation location | Verification method |
|---|---|---|---|
| 0 | Results first, re-runnable closed loop | `demo.py` / `tests.py` / `verify.py` / `start.py` | All three commands exit 0; `verify.py` outputs `all_green: true` |
| 1 | One-click startup | `run.ps1` / `run.sh` / `start.py` | Environment check → init → re-run → summary, exit code 0 |
| 2 | Strict authorization-field validation | `module_a/auth_fields.py` + `pattern_samples.json` | `TestAuthFields` / `TestAuthEdgeCases` (negative cases with per-field missing values) |
| 3 | Manufacturability 10/10 | `module_a/manufacturability.py` + `mfg_cases.json` (10 cases incl. 3 negatives) | `verify.py` `manufacturability.score=10/10` |
| 4 | Traceable C2M order flow | `module_a/order_machine.py` | `TestOrderMachine` / `TestOrderEdgeCases` (6 states, ledger fields, illegal transitions) |
| 5 | Enterprise AI service layer | `module_b/enterprise_service.py` + 2 industry configs | `TestEnterpriseService` / `TestServiceEdgeCases` (industry switching, knowledge-base fallback) |
| 6 | Export growth stack | `module_b/export_stack.py` (tri-lingual sites/SEO/CRM) | `TestSiteGeneration` / `TestSeoAudit` / `TestCrmFlow` / `TestExportEdgeCases` |
| 7 | IP samples and pipeline | `module_c/` (characters/assets/pipeline/license/review) + `module_d/` (contest package) | `TestModuleC*` / `TestModuleD*` (license gate, review blocking, scoring boundaries) |
| 8 | Unit tests ≥100 | `tests.py` | 125 cases all green (covering A/B/C/D positive & negative cases, broken/missing config, industry switching, multi-language, CRM SLA, IP license gate, review blocking, contest scoring boundaries) |
| 9 | Documentation consistency | `README.md` / `VERIFICATION.md` | `scripts/compliance_check.py` doc-consistency check: commands mentioned in README map one-to-one to implementations |
| 10 | Compliance | `scripts/compliance_check.py` | All six compliance items PASS (dependency/review/IP/data/license/documentation) |

## 六、验证记录（当前基线）
## 6. Verification Records (Current Baseline)

完整命令与输出见 **[VERIFICATION.md](./VERIFICATION.md)**。摘要：
For the full commands and outputs, see **[VERIFICATION.md](./VERIFICATION.md)**. Summary:

| 项 | 结果 |
|---|---|
| `python tests.py` | 125 例，0 失败 0 错误 |
| `python verify.py` | `all_green: true`，退出码 0；可制造性 10/10；模块 B/C/D 全 ok |
| `python scripts/init_check.py` | 零第三方依赖、联网导入为空、22 个 JSON 完整性通过 |
| `python scripts/compliance_check.py` | 6/6 合规项 PASS |

| Item | Result |
|---|---|
| `python tests.py` | 125 cases, 0 failures, 0 errors |
| `python verify.py` | `all_green: true`, exit code 0; manufacturability 10/10; Modules B/C/D all ok |
| `python scripts/init_check.py` | Zero third-party dependencies, no network imports, 22 JSON integrity checks passed |
| `python scripts/compliance_check.py` | 6/6 compliance items PASS |

> 复跑准则：任一台干净机器执行 `python start.py`（或平台脚本）即可复现上述基线；输出确定性由固定模拟时钟与固定随机种子保证。
> Reproduction guideline: running `python start.py` (or the platform script) on any clean machine reproduces the baseline above; output determinism is guaranteed by a fixed simulated clock and fixed random seeds.

## 七、合规声明
## 7. Compliance Statement

- **开源许可**：本仓库作为 ClawHunt #1724 投标交付原型对外展示，遵循开源许可证发布（MIT License，见交付包许可声明）；使用方需按 proposal 约定履行署名与标注义务。
  - **Open-source license**: this repository is exhibited as the ClawHunt #1724 bid-delivery prototype and is released under an open-source license (MIT License; see the license statement in the delivery package); users must fulfill the attribution and labeling obligations agreed in the proposal.
- **零第三方依赖**：全部源码仅使用 Python 标准库（`json` / `unittest` / `os` / `datetime` / `re` / `ast` / `subprocess` 等），AST 级扫描确认无第三方 import、无联网调用，**纯离线可运行**。
  - **Zero third-party dependencies**: all source code uses only the Python standard library (`json` / `unittest` / `os` / `datetime` / `re` / `ast` / `subprocess`, etc.); AST-level scans confirm no third-party imports and no network calls, so the repository is **fully offline-runnable**.
- **数据边界与隐私**：仓库内全部数据为**合成 / 脱敏样例**（工坊、授权主体、角色、企业、客户、纹样均为虚构标注），经 PII 正则扫描无真实手机号/身份证/银行卡/邮箱。
  - **Data boundary and privacy**: all data in the repository are **synthetic / anonymized samples** (workshops, license holders, characters, enterprises, customers, and motifs are all fictional); PII regex scans find no real phone numbers, ID numbers, bank cards, or email addresses.
- **IP 原型非独占**：文化原型与宗教场所名称**不被声明为独占权利**；原创再创作部分另行标注授权；IP 授权矩阵含 3 类授权（IP / 衍生品 / 赛事）+ 4 类衍生品规范 + 审批门禁与 AI 生成标识要求。
  - **IP prototypes are non-exclusive**: cultural prototypes and names of religious sites are **not claimed as exclusive rights**; original re-creations are separately labeled with authorization; the IP license matrix covers 3 license types (IP / derivatives / contests) + 4 derivative-spec categories + approval gates and AI-generated labeling requirements.
- **内容安全**：内置安全词表（禁用词/品牌词）与 AI 标识门禁，违规内容由审核链路拦截并留档（review_log）。
  - **Content safety**: a built-in safety word list (banned words / brand words) and an AI-label gate; non-compliant content is blocked by the review pipeline and archived (review_log).
- **AI 生成标识**：本仓库为 AI 试点产物，演示/验证记录均含 AI 生成标注；正式交付时按验收 10 口径补充最终合规清单。
  - **AI-generated labeling**: this repository is an AI pilot artifact; demo and verification records all carry AI-generation labels; the final compliance checklist will be supplemented per acceptance item 10 at formal delivery.

## 八、演示样片与发布压缩包
## 8. Demo Samples and Release Archive

### 8.1 发布版样片（正式样片保留）
### 8.1 Publish-Edition Sample (Official Sample Kept)

- **产物（保留正式样片）**：
  **Artifacts (official sample kept)**:
  - `output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4`：**正式演示样片（发布版保留）**，1920x1080、H.264（yuv420p、faststart）、AI 配音、约 15 MB；Web 工作台 C 页签"申请查看样片（演示）"弹窗播放 `/media/ai_demo_1080p_voice_neil_bgm_v5.mp4`（部署后经 8000 端口访问）。
    - `output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4`: **official demo sample (kept in publish edition)**, 1920x1080, H.264 (yuv420p, faststart), AI voice-over, ~15 MB; tab C "Request Sample (Demo)" modal plays `/media/ai_demo_1080p_voice_neil_bgm_v5.mp4` (served on port 8000 after deployment).
- **剔除项（发布版不含）**：demo_v2 系列（demo_v2.gif/mp4/srt）、历史版本样片（无版本号及 v2/v3/v4 等 neil 版、voice/bgm/cloud 版）、关键帧（ai_frames/、ai_frames_1080p/）、拼接片段（temp_clips/）、拼接中间产物（_1080p_work/）、私有配音（tts_voices/、tts_voices_neil/）一律不进入发布版；若样片缺失，前端显示"演示样片按防白嫖约定隐藏，中标后提供"占位。
  **Excluded (not in publish edition)**: demo_v2 series (demo_v2.gif/mp4/srt), historical sample versions (unversioned and v2/v3/v4 neil builds, voice/bgm/cloud builds), keyframes (ai_frames/, ai_frames_1080p/), stitching clips (temp_clips/), stitching intermediates (_1080p_work/), private voices (tts_voices/, tts_voices_neil/) — none enter the publish edition; if a sample is missing, the frontend shows the "demo samples hidden per anti-free-ride agreement; provided after award" placeholder.
- **说明**：本轮按用户要求调整防白嫖约定——发布版**保留正式样片**（供样片查看功能演示），其余私有资产仍全部剔除；完整版（含全部样片与私有资产）本地保留，绝不对外发布。
  **Notes**: per this round's client request, the anti-free-ride convention is adjusted — the publish edition **keeps the official sample** (for the sample-viewing feature) while all other private assets remain excluded; the full edition (all samples & private assets) stays local and is never published.

### 8.2 发布压缩包
### 8.2 Release Archive

- **产物**：`D:\projects\clawhunt\03_proposal\Task1724\Task1724_prototype_publish_v1.0.zip`（zip 内顶层目录 `Task1724_prototype_publish_v1.0/`，去核心化发布版，含正式样片 v5）。
  **Artifacts**: `D:\projects\clawhunt\03_proposal\Task1724\Task1724_prototype_publish_v1.0.zip` (top-level directory inside the zip: `Task1724_prototype_publish_v1.0/`, de-cored publish build including official sample v5).
- **生成方式**：`python scripts/make_publish.py`（从 `../prototype` 原版重新生成，保证发布版与原版只差去核心化 + 资产剔除一层变换）。
  **Generation**: `python scripts/make_publish.py` (regenerated from the `../prototype` full build, ensuring the publish build differs from the full build only by the de-coring + asset-exclusion transform).
- **样片说明**：发布包内样片为 **`output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4`（1920x1080 AI 配音正式样片）**；demo_v2 系列及历史版本已移除，不再分发。
  **Sample notes**: the sample inside the publish package is **`output/demo_video/ai_demo_1080p_voice_neil_bgm_v5.mp4` (1920x1080, AI voice-over, official)**; the demo_v2 series and historical versions have been removed and are no longer distributed.

*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
