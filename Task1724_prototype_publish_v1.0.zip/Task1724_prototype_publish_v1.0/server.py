# -*- coding: utf-8 -*-
"""ClawHunt #1724 零依赖版 HTTP 服务（纯 Python 标准库，离线可运行）。

用法:
    python server.py --host 0.0.0.0 --port 8000

路由:
    /api/health                服务健康与技术栈信息（stack 信息）
    /api/industries            支持的行业列表（module_b.enterprise_service）
    /api/components/{industry} 行业组件清单（module_b.component_registry）
    /media/*                   output/demo_video 下静态视频/样片（支持 Range，浏览器可拖动）
    / 与静态文件               零依赖 Web 工作台（web/index.html）

说明:
    - 仅使用 Python 标准库（http.server / json / argparse / os / sys），无第三方依赖；
    - http.server 为服务端监听组件，是交付功能而非外联调用，仓库保持离线可运行；
    - output/demo_video、web 目录缺失时自动创建，避免启动失败；
    - 核心业务在 module_a~d，本服务只做薄适配层（与重技术栈 app/main.py API 语义对齐）。
"""
import argparse
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(ROOT, "web")
MEDIA_DIR = os.path.join(ROOT, "output", "demo_video")

# 兜底行业列表（module_b.enterprise_service 可导入时以其为准）
FALLBACK_INDUSTRIES = ("jewelry", "wood")

_INDUSTRY_DISPLAY = {
    "jewelry": "珠宝行业 · Jewelry & Craft",
    "wood": "木作行业 · Woodworking",
}

MIME_MAP = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".mp4": "video/mp4",
    ".gif": "image/gif",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".wav": "audio/wav",
    ".srt": "text/plain; charset=utf-8",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/markdown; charset=utf-8",
    ".ico": "image/x-icon",
}


def _percent_decode(s):
    """简易 percent-decode（%XX -> 字符），避免引入 urllib 依赖。"""
    out = bytearray()
    i = 0
    while i < len(s):
        if s[i] == "%" and i + 2 < len(s):
            try:
                out.append(int(s[i + 1:i + 3], 16))
                i += 3
                continue
            except ValueError:
                pass
        out.extend(s[i].encode("utf-8"))
        i += 1
    try:
        return out.decode("utf-8")
    except UnicodeDecodeError:
        return s


def _json_bytes(payload):
    return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")


def _industries_payload():
    ids = list(FALLBACK_INDUSTRIES)
    try:
        from module_b.enterprise_service import SUPPORTED_INDUSTRIES
        ids = list(SUPPORTED_INDUSTRIES)
    except Exception:
        pass
    return {
        "industries": [
            {"id": i, "display_name": _INDUSTRY_DISPLAY.get(i, i)} for i in ids
        ],
        "offline": True,
    }


def _components_payload(industry):
    """返回某行业组件清单；模块缺失/异常时返回 stub 占位（发布版兜底）。"""
    try:
        from module_b.component_registry import ComponentRegistry
        reg = ComponentRegistry()
        comps = reg.list_components(industry)
        if not comps and industry not in _industries_payload()["industries"]:
            raise ValueError("不支持的行业: %s" % industry)
        return {"industry": industry, "components": comps, "stub": False}
    except Exception as exc:
        return {
            "industry": industry,
            "components": [],
            "stub": True,
            "note": "核心实现将于中标后提供（full implementation provided after award）",
            "detail": str(exc),
        }


def _safe_join(base, rel):
    """拼接静态文件路径并做路径遍历防护（拒绝 .. 跳转）。"""
    rel = rel.replace("\\", "/")
    if rel.startswith("/"):
        rel = rel.lstrip("/")
    parts = [p for p in rel.split("/") if p not in ("", ".", "..")]
    joined = os.path.normpath(os.path.join(base, *parts))
    base_norm = os.path.normpath(base)
    if not joined.startswith(base_norm + os.sep) and joined != base_norm:
        return None
    return joined


class Handler(BaseHTTPRequestHandler):
    server_version = "ClawHuntZeroDep/1.0"

    # ---------- 基础 ----------
    def log_message(self, fmt, *args):
        sys.stdout.write("[%s] %s\n" % (self.address_string(), fmt % args))

    def _send_json(self, payload, status=200):
        body = _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, full, status=200, start=0, end=None):
        size = os.path.getsize(full)
        if end is None or end >= size:
            end = size - 1
        if start > end:
            self.send_error(416, "Requested Range Not Satisfiable")
            return
        length = end - start + 1
        ctype = MIME_MAP.get(os.path.splitext(full)[1].lower(),
                             "application/octet-stream")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range",
                             "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()
        with open(full, "rb") as f:
            f.seek(start)
            remaining = length
            while remaining > 0:
                chunk = f.read(min(65536, remaining))
                if not chunk:
                    break
                self.wfile.write(chunk)
                remaining -= len(chunk)

    def _handle_static(self, root_dir, rel, allow_index=True):
        if rel == "/" or rel == "":
            if not allow_index:
                return False
            rel = "index.html"
        full = _safe_join(root_dir, rel)
        if full is None or not os.path.isfile(full):
            return False
        try:
            self._serve_with_range(full)
        except BrokenPipeError:
            pass
        return True

    def _serve_with_range(self, full):
        size = os.path.getsize(full)
        start, end = 0, None
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes="):
            spec = rng[len("bytes="):].split(",", 1)[0].strip()
            if "-" in spec:
                a, b = spec.split("-", 1)
                if a == "":
                    # 末尾 N 字节
                    n = int(b) if b.isdigit() else 0
                    start = max(0, size - n)
                    end = size - 1
                else:
                    start = int(a)
                    end = int(b) if b else size - 1
            if start >= size:
                self.send_error(416, "Requested Range Not Satisfiable")
                return
            self._send_file(full, status=206, start=start, end=end)
        else:
            self._send_file(full, status=200)

    # ---------- 路由 ----------
    def do_GET(self):
        self._route()

    def do_HEAD(self):
        # 简化 HEAD：同 GET 处理（客户端主要用 GET）
        self._route(head_only=True)

    def _route(self, head_only=False):
        path = self.path.split("?", 1)[0]
        decoded = _percent_decode(path)

        if decoded == "/api/health":
            payload = {
                "status": "ok",
                "stack": "Python stdlib ThreadingHTTPServer + Vanilla JS/CSS (zero-build, no npm)",
                "offline": True,
                "modules": ["module_a", "module_b", "module_c", "module_d"],
                "industries": _industries_payload()["industries"],
            }
            self._send_json(payload)
            return

        if decoded == "/api/industries":
            self._send_json(_industries_payload())
            return

        if decoded.startswith("/api/components/"):
            industry = decoded[len("/api/components/"):].strip("/")
            self._send_json(_components_payload(industry))
            return

        if decoded.startswith("/media/"):
            rel = decoded[len("/media/"):]
            if self._handle_static(MEDIA_DIR, rel):
                return
            self._send_json({"error": "not_found", "path": path}, status=404)
            return

        if decoded.startswith("/api/"):
            self._send_json({"error": "unknown_api", "path": path}, status=404)
            return

        if self._handle_static(WEB_DIR, decoded, allow_index=True):
            return

        self._send_json({"error": "not_found", "path": path}, status=404)

    # ---------- 其它方法 ----------
    def do_POST(self):
        self._send_json({"error": "method_not_allowed",
                         "hint": "本服务为零依赖只读工作台服务；POST 交互为前端本地演示"},
                        status=405)


def _ensure_dirs():
    os.makedirs(MEDIA_DIR, exist_ok=True)
    if not os.path.isdir(WEB_DIR):
        os.makedirs(WEB_DIR, exist_ok=True)
        index = os.path.join(WEB_DIR, "index.html")
        if not os.path.exists(index):
            with open(index, "w", encoding="utf-8") as f:
                f.write("<!doctype html><html><head><meta charset='utf-8'>"
                        "<title>ClawHunt #1724 Zero-Dep Workbench</title></head>"
                        "<body><h1>ClawHunt #1724</h1>"
                        "<p>Web workbench assets not ready; run from the full repository.</p>"
                        "</body></html>")


def main():
    parser = argparse.ArgumentParser(
        description="ClawHunt #1724 零依赖版 HTTP 服务（纯标准库）")
    parser.add_argument("--host", default="0.0.0.0", help="监听地址（默认 0.0.0.0）")
    parser.add_argument("--port", type=int, default=8000, help="监听端口（默认 8000）")
    args = parser.parse_args()

    _ensure_dirs()
    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    print("ClawHunt #1724 zero-dep server: http://%s:%d" % (args.host, args.port))
    print("  API:  /api/health  /api/industries  /api/components/{industry}")
    print("  Workbench: /  (web/index.html),  media: /media/<file>")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
