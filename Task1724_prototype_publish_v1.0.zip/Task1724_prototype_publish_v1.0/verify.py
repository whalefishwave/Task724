"""ClawHunt #1724 模块 A 最小可运行闭环原型 - 全量验证命令。

用法：python verify.py
1) 跑全部单元测试（unittest）
2) 跑 demo 三模块关键场景并断言
3) 输出 JSON 结果清单（all_green 决定退出码 0/1），判据可复跑。
"""
import json
import sys
import unittest

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import tests as tests_module
from module_a.auth_fields import run_auth_demo
from module_a.manufacturability import run_mfg_demo
from module_a.order_machine import run_order_demo
from demo import run_module_b_demo, run_module_c_demo, run_module_d_demo


def main():
    results = {}

    # 1. 单元测试全量
    suite = unittest.TestLoader().loadTestsFromModule(tests_module)
    runner = unittest.TextTestRunner(verbosity=1, stream=sys.stdout)
    tr = runner.run(suite)
    results["unit_tests"] = {
        "run": tr.testsRun,
        "failures": len(tr.failures),
        "errors": len(tr.errors),
        "green": (len(tr.failures) == 0 and len(tr.errors) == 0),
    }

    # 2. demo 模块关键场景（静默执行，只取统计）
    auth = run_auth_demo(verbose=False)
    mfg = run_mfg_demo(verbose=False)
    order = run_order_demo(verbose=False)
    module_b = run_module_b_demo(verbose=False)
    module_c = run_module_c_demo(verbose=False)
    module_d = run_module_d_demo(verbose=False)
    results["auth_fields"] = auth
    results["manufacturability"] = {
        "score": mfg["score"], "total": mfg["total"],
        "green": mfg["ok"],
    }
    results["order_machine"] = order
    results["module_b"] = module_b
    results["module_c"] = module_c
    results["module_d"] = module_d

    all_green = (results["unit_tests"]["green"]
                 and auth["ok"] and mfg["ok"] and order["ok"] and module_b["ok"]
                 and module_c["ok"] and module_d["ok"])
    results["all_green"] = all_green

    print("=" * 70)
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("=" * 70)
    print("VERIFY {}".format("PASS" if all_green else "FAIL"))
    return 0 if all_green else 1


if __name__ == "__main__":
    sys.exit(main())
