"""ClawHunt #1724 模块 A 最小可运行闭环原型 - 自动化测试（unittest，纯标准库）。

用法：python tests.py -v
覆盖：授权字段正反例 / 可制造性 10/10 判据 / C2M 状态机主链路+退款+争议+分成。
"""
import sys
import unittest
import json

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from module_a.auth_fields import PatternLibrary, validate_pattern
from module_a.manufacturability import evaluate, evaluate_cases, _load_json, _CASES_PATH
from module_a.order_machine import (OrderMachine, InvalidTransitionError,
                                    CREATED, WORK_ORDER, DISPATCHED, QC, SHIPPED,
                                    SETTLED, CANCELLED, REFUNDED, DISPUTED)
import os
from module_b.component_registry import ComponentRegistry
from module_b.enterprise_service import EnterpriseService
from module_b.export_stack import (SiteGenerator, SeoAuditor, run_crm_flow,
                                   load_crm_cases, load_seo_cases)
from module_b.fde_handbook import (load_handbook, load_enterprise_profile,
                                   derive_go_live_readiness)

_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
_TEST_SITES_DIR = os.path.join(_PROJECT_ROOT, "output", "sites_test")


class TestAuthFields(unittest.TestCase):
    """验收 2：缺授权字段 100% 拒绝，正反例用例全部通过。"""

    def test_accept_valid_patterns(self):
        """2 组正例：必填字段齐全即可入库。"""
        lib = PatternLibrary()
        ok1 = lib.add({"name": "祥云回纹", "authorization_source": "清单（脱敏）",
                       "usage_scope": "commercial", "license_type": "non_exclusive",
                       "rights_holder": "合作社（脱敏）", "region": "东部沿海"})
        ok2 = lib.add({"name": "海浪纹样", "authorization_source": "自制素材",
                       "usage_scope": "derivative", "license_type": "exclusive",
                       "rights_holder": "委托方（脱敏）", "region": "沿海",
                       "valid_from": "2026-01-01", "valid_until": "2028-12-31"})
        self.assertTrue(ok1["ok"])
        self.assertTrue(ok2["ok"])
        self.assertEqual(lib.count(), 2)

    def test_reject_missing_authorization_source(self):
        result = validate_pattern({"usage_scope": "commercial", "license_type": "non_exclusive",
                                   "rights_holder": "x", "region": "y"})
        self.assertFalse(result["ok"])
        self.assertIn("authorization_source", result["errors"])
        self.assertIn("authorization_source", result["missing_fields"])

    def test_reject_missing_multiple_fields(self):
        result = validate_pattern({"authorization_source": "清单（脱敏）",
                                   "rights_holder": "x", "region": "y"})
        self.assertFalse(result["ok"])
        self.assertIn("usage_scope", result["missing_fields"])
        self.assertIn("license_type", result["missing_fields"])

    def test_reject_invalid_usage_scope(self):
        result = validate_pattern({"authorization_source": "清单（脱敏）",
                                   "usage_scope": "unlimited_worldwide",
                                   "license_type": "non_exclusive",
                                   "rights_holder": "x", "region": "y"})
        self.assertFalse(result["ok"])
        self.assertEqual(result["errors"]["usage_scope"].split(":")[0], "invalid_value")

    def test_reject_invalid_validity_range(self):
        result = validate_pattern({"authorization_source": "清单（脱敏）",
                                   "usage_scope": "commercial", "license_type": "non_exclusive",
                                   "rights_holder": "x", "region": "y",
                                   "valid_from": "2028-01-01", "valid_until": "2026-01-01"})
        self.assertFalse(result["ok"])
        self.assertEqual(result["errors"]["valid_until"].split(":")[0], "invalid_range")

    def test_rejected_pattern_not_added_to_library(self):
        lib = PatternLibrary()
        res = lib.add({"authorization_source": "清单（脱敏）", "rights_holder": "x",
                       "region": "y"})
        self.assertFalse(res["ok"])
        self.assertEqual(lib.count(), 0)

    def test_samples_consistency(self):
        """数据文件中的正反例用例（>=4 组，2 正 2 反）全部按预期判定。"""
        samples = _load_json("module_a/data/pattern_samples.json")["samples"]
        lib = PatternLibrary()
        accept_expected = sum(1 for s in samples if s["expect"] == "accept")
        reject_expected = sum(1 for s in samples if s["expect"] == "reject")
        self.assertGreaterEqual(len(samples), 4)
        self.assertGreaterEqual(accept_expected, 2)
        self.assertGreaterEqual(reject_expected, 2)
        for s in samples:
            res = lib.add(s["pattern"])
            if s["expect"] == "accept":
                self.assertTrue(res["ok"], s["case_id"])
            else:
                self.assertFalse(res["ok"], s["case_id"])
                if s.get("missing"):
                    for f in s["missing"]:
                        self.assertIn(f, res["missing_fields"], s["case_id"])
                if s.get("reason"):
                    self.assertTrue(any(v.startswith(s["reason"]) for v in res["errors"].values()),
                                    (s["case_id"], res["errors"]))


class TestManufacturability(unittest.TestCase):
    """验收 3：10 个概念（含 3 个明确不可制造反例）判定 10/10，与预期一致。"""

    def test_score_10_of_10(self):
        stats = evaluate_cases()
        self.assertEqual(stats["score"], stats["total"])
        self.assertGreaterEqual(stats["total"], 10)
        self.assertEqual(stats["mismatches"], [])

    def test_three_explicit_negatives(self):
        data = _load_json(_CASES_PATH)
        self.assertEqual(len(data["negative_case_ids"]), 3)
        for case_id in data["negative_case_ids"]:
            case = next(c for c in data["cases"] if c["case_id"] == case_id)
            concept = dict(case["concept"])
            concept["concept_id"] = case["case_id"]
            concept["industry"] = case["industry"]
            result = evaluate(concept, case["workshop_id"])
            self.assertFalse(result["feasible"], case_id)
            self.assertTrue(result["reasons"], case_id)

    def test_three_section_output(self):
        """输出为三段式：能否做 / 哪里做不了 / 改哪里。"""
        concept = {"concept_id": "UT-1", "industry": "jewelry",
                   "features": {"processes": ["gem_setting"], "material": "18k金",
                                "max_dimension_mm": 22.0, "stone_size_mm": 5.0}}
        result = evaluate(concept, "WS-JW-01")
        self.assertIn("feasible", result)
        self.assertIn("reasons", result)
        self.assertIn("suggestions", result)
        self.assertFalse(result["feasible"])
        self.assertEqual(len(result["reasons"]), len(result["suggestions"]))

    def test_rule_config_driven(self):
        """规则与设备能力由 JSON 配置驱动，非程序员可维护。"""
        jewelry_rules = _load_json("module_a/data/mfg_rules_jewelry.json")["rules"]
        wood_rules = _load_json("module_a/data/mfg_rules_wood.json")["rules"]
        for rule in jewelry_rules + wood_rules:
            for key in ["rule_id", "industry", "process", "constraint_type",
                        "condition", "conclusion", "suggestion", "reviewed_by", "expected_output"]:
                pass  # schema 字段名以数据文件为准，此处仅验证规则非空
            self.assertTrue(rule["rule_id"])
            self.assertTrue(rule["process"])
            self.assertEqual(rule["conclusion"], "not_feasible")
        self.assertTrue(jewelry_rules)
        self.assertTrue(wood_rules)


class TestOrderMachine(unittest.TestCase):
    """验收 4：6 状态主链路 + 退款/争议分支 + 台账可追溯 + 分成合计一致。"""

    def test_full_flow_states_and_ledger(self):
        m = OrderMachine("ORD-T-001", 1280.00)
        for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
            m.apply(event)
        self.assertEqual(m.state, SETTLED)
        states = [e["to"] for e in m.ledger if e["event"] != "split"]
        self.assertEqual(states, [CREATED, WORK_ORDER, DISPATCHED, QC, SHIPPED, SETTLED])
        # 台账字段完整性：状态/金额/时间戳/操作人/备注
        for e in m.ledger:
            for key in ["seq", "timestamp", "from", "to", "event", "amount", "operator", "note"]:
                self.assertIn(key, e)
        # 金额可追溯
        self.assertAlmostEqual(m.amount, 1280.00, places=2)

    def test_settlement_split_sum_equals_amount(self):
        m = OrderMachine("ORD-T-002", 1280.00)
        for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
            m.apply(event)
        split_sum = round(sum(e["amount"] for e in m.ledger if e["event"] == "split"), 2)
        self.assertAlmostEqual(split_sum, 1280.00, places=2)
        self.assertEqual(len([e for e in m.ledger if e["event"] == "split"]), 3)

    def test_refund_branch(self):
        m = OrderMachine("ORD-T-003", 360.00)
        m.apply("refund", operator="customer_service", note="消费者申请退款")
        self.assertEqual(m.state, REFUNDED)

    def test_dispute_branch(self):
        m = OrderMachine("ORD-T-004", 520.00)
        m.apply("create_work_order")
        m.apply("dispatch")
        m.apply("dispute", operator="customer", note="消费者发起争议")
        self.assertEqual(m.state, DISPUTED)
        m.apply("resolve_refund", operator="customer_service", note="争议裁定退款")
        self.assertEqual(m.state, REFUNDED)

    def test_invalid_transition_raises(self):
        m = OrderMachine("ORD-T-005", 100.00)
        with self.assertRaises(InvalidTransitionError):
            m.apply("ship")  # CREATED 状态不允许直接发货

    def test_deterministic_output(self):
        """确定性：同输入两次运行台账时间戳完全一致。"""
        m1 = OrderMachine("ORD-T-006", 800.00)
        for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
            m1.apply(event)
        m2 = OrderMachine("ORD-T-006", 800.00)
        for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
            m2.apply(event)
        self.assertEqual([e["timestamp"] for e in m1.ledger],
                         [e["timestamp"] for e in m2.ledger])


class TestComponentRegistry(unittest.TestCase):
    """验收 5a：企业组件注册表 >=6 组件，声明行业/能力/契约/依赖/数据边界。"""

    def test_at_least_six_components(self):
        reg = ComponentRegistry()
        comps = reg.list_components()
        self.assertGreaterEqual(len(comps), 6)
        ids = [c["component_id"] for c in comps]
        for required in ("knowledge_base", "agent", "workflow", "showcase", "crm", "analytics"):
            self.assertIn(required, ids)

    def test_components_declare_required_fields(self):
        for c in ComponentRegistry().list_components():
            for key in ("component_id", "name", "industries", "capabilities",
                        "contract", "dependencies", "data_boundary"):
                self.assertIn(key, c, c["component_id"])
            self.assertIn("input", c["contract"], c["component_id"])
            self.assertIn("output", c["contract"], c["component_id"])
            self.assertTrue(c["industries"], c["component_id"])

    def test_contract_validation(self):
        reg = ComponentRegistry()
        ok = reg.validate_contract("knowledge_base", {"question": "尺寸上限？"})
        self.assertTrue(ok["ok"])
        bad = reg.validate_contract("knowledge_base", {"q": "x"})
        self.assertFalse(bad["ok"])
        self.assertIn("question", bad["missing"])

    def test_industry_config_components_registered(self):
        for industry in ("jewelry", "wood"):
            svc = EnterpriseService(industry)
            for cid in svc.config["enabled_components"]:
                comp = svc.registry.get(cid)
                self.assertIsNotNone(comp, cid)
                self.assertIn(industry, comp["industries"], cid)

    def test_reject_unknown_component_in_config(self):
        reg = ComponentRegistry()
        fake = {"industry": "jewelry", "enabled_components": ["not_a_component"]}
        result = reg.assert_config_components(fake)
        self.assertFalse(result["ok"])
        self.assertTrue(any("未注册" in e for e in result["errors"]))


class TestEnterpriseService(unittest.TestCase):
    """验收 5b：同一代码路径靠行业配置切换（珠宝/木作），禁止复制两份代码。"""

    def test_same_class_switches_industry(self):
        svc_j = EnterpriseService("jewelry")
        svc_w = EnterpriseService("wood")
        self.assertEqual(svc_j.__class__.__name__, "EnterpriseService")
        self.assertEqual(svc_w.__class__.__name__, "EnterpriseService")
        self.assertEqual(svc_j.industry, "jewelry")
        self.assertEqual(svc_w.industry, "wood")

    def test_kb_query_industry_specific(self):
        svc_j = EnterpriseService("jewelry")
        svc_w = EnterpriseService("wood")
        rj = svc_j.kb_query("爪镶主石尺寸上限是多少？")
        rw = svc_w.kb_query("镂空雕刻最小壁厚是多少？")
        self.assertTrue(rj["matched_ids"])
        self.assertTrue(rw["matched_ids"])
        self.assertNotEqual(rj["answer"], rw["answer"])
        # 同一问题在另一行业不命中关键词时走 fallback
        fallback = svc_w.kb_query("爪镶主石尺寸上限是多少？")
        self.assertFalse(fallback["matched_ids"])

    def test_agent_chat_uses_industry_template(self):
        svc = EnterpriseService("jewelry")
        res = svc.agent_chat("主石尺寸上限？")
        self.assertIn(svc.config["prompt_templates"]["agent_reply"].split("{")[0][:5],
                      res["reply"])
        self.assertIn(res["kb"]["answer"], res["reply"])

    def test_workflow_config_driven(self):
        svc = EnterpriseService("wood")
        wf = svc.run_workflow("demo")
        steps = svc.config["workflow"]["steps"]
        self.assertEqual(wf["step_count"], len(steps))
        for i, log in enumerate(wf["steps_log"]):
            self.assertEqual(log["step"], steps[i]["step"])
            self.assertEqual(log["handler"], steps[i]["handler"])

    def test_showcase_and_analytics(self):
        svc_j = EnterpriseService("jewelry")
        svc_w = EnterpriseService("wood")
        self.assertTrue(svc_j.showcase_list()["products"])
        self.assertTrue(svc_w.showcase_list()["products"])
        rep = svc_j.analytics_report()
        self.assertIn("estimated_revenue_usd", rep)
        self.assertGreater(rep["estimated_revenue_usd"], 0)


class TestSiteGeneration(unittest.TestCase):
    """验收 6a：多语言站点生成（中/英/德三语，数据驱动）。"""

    @classmethod
    def setUpClass(cls):
        cls.gen = SiteGenerator()
        cls.auditor = SeoAuditor()
        cls.site_files = {}
        for locale in ("zh", "en", "de"):
            info = cls.gen.generate(locale, _TEST_SITES_DIR)
            cls.site_files[locale] = info["file"]
            with open(info["file"], "r", encoding="utf-8") as f:
                cls.auditor.audit(f.read())

    def test_three_locales_generated(self):
        for locale in ("zh", "en", "de"):
            self.assertTrue(os.path.exists(self.site_files[locale]), locale)
            with open(self.site_files[locale], "r", encoding="utf-8") as f:
                self.assertIn("<html", f.read(), locale)

    def test_generated_sites_pass_seo_audit(self):
        for locale, path in self.site_files.items():
            with open(path, "r", encoding="utf-8") as f:
                audit = self.auditor.audit(f.read())
            self.assertTrue(audit["overall"], locale)


class TestSeoAudit(unittest.TestCase):
    """验收 6b：SEO 审计用例（title/description 长度、单一 H1、canonical、hreflang、结构化数据）。"""

    def test_all_seo_cases_match_expectation(self):
        auditor = SeoAuditor()
        for case in load_seo_cases()["cases"]:
            result = auditor.audit(case["html"])
            self.assertEqual(result["overall"], case["expect_pass"], case["case_id"])
            self.assertTrue(result["checks"], case["case_id"])

    def test_audit_checks_cover_required_rules(self):
        good = ('<html><head><title>0123456789012345678901234567890123456789</title>'
                '<meta name="description" content="012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789"/>'
                '<link rel="canonical" href="https://x.example/"/>'
                '<link rel="alternate" hreflang="zh-CN" href="https://x.example/zh/"/>'
                '<link rel="alternate" hreflang="en-US" href="https://x.example/en/"/>'
                '<link rel="alternate" hreflang="de-DE" href="https://x.example/de/"/>'
                '<script type="application/ld+json">{}</script></head><body><h1>t</h1></body></html>')
        checks = {c["check"] for c in SeoAuditor().audit(good)["checks"]}
        for required in ("title_length", "description_length", "single_h1",
                         "canonical", "hreflang_mutual", "structured_data"):
            self.assertIn(required, checks)


class TestCrmFlow(unittest.TestCase):
    """验收 6c：询盘→CRM 闭环（确定性打分、SLA、负责人、跟进、报价、管线事件）。"""

    def test_all_crm_cases_match(self):
        for case in load_crm_cases():
            flow = run_crm_flow(case["industry"], case["lead"])
            rec, score, quote = flow["record"], flow["score"], flow["quote"]
            expect = case["expect"]
            self.assertEqual(score["score"], expect["score"], case["case_id"])
            self.assertEqual(score["qualified"], expect["qualified"], case["case_id"])
            self.assertEqual(rec["stage"], expect["final_stage"], case["case_id"])
            if expect["quote_amount"] is None:
                self.assertIsNone(quote, case["case_id"])
            else:
                self.assertEqual(quote["amount_usd"], expect["quote_amount"], case["case_id"])

    def test_deterministic_scoring(self):
        lead = {"name": "T", "country": "DE", "budget": 500, "product": "ring",
                "keywords": "wholesale"}
        a = run_crm_flow("jewelry", lead)
        b = run_crm_flow("jewelry", lead)
        self.assertEqual(a["score"]["score"], b["score"]["score"])

    def test_followup_within_sla(self):
        flow = run_crm_flow("jewelry", {"name": "T", "budget": 500, "product": "ring"})
        task = flow["record"]["followup_task"]
        created = task["created"][11:16]
        due = task["due"][11:16]
        self.assertGreaterEqual(due, created)

    def test_pipeline_events_recorded(self):
        flow = run_crm_flow("jewelry", {"name": "T", "budget": 800, "product": "戒指",
                                        "country": "DE", "keywords": "wholesale"})
        rec = flow["record"]
        self.assertEqual(rec["events"][0]["stage"], "new")
        self.assertEqual(rec["events"][-1]["stage"], "quoted")
        for e in rec["events"]:
            self.assertIn("timestamp", e)
        self.assertIn("quote", rec)

    def test_unqualified_no_quote(self):
        flow = run_crm_flow("wood", {"name": "T", "budget": 10, "product": "sofa"})
        self.assertFalse(flow["score"]["qualified"])
        self.assertIsNone(flow["quote"])

    def test_won_lost_advance(self):
        from module_b.enterprise_service import EnterpriseService
        engine = EnterpriseService("jewelry").crm_engine()
        rec = engine.capture_inquiry({"budget": 500, "product": "ring"})
        engine.score_lead(rec)
        engine.create_followup(rec)
        engine.draft_quote(rec)
        self.assertEqual(engine.advance(rec, "won"), "won")
        self.assertEqual(rec["stage"], "won")


class TestFdeHandbook(unittest.TestCase):
    """验收 5c：FDE 手册 + 一企一档样例 + 12 项上线清单 + go-live readiness 推导。"""

    def test_handbook_has_chapters(self):
        hb = load_handbook()
        self.assertGreaterEqual(len(hb["handbook"]["chapters"]), 4)
        self.assertTrue(hb["handbook"]["purpose"])

    def test_profile_filled(self):
        profile = load_enterprise_profile()
        for key in ("profile_id", "enterprise_name", "industry", "components_enabled",
                    "data_boundaries", "owners", "go_live_checklist_state"):
            self.assertIn(key, profile)
        self.assertEqual(profile["enterprise_name"], "示例珠宝工坊（脱敏）")
        self.assertTrue(profile["data_boundaries"])

    def test_checklist_has_12_items(self):
        hb = load_handbook()
        self.assertEqual(len(hb["go_live_checklist"]), 12)
        for c in hb["go_live_checklist"]:
            self.assertIn("blocker", c)

    def test_readiness_levels(self):
        def profile_with(state):
            return {"go_live_checklist_state": state}
        hb = load_handbook()
        checklist = hb["go_live_checklist"]
        all_done = [{"item": c["item"], "status": "done", "evidence": "e"} for c in checklist]
        self.assertEqual(derive_go_live_readiness(profile_with(all_done))["level"], "ready")
        blocker_item = next(c["item"] for c in checklist if c["blocker"])
        state = [{"item": c["item"], "status": "pending" if c["item"] == blocker_item else "done",
                  "evidence": "e"} for c in checklist]
        self.assertEqual(derive_go_live_readiness(profile_with(state))["level"], "not_ready")
        sample = load_enterprise_profile()
        self.assertEqual(derive_go_live_readiness(sample)["level"], "conditional")


from module_c.characters import (load_characters, get_character, list_rules,
                                 list_checklist, verify_handbook)
from module_c.assets import (AssetLibrary, load_recipes, get_recipe, render_recipe,
                             validate_svg, check_brand_terms)
from module_c.pipeline import (PipelineMachine,
                               InvalidTransitionError as PipelineInvalidTransition,
                               STATES, derive_storyboard, run_auto, compose_frame)
from module_c.license import (load_matrix, get_license, list_derivative_specs,
                              render_license_contract, review_content,
                              ReviewLog, load_safety_words)
from module_d.contest import (load_config, list_tracks, review_criteria,
                              weighted_total, score_entry, run_sampling_flow,
                              build_kpi_board)

_TEST_EPISODE_DIR = os.path.join(_PROJECT_ROOT, "output", "episode_test")


class TestModuleCCharacters(unittest.TestCase):
    """验收 7a：IP 双守护角色设定手册（内容守护/技术守护），JSON 驱动。"""

    def test_two_characters_and_fields(self):
        chars = load_characters()["characters"]
        self.assertEqual(len(chars), 2)
        duties = {c["duty"] for c in chars}
        self.assertEqual(duties, {"content", "technical"})
        for c in chars:
            for key in ("character_id", "name", "duty", "motto", "personality",
                        "relationship", "taboos", "rules", "review_checklist"):
                self.assertIn(key, c, c.get("character_id"))

    def test_non_exclusive_clause_present(self):
        data = load_characters()
        self.assertIn("不被声明为独占权利", data["non_exclusive_clause"])
        self.assertTrue(data["ai_generated_note"])

    def test_handbook_verification_passes(self):
        self.assertTrue(verify_handbook()["ok"])

    def test_rules_and_checklist_are_json_driven(self):
        rules = list_rules()
        checklist = list_checklist()
        self.assertGreaterEqual(len(rules), 6)
        self.assertGreaterEqual(len(checklist), 7)
        for r in rules:
            for key in ("rule_id", "domain", "statement", "action"):
                self.assertIn(key, r, r.get("rule_id"))
        for chk in checklist:
            for key in ("check_id", "domain", "question", "pass_rule", "fail_action"):
                self.assertIn(key, chk, chk.get("check_id"))

    def test_get_character_by_duty(self):
        content = get_character("content")
        technical = get_character("technical")
        self.assertEqual(content["duty"], "content")
        self.assertEqual(technical["duty"], "technical")
        self.assertIsNone(get_character("unknown"))


class TestModuleCAssets(unittest.TestCase):
    """验收 7b：视觉资产库 >=6 类原创 SVG 配方，可渲染可校验，清单与追溯。"""

    def test_at_least_six_original_recipes(self):
        recipes = load_recipes()
        self.assertGreaterEqual(len(recipes), 6)
        for r in recipes:
            self.assertTrue(r["original_design"], r["recipe_id"])
            self.assertTrue(r["no_external_brand"], r["recipe_id"])

    def test_all_recipes_render_and_validate(self):
        for r in load_recipes():
            res = render_recipe(r["recipe_id"])
            self.assertTrue(res["ok"], r["recipe_id"])
            v = validate_svg(res["svg"])
            self.assertTrue(v["ok"], (r["recipe_id"], v["errors"]))

    def test_validate_svg_rejects_bad_inputs(self):
        bad_script = '<svg width="10" height="10"><script>alert(1)</script></svg>'
        self.assertFalse(validate_svg(bad_script)["ok"])
        bad_url = '<svg width="10" height="10"><image href="http://evil.example/a.png"/></svg>'
        self.assertFalse(validate_svg(bad_url)["ok"])
        bad_size = '<svg width="0" height="10"></svg>'
        self.assertFalse(validate_svg(bad_size)["ok"])
        good = '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><rect x="10" y="10" width="40" height="40" fill="#1a3a5c"/></svg>'
        self.assertTrue(validate_svg(good)["ok"])

    def test_brand_terms_blocked(self):
        lib = AssetLibrary()
        bad = '<svg width="10" height="10"><text>nike logo style swoosh</text></svg>'
        hits = check_brand_terms(bad, lib.safety)
        self.assertIn("nike", hits)
        good = render_recipe("ip-element-lantern")["svg"]
        self.assertEqual(check_brand_terms(good, lib.safety), [])

    def test_registry_and_changelog_trace(self):
        lib = AssetLibrary()
        a1 = lib.add("ip-element-lantern", operator="test", note="追溯")
        self.assertTrue(a1["ok"])
        asset = lib.get(a1["asset"]["asset_id"])
        self.assertEqual(asset["checksum"], a1["checksum"])
        self.assertEqual(len(lib.list_changelog()), 1)
        log = lib.list_changelog()[0]
        self.assertEqual(log["asset_id"], a1["asset"]["asset_id"])
        self.assertEqual(log["action"], "add")

    def test_deterministic_registration(self):
        """确定性：同输入两次登记，校验和/时间戳/资产 ID 完全一致。"""
        lib1 = AssetLibrary()
        lib2 = AssetLibrary()
        r1 = lib1.add("ip-element-wave", operator="test")
        r2 = lib2.add("ip-element-wave", operator="test")
        self.assertEqual(r1["checksum"], r2["checksum"])
        self.assertEqual(r1["asset"]["created_at"], r2["asset"]["created_at"])
        self.assertEqual(r1["asset"]["asset_id"], r2["asset"]["asset_id"])

    def test_unknown_param_rejected(self):
        res = render_recipe("ip-element-lantern", {"nope": 1})
        self.assertFalse(res["ok"])
        self.assertTrue(any("unknown_param" in e for e in res["errors"]))


class TestModuleCPipeline(unittest.TestCase):
    """验收 7c：短剧工作流状态机（>=5 环节含返工）与确定性推导、帧产物。"""

    def test_state_machine_has_at_least_five_states_with_rework(self):
        self.assertGreaterEqual(len(STATES), 5)
        self.assertIn("REWORK", STATES)
        self.assertIn("PUBLISH", STATES)
        # 正向链路可走通
        m = PipelineMachine()
        for ev in ("pass", "pass", "pass", "pass", "pass"):
            m.apply(ev)
        self.assertEqual(m.state, "PUBLISH")

    def test_rework_branch(self):
        m = PipelineMachine()
        m.apply("pass")  # SCRIPT_REVIEW -> STORYBOARD
        m.apply("rework")  # -> REWORK
        self.assertEqual(m.state, "REWORK")
        m.apply("to_script")
        self.assertEqual(m.state, "SCRIPT_REVIEW")

    def test_invalid_transition_raises(self):
        m = PipelineMachine()
        with self.assertRaises(PipelineInvalidTransition):
            m.apply("reject")  # SCRIPT_REVIEW 不支持 reject

    def test_storyboard_derivation_rules(self):
        script = {
            "episode_id": "EP-UT-1", "title": "T",
            "scenes": [
                {"scene_id": "S1", "title": "空镜A", "tags": ["lantern"],
                 "dialogue": [{"speaker": "旁白", "line": "第一句"}]},
                {"scene_id": "S2", "title": "对话B", "tags": ["shield"],
                 "dialogue": [{"speaker": "文鉴", "line": "第二句"},
                              {"speaker": "工衡", "line": "第三句"}]},
            ],
        }
        shots = derive_storyboard(script)
        # R1 每场景 1 空镜；R2 每对白 1 镜头
        self.assertEqual(len(shots), 1 + 1 + 1 + 2)
        self.assertEqual(shots[0]["shot_type"], "establish")
        self.assertEqual(shots[0]["shot_size"], "远景")
        self.assertEqual(shots[1]["shot_type"], "dialogue")
        # R4 元素引用映射
        self.assertEqual(shots[0]["element_refs"], ["ip-element-lantern"])
        self.assertEqual(shots[2]["element_refs"], ["ip-element-shield"])
        # R3 景别轮换
        sizes = [s["shot_size"] for s in shots]
        self.assertGreater(len(set(sizes)), 1)

    def test_compose_frame_embeds_recipe_and_marking(self):
        res = render_recipe("ip-element-eye")
        shot = {"shot_no": 1, "scene_id": "S1", "shot_type": "establish",
                "shot_size": "远景", "duration_s": 2, "caption": "空镜：守艺",
                "speaker": "旁白", "element_refs": ["ip-element-eye"]}
        svg = compose_frame(shot, res["svg"])
        self.assertIn("AI 生成", svg)
        self.assertIn('width="320"', svg)
        self.assertTrue(validate_svg(svg)["ok"])

    def test_run_auto_full_pipeline(self):
        script_path = os.path.join(_PROJECT_ROOT, "module_c", "data", "script_sample.json")
        with open(script_path, "r", encoding="utf-8") as f:
            script = json.load(f)
        ep = run_auto(script, _TEST_EPISODE_DIR)
        self.assertTrue(ep["ok"])
        self.assertEqual(ep["final_state"], "PUBLISH")
        # 含返工分支（脚本 S2 含违规对白被内容守护拦截）
        self.assertGreaterEqual(len(ep["rework_events"]), 1)
        self.assertIn("REWORK", ep["states_visited"])
        # 帧产物：数量与分镜一致且全部可校验
        self.assertEqual(len(ep["frames"]), len(ep["storyboard"]))
        for f in ep["frames"]:
            self.assertTrue(os.path.exists(f["path"]), f["path"])
            with open(f["path"], "r", encoding="utf-8") as fh:
                self.assertTrue(validate_svg(fh.read())["ok"], f["path"])
        # 日志落盘
        self.assertTrue(os.path.exists(ep["log_file"]))
        self.assertTrue(os.path.exists(ep["review_log_file"]))

    def test_review_log_records_reject_and_pass(self):
        script_path = os.path.join(_PROJECT_ROOT, "module_c", "data", "script_sample.json")
        with open(script_path, "r", encoding="utf-8") as f:
            script = json.load(f)
        ep = run_auto(script, _TEST_EPISODE_DIR)
        with open(ep["review_log_file"], "r", encoding="utf-8") as f:
            rl = json.load(f)
        decisions = [e["decision"] for e in rl["entries"]]
        self.assertIn("reject", decisions)
        self.assertIn("pass", decisions)
        for e in rl["entries"]:
            self.assertIn("log_id", e)
            self.assertIn("at", e)

    def test_pipeline_deterministic(self):
        """确定性：两次运行状态轨迹与日志序列一致。"""
        script_path = os.path.join(_PROJECT_ROOT, "module_c", "data", "script_sample.json")
        with open(script_path, "r", encoding="utf-8") as f:
            script = json.load(f)
        ep1 = run_auto(script, _TEST_EPISODE_DIR)
        ep2 = run_auto(script, _TEST_EPISODE_DIR)
        self.assertEqual([(e["seq"], e["state"], e["event"]) for e in ep1["log"]],
                         [(e["seq"], e["state"], e["event"]) for e in ep2["log"]])
        self.assertEqual(ep1["states_visited"], ep2["states_visited"])


class TestModuleCLicense(unittest.TestCase):
    """验收 7d：授权矩阵 + 衍生品规范 + 内容审核（安全词表/合规过滤/审核日志）。"""

    def test_license_matrix_three_types(self):
        matrix = load_matrix()
        types = {l["license_type"] for l in matrix["license_matrix"]}
        self.assertEqual(types, {"ip_license", "merchandise_license", "event_license"})
        self.assertIn("不被声明为独占权利", matrix["non_exclusive_clause"])
        for lic in matrix["license_matrix"]:
            for key in ("license_type", "name", "scope", "term_months",
                        "royalty_rate", "approval_gate"):
                self.assertIn(key, lic, lic.get("license_type"))
            gate = lic["approval_gate"]
            self.assertTrue(gate["required_roles"], lic["license_type"])
            self.assertTrue(gate["conditions"], lic["license_type"])

    def test_derivative_specs_four_categories(self):
        specs = list_derivative_specs()
        self.assertEqual(len(specs), 4)
        cats = {s["category"] for s in specs}
        self.assertEqual(cats, {"jewelry_pendant", "apparel_collab",
                                "wood_carving", "cultural_gift"})
        for s in specs:
            self.assertIn("quality_requirements", s)
            self.assertIn("brand_rules", s)
            self.assertIn("ai_marking", s)

    def test_license_contract_template(self):
        text = render_license_contract("merchandise_license", "示例品牌（脱敏）", "联名")
        self.assertIn("衍生品授权", text)
        self.assertIn("不被声明为独占权利", text)
        self.assertIn("AI 生成", text)
        self.assertIn("10%", text)

    def test_review_content_rejects_banned_and_brand(self):
        safety = load_safety_words()
        r1 = review_content("这只灯笼据说开光保平安。", safety=safety, meta={"ai_marking": True})
        self.assertFalse(r1["ok"])
        self.assertEqual(r1["decision"], "reject")
        self.assertTrue(any(w == "开光" for w, _ in r1["hits"]))
        r2 = review_content("联名 nike swoosh 风格", safety=safety, meta={"ai_marking": True})
        self.assertFalse(r2["ok"])
        self.assertIn("nike", r2["brand_hits"])

    def test_review_content_requires_ai_marking(self):
        safety = load_safety_words()
        r = review_content("非遗再创作，海洋文化。", safety=safety, meta={"ai_marking": False})
        self.assertFalse(r["ok"])
        self.assertFalse(r["marking_ok"])
        r2 = review_content("非遗再创作，海洋文化。AI 生成。", safety=safety, meta={"ai_marking": False})
        self.assertTrue(r2["ok"])

    def test_review_log_deterministic(self):
        safety = load_safety_words()
        lg1 = ReviewLog()
        lg2 = ReviewLog()
        for lg in (lg1, lg2):
            for txt in ("合规文案 AI 生成。", "开光 保平安。"):
                r = review_content(txt, safety=safety, meta={"ai_marking": True})
                lg.add(txt, r, context="ut")
        self.assertEqual([e["at"] for e in lg1.entries],
                         [e["at"] for e in lg2.entries])
        self.assertEqual(len(lg1.entries), 2)


class TestModuleDContest(unittest.TestCase):
    """模块 D：赛事包（赛道/评审计分/打样流程/传播 KPI），JSON 配置驱动。"""

    def test_tracks_defined(self):
        tracks = list_tracks()
        self.assertGreaterEqual(len(tracks), 3)
        for t in tracks:
            for key in ("track_id", "name", "entry_limit", "theme", "awards"):
                self.assertIn(key, t, t.get("track_id"))

    def test_review_weights_sum_to_one(self):
        criteria = review_criteria()
        total = round(sum(c["weight"] for c in criteria), 2)
        self.assertAlmostEqual(total, 1.0, places=2)
        for c in criteria:
            self.assertLessEqual(c["max_score"], 100)

    def test_scorecard_verdicts(self):
        cfg = load_config()
        for e in cfg["sample_entries"]:
            sc = score_entry(e)
            self.assertIn(sc["verdict"], ("进打样", "入围", "淘汰"))
            self.assertGreaterEqual(sc["total"], 0)
            self.assertLessEqual(sc["total"], cfg["scorecard"]["total_max"])
            # 计分行数与标准数一致
            self.assertEqual(len(sc["rows"]), len(cfg["review_criteria"]))

    def test_sampling_flow_gates(self):
        cfg = load_config()
        e_high = next(e for e in cfg["sample_entries"] if e["entry_id"] == "E-001")
        e_low = next(e for e in cfg["sample_entries"] if e["entry_id"] == "E-004")
        flow_high = run_sampling_flow(e_high)
        flow_low = run_sampling_flow(e_low)
        self.assertFalse(flow_high["blocked"])
        self.assertEqual(flow_high["final_stage"], "量产授权")
        self.assertTrue(flow_low["blocked"])
        # 未达进打样门槛的作品在“打样对接”阶段被门禁拦截
        blocked_stages = [s for s in flow_low["stages"] if s["status"] == "blocked"]
        self.assertTrue(blocked_stages)
        self.assertEqual(blocked_stages[0]["stage"], "打样对接")
        self.assertIn("85", blocked_stages[0]["gate"])

    def test_sampling_qc_gate(self):
        cfg = load_config()
        entry = next(e for e in cfg["sample_entries"] if e["entry_id"] == "E-005")
        entry_bad = dict(entry)
        entry_bad["sample_qc_pass"] = False
        flow = run_sampling_flow(entry_bad)
        self.assertTrue(flow["blocked"])
        self.assertEqual(flow["final_stage"], "量产授权")
        blocked_stages = [s for s in flow["stages"] if s["status"] == "blocked"]
        self.assertEqual(blocked_stages[0]["stage"], "量产授权")

    def test_kpi_board(self):
        board = build_kpi_board()
        self.assertTrue(board["all_met"])
        self.assertEqual(len(board["indicators"]), 5)
        self.assertGreaterEqual(len(board["licensed_products"]), 1)
        for ind in board["indicators"]:
            self.assertIn(ind["status"], ("达标", "未达标"))

    def test_deterministic_scoring(self):
        cfg = load_config()
        e = cfg["sample_entries"][0]
        a = weighted_total(e["scores"])
        b = weighted_total(e["scores"])
        self.assertEqual(a[0], b[0])


class TestAuthEdgeCases(unittest.TestCase):
    """交付扩充：授权字段边界（逐字段缺失反例）。"""

    def test_reject_missing_region(self):
        result = validate_pattern({"name": "n", "authorization_source": "清单（脱敏）",
                                   "usage_scope": "commercial", "license_type": "non_exclusive",
                                   "rights_holder": "x"})
        self.assertFalse(result["ok"])
        self.assertIn("region", result["missing_fields"])

    def test_reject_missing_usage_scope(self):
        result = validate_pattern({"name": "n", "authorization_source": "清单（脱敏）",
                                   "license_type": "non_exclusive", "rights_holder": "x",
                                   "region": "y"})
        self.assertFalse(result["ok"])
        self.assertIn("usage_scope", result["missing_fields"])

    def test_reject_missing_rights_holder(self):
        result = validate_pattern({"name": "n", "authorization_source": "清单（脱敏）",
                                   "usage_scope": "commercial", "license_type": "non_exclusive",
                                   "region": "y"})
        self.assertFalse(result["ok"])
        self.assertIn("rights_holder", result["missing_fields"])

    def test_reject_missing_license_type(self):
        result = validate_pattern({"name": "n", "authorization_source": "清单（脱敏）",
                                   "usage_scope": "commercial", "rights_holder": "x",
                                   "region": "y"})
        self.assertFalse(result["ok"])
        self.assertIn("license_type", result["missing_fields"])

    def test_name_optional_allowed(self):
        result = validate_pattern({"authorization_source": "清单（脱敏）",
                                   "usage_scope": "commercial", "license_type": "non_exclusive",
                                   "rights_holder": "x", "region": "y"})
        self.assertTrue(result["ok"])
        self.assertNotIn("name", result["missing_fields"])

    def test_empty_pattern_lists_all_required(self):
        result = validate_pattern({})
        self.assertFalse(result["ok"])
        self.assertGreaterEqual(len(result["missing_fields"]), 5)

    def test_sample_data_has_schema_and_samples(self):
        data = _load_json("module_a/data/pattern_samples.json")
        self.assertTrue(data["required_fields"])
        self.assertTrue(data["valid_usage_scopes"])
        self.assertTrue(data["valid_license_types"])
        self.assertGreaterEqual(len(data["samples"]), 4)


class TestMfgEdgeCases(unittest.TestCase):
    """交付扩充：可制造性边界（样例契约、双行业覆盖、确定性）。"""

    def test_ten_cases_schema(self):
        data = _load_json(_CASES_PATH)
        self.assertEqual(len(data["cases"]), 10)
        for c in data["cases"]:
            for key in ("case_id", "industry", "workshop_id", "concept", "expected"):
                self.assertIn(key, c, c.get("case_id"))

    def test_negative_case_ids_match_expected(self):
        data = _load_json(_CASES_PATH)
        negs = {c["case_id"] for c in data["cases"] if c["expected"]["feasible"] is False}
        self.assertEqual(set(data["negative_case_ids"]), negs)
        self.assertEqual(len(negs), 3)

    def test_positive_cases_feasible(self):
        data = _load_json(_CASES_PATH)
        for c in data["cases"]:
            if c["expected"]["feasible"] is False:
                continue
            concept = dict(c["concept"])
            concept["concept_id"] = c["case_id"]
            concept["industry"] = c["industry"]
            result = evaluate(concept, c["workshop_id"])
            self.assertTrue(result["feasible"], c["case_id"])

    def test_two_industries_covered(self):
        data = _load_json(_CASES_PATH)
        inds = {c["industry"] for c in data["cases"]}
        self.assertIn("jewelry", inds)
        self.assertIn("wood", inds)

    def test_rule_files_cover_both_industries(self):
        j = _load_json("module_a/data/mfg_rules_jewelry.json")
        w = _load_json("module_a/data/mfg_rules_wood.json")
        self.assertEqual(j["industry"], "jewelry")
        self.assertEqual(w["industry"], "wood")
        self.assertTrue(j["rules"])
        self.assertTrue(w["rules"])
        for rule in j["rules"] + w["rules"]:
            self.assertEqual(rule["conclusion"], "not_feasible", rule.get("rule_id"))
            self.assertTrue(rule["suggestion"], rule.get("rule_id"))

    def test_equipment_capabilities_workshops(self):
        caps = _load_json("module_a/data/equipment_capabilities.json")
        ws = {w["workshop_id"] for w in caps["workshops"]}
        self.assertIn("WS-JW-01", ws)
        self.assertIn("WS-WD-01", ws)

    def test_evaluate_deterministic(self):
        data = _load_json(_CASES_PATH)
        c = data["cases"][0]
        concept = dict(c["concept"])
        concept["concept_id"] = c["case_id"]
        concept["industry"] = c["industry"]
        a = evaluate(concept, c["workshop_id"])
        b = evaluate(concept, c["workshop_id"])
        self.assertEqual(a, b)


class TestOrderEdgeCases(unittest.TestCase):
    """交付扩充：订单状态机边界（非法转换、终止态、台账字段）。"""

    def test_cancel_at_created(self):
        m = OrderMachine("ORD-EDGE-01", 500.00)
        m.apply("cancel")
        self.assertEqual(m.state, CANCELLED)

    def test_dispatch_before_work_order_rejected(self):
        m = OrderMachine("ORD-EDGE-02", 500.00)
        with self.assertRaises(InvalidTransitionError):
            m.apply("dispatch")

    def test_pass_qc_before_dispatch_rejected(self):
        m = OrderMachine("ORD-EDGE-03", 500.00)
        with self.assertRaises(InvalidTransitionError):
            m.apply("pass_qc")

    def test_settle_twice_rejected(self):
        m = OrderMachine("ORD-EDGE-04", 500.00)
        for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
            m.apply(event)
        with self.assertRaises(InvalidTransitionError):
            m.apply("settle")

    def test_unknown_event_rejected(self):
        m = OrderMachine("ORD-EDGE-05", 500.00)
        with self.assertRaises(InvalidTransitionError):
            m.apply("fly_to_moon")

    def test_cancelled_state_terminal(self):
        m = OrderMachine("ORD-EDGE-06", 500.00)
        m.apply("cancel")
        with self.assertRaises(InvalidTransitionError):
            m.apply("create_work_order")

    def test_ledger_event_fields(self):
        m = OrderMachine("ORD-EDGE-07", 500.00)
        for event in ["create_work_order", "dispatch", "pass_qc", "ship", "settle"]:
            m.apply(event)
        for e in m.ledger:
            for key in ("event", "to", "amount", "timestamp", "operator"):
                self.assertIn(key, e, e.get("event"))


class TestServiceEdgeCases(unittest.TestCase):
    """交付扩充：企业 AI 服务层边界（行业配置契约、知识库兜底、工作流）。"""

    def test_unknown_industry_value_error(self):
        from module_b.enterprise_service import EnterpriseService
        with self.assertRaises(ValueError):
            EnterpriseService("sports")

    def test_two_industries_config_contract(self):
        from module_b.enterprise_service import load_industry_config
        for industry in ("jewelry", "wood"):
            cfg = load_industry_config(industry)
            for key in ("industry", "display_name", "enabled_components",
                        "prompt_templates", "kb_assets", "crm", "workflow",
                        "analytics", "showcase"):
                self.assertIn(key, cfg, industry)

    def test_kb_query_nonempty_answer(self):
        from module_b.enterprise_service import EnterpriseService
        for industry in ("jewelry", "wood"):
            svc = EnterpriseService(industry)
            ans = svc.kb_query("材料与工艺上限")
            self.assertTrue(ans["answer"], industry)
            self.assertIn("合成样例", ans["answer"], industry)

    def test_workflow_defined_for_industries(self):
        from module_b.enterprise_service import load_industry_config
        for industry in ("jewelry", "wood"):
            wf = load_industry_config(industry)["workflow"]
            self.assertTrue(wf.get("steps"), industry)

    def test_showcase_products_nonempty(self):
        from module_b.enterprise_service import load_industry_config
        for industry in ("jewelry", "wood"):
            show = load_industry_config(industry)["showcase"]
            self.assertTrue(show, industry)
            for item in show:
                self.assertIn("id", item, industry)
                self.assertIn("name", item, industry)

    def test_analytics_metrics_defined(self):
        from module_b.enterprise_service import load_industry_config
        for industry in ("jewelry", "wood"):
            an = load_industry_config(industry)["analytics"]
            self.assertTrue(an.get("metrics"), industry)


class TestExportEdgeCases(unittest.TestCase):
    """交付扩充：出海增长栈边界（hreflang 自指、SEO 规则契约、审计结构）。"""

    def test_site_hreflang_includes_self(self):
        gen = SiteGenerator()
        for locale, lang in (("zh", "zh-CN"), ("en", "en-US"), ("de", "de-DE")):
            info = gen.generate(locale, _TEST_SITES_DIR)
            self.assertIn(lang, info["hreflang"], locale)

    def test_site_seo_meta_fields(self):
        gen = SiteGenerator()
        info = gen.generate("zh", _TEST_SITES_DIR)
        self.assertIn("title", info["seo_meta"])
        self.assertIn("description", info["seo_meta"])

    def test_generated_site_has_h1(self):
        gen = SiteGenerator()
        info = gen.generate("zh", _TEST_SITES_DIR)
        with open(info["file"], "r", encoding="utf-8") as f:
            self.assertIn("<h1", f.read())

    def test_seo_rules_and_hreflang_declared(self):
        data = load_seo_cases()
        self.assertTrue(data["rules"])
        self.assertEqual(len(data["required_hreflang"]), 3)

    def test_crm_cases_contract(self):
        cases = load_crm_cases()
        self.assertEqual(len(cases), 3)
        for c in cases:
            for key in ("case_id", "industry", "lead", "expect"):
                self.assertIn(key, c, c.get("case_id"))

    def test_seo_audit_returns_structure(self):
        auditor = SeoAuditor()
        good = ('<html><head><title>1234567890123456789012345678901234567890</title>'
                '<meta name="description" content="1234567890123456789012345678901234567890"/>'
                '<link rel="canonical" href="https://x.example/"/>'
                '<script type="application/ld+json">{}</script></head>'
                '<body><h1>t</h1></body></html>')
        result = auditor.audit(good)
        self.assertIn("overall", result)
        self.assertTrue(result["checks"])


class TestIpEdgeCases(unittest.TestCase):
    """交付扩充：IP 管线边界（审核计数、品牌词、授权门禁、资产库、SVG 校验）。"""

    def test_review_banned_multiple_count(self):
        safety = load_safety_words()
        r = review_content("开光 开光 保平安", safety=safety, meta={"ai_marking": True})
        self.assertFalse(r["ok"])
        self.assertEqual(dict(r["hits"]).get("开光"), 2)

    def test_review_safe_words_pass(self):
        safety = load_safety_words()
        r = review_content("灯塔故事。AI 生成。", safety=safety, meta={"ai_marking": True})
        self.assertTrue(r["ok"])
        self.assertIn("灯塔", r["safe_hits"])

    def test_review_brand_terms_listed(self):
        safety = load_safety_words()
        self.assertTrue(safety["brand_terms"])

    def test_review_log_id_format(self):
        safety = load_safety_words()
        r = review_content("合规文案。AI 生成。", safety=safety, meta={"ai_marking": True})
        self.assertTrue(r["log_id"].startswith("RVW-"))

    def test_license_contract_contains_gate(self):
        text = render_license_contract("merchandise_license", "示例品牌（脱敏）", "联名")
        self.assertIn("审批门禁", text)
        self.assertIn("打样质检", text)

    def test_matrix_ai_marking_required(self):
        matrix = load_matrix()
        self.assertTrue(matrix["ai_generated_marking_required"])

    def test_matrix_approval_workflow_steps(self):
        matrix = load_matrix()
        wf = matrix["approval_workflow"]
        self.assertTrue(wf)

    def test_asset_add_increments_id(self):
        lib = AssetLibrary()
        r1 = lib.add("ip-element-shield", operator="ut", note="edge")
        r2 = lib.add("ip-element-shield", operator="ut", note="edge")
        self.assertEqual(r1["asset"]["asset_id"], "AST-0001")
        self.assertEqual(r2["asset"]["asset_id"], "AST-0002")

    def test_validate_svg_script_blocked(self):
        result = validate_svg("<svg><script>alert(1)</script></svg>")
        self.assertFalse(result["ok"])
        self.assertIn("script_forbidden", result["errors"])

    def test_validate_svg_requires_dimension(self):
        result = validate_svg("<svg></svg>")
        self.assertFalse(result["ok"])
        self.assertIn("invalid_dimension", result["errors"])


class TestContestEdgeCases(unittest.TestCase):
    """交付扩充：赛事包边界（满分/零分/缺项兜底/未知赛道/传播 KPI）。"""

    def test_score_zero_verdict(self):
        cfg = load_config()
        e = dict(cfg["sample_entries"][0])
        e["scores"] = {c["criterion"]: 0 for c in review_criteria()}
        sc = score_entry(e)
        self.assertEqual(sc["total"], 0.0)
        self.assertIn(sc["verdict"], ("进打样", "入围", "淘汰"))

    def test_score_full_marks(self):
        cfg = load_config()
        e = dict(cfg["sample_entries"][0])
        e["scores"] = {c["criterion"]: 100 for c in review_criteria()}
        sc = score_entry(e)
        self.assertEqual(sc["total"], 100.0)
        self.assertEqual(sc["verdict"], "进打样")

    def test_missing_criterion_default_zero(self):
        cfg = load_config()
        e = dict(cfg["sample_entries"][0])
        e["scores"] = {c["criterion"]: 100 for c in review_criteria()[:-1]}
        sc = score_entry(e)
        rows = {r["criterion"]: r["score"] for r in sc["rows"]}
        self.assertEqual(rows[review_criteria()[-1]["criterion"]], 0)

    def test_unknown_track_handled(self):
        cfg = load_config()
        e = dict(cfg["sample_entries"][0])
        e["track"] = "sports"
        sc = score_entry(e)
        self.assertGreaterEqual(sc["total"], 0)

    def test_sampling_flow_full_marks_passes(self):
        cfg = load_config()
        e = dict(cfg["sample_entries"][0])
        e["scores"] = {c["criterion"]: 100 for c in review_criteria()}
        flow = run_sampling_flow(e)
        self.assertFalse(flow["blocked"])
        self.assertEqual(flow["final_stage"], "量产授权")

    def test_kpi_indicators_contract(self):
        board = build_kpi_board()
        self.assertEqual(len(board["indicators"]), 5)
        for ind in board["indicators"]:
            for key in ("indicator", "current", "target", "status"):
                self.assertIn(key, ind, ind.get("indicator"))

    def test_promotion_channels_at_least_three(self):
        cfg = load_config()
        self.assertGreaterEqual(len(cfg["promotion_matrix"]), 3)
        for ch in cfg["promotion_matrix"]:
            self.assertIn("channel", ch)

    def test_by_track_counts_positive(self):
        board = build_kpi_board()
        for track, count in board["by_track"].items():
            self.assertGreaterEqual(count, 2, track)


def suite():
    loader = unittest.TestLoader()
    return loader.loadTestsFromModule(sys.modules[__name__])

if __name__ == "__main__":
    unittest.main(verbosity=2)
