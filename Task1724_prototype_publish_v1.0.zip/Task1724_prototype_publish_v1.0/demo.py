"""ClawHunt #1724 模块 A+B 最小可运行闭环原型 - 演示命令。

用法：python demo.py
跑通模块 A（授权校验 / 可制造性 10/10 / C2M 订单链路）与模块 B
（企业组件注册表 / 两行业配置切换 / 出海增长栈三语站点+SEO / 询盘→CRM 闭环 / FDE 交付），
输出确定性结果，可直接作为验收 2/3/4/5/6 的演示证据。
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from module_a.auth_fields import run_auth_demo
from module_a.manufacturability import run_mfg_demo
from module_a.order_machine import run_order_demo
from module_b.component_registry import ComponentRegistry
from module_b.enterprise_service import EnterpriseService
from module_b.export_stack import SiteGenerator, SeoAuditor, run_crm_flow, load_crm_cases
from module_b.fde_handbook import load_handbook, load_enterprise_profile, derive_go_live_readiness
from module_c.characters import load_characters, verify_handbook, list_rules, list_checklist
from module_c.assets import AssetLibrary, load_recipes, render_recipe, validate_svg
from module_c.pipeline import run_auto
from module_c.license import (load_matrix, get_license, list_derivative_specs,
                              render_license_contract, review_content,
                              load_safety_words)
from module_d.contest import (list_tracks, weighted_total, score_entry,
                              run_sampling_flow, build_kpi_board)

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
SITES_DIR = os.path.join(PROJECT_ROOT, "output", "sites")


def run_module_b_demo(verbose=True):
    def p(msg):
        if verbose:
            print(msg)

    p("ClawHunt #1724 模块 B：企业 AI 服务层（FDE 模式）+ 出海增长栈（纯标准库，零依赖）")
    p("蓝本: proposal_Task1724.md 验收标准 5/6")
    p("")

    # 1. 企业组件注册表（>=6 组件，声明行业/能力/契约/依赖/数据边界）
    reg = ComponentRegistry()
    comps = reg.list_components()
    p("[1] 企业组件注册表：{} 个组件".format(len(comps)))
    for c in comps:
        p("    - {}（{}）行业: {} | 能力: {} | 依赖: {} | 数据边界: {}".format(
            c["component_id"], c["name"], ",".join(c["industries"]),
            ",".join(c["capabilities"]),
            ",".join(c["dependencies"]) if c["dependencies"] else "无",
            c["data_boundary"]))
    p("")

    # 2. 珠宝/木作两行业配置切换（同一代码路径，仅换 industry_config）
    svc_j = EnterpriseService("jewelry")
    svc_w = EnterpriseService("wood")
    kb_j = svc_j.kb_query("爪镶主石尺寸上限是多少？")
    kb_w = svc_w.kb_query("榫卯结构可以做吗？")
    agent_w = svc_w.agent_chat("镂空雕刻最小壁厚？")
    wf_j = svc_j.run_workflow("询盘触发")
    p("[2] 行业配置切换（同一代码，仅换 industry_config，无复制代码）")
    p("    珠宝 kb_query -> {}".format(kb_j["answer"]))
    p("    木作 kb_query -> {}".format(kb_w["answer"]))
    p("    木作 agent_chat -> {}".format(agent_w["reply"]))
    p("    珠宝 workflow: {}（{} 步）".format(wf_j["workflow"], wf_j["step_count"]))
    p("")

    # 3. 出海增长栈：三语站点生成 + SEO 审计
    gen = SiteGenerator()
    auditor = SeoAuditor()
    site_infos = []
    seo_ok = True
    p("[3] 多语言站点生成（中/英/德三语，数据驱动）")
    for locale in ("zh", "en", "de"):
        info = gen.generate(locale, SITES_DIR)
        with open(info["file"], "r", encoding="utf-8") as f:
            audit = auditor.audit(f.read())
        site_infos.append(info)
        seo_ok = seo_ok and audit["overall"]
        p("    {} -> {} | SEO {}".format(info["lang_code"], info["file"],
                                         "PASS" if audit["overall"] else "FAIL"))
    p("")

    # 4. 询盘→CRM 闭环（确定性打分 / SLA 时钟 / 负责人 / 跟进任务 / 报价草稿 / 管线事件）
    p("[4] 询盘→CRM 闭环")
    crm_passed = 0
    cases = load_crm_cases()
    for case in cases:
        flow = run_crm_flow(case["industry"], case["lead"])
        rec, score, quote = flow["record"], flow["score"], flow["quote"]
        followup = rec["followup_task"]
        expect = case["expect"]
        ok = (score["qualified"] == expect["qualified"]
              and rec["stage"] == expect["final_stage"]
              and (quote or {}).get("amount_usd") == expect["quote_amount"]
              and score["score"] == expect["score"])
        crm_passed += 1 if ok else 0
        p("    {} [{}] 分数={} 达标={} 阶段={} 跟进={}(due {}) 报价USD={} {}".format(
            case["case_id"], case["industry"], score["score"], score["qualified"],
            rec["stage"], followup["owner"], followup["due"],
            (quote or {}).get("amount_usd") if quote else "N/A",
            "PASS" if ok else "FAIL"))
    p("")

    # 5. FDE 驻企交付手册 + 一企一档样例 + 12 项上线清单 + go-live readiness
    hb = load_handbook()
    profile = load_enterprise_profile()
    readiness = derive_go_live_readiness(profile)
    p("[5] FDE 驻企交付：手册 / 一企一档 / 上线清单 / go-live readiness")
    p("    手册章节 {} | 一企一档 {}（{}） | 上线清单 {} 项 | readiness={}（{}/{}）".format(
        len(hb["handbook"]["chapters"]), profile["profile_id"], profile["enterprise_name"],
        len(hb["go_live_checklist"]), readiness["level"], readiness["score"], readiness["total"]))
    p("")
    return {
        "components": len(comps),
        "industry_switch": {"jewelry_kb": kb_j["answer"], "wood_kb": kb_w["answer"]},
        "sites": [info["file"] for info in site_infos],
        "seo_passes": seo_ok,
        "crm_cases": {"passed": crm_passed, "total": len(cases)},
        "fde": {"chapters": len(hb["handbook"]["chapters"]),
                "checklist": len(hb["go_live_checklist"]),
                "readiness": readiness["level"],
                "readiness_score": readiness["score"]},
        "ok": seo_ok and crm_passed == len(cases),
    }


def run_module_c_demo(verbose=True):
    """模块 C：文化 IP 内容与授权管线（验收 7 演示）。"""
    def p(msg):
        if verbose:
            print(msg)

    p("ClawHunt #1724 模块 C：文化 IP 内容与授权管线（纯标准库，零依赖）")
    p("蓝本: proposal_Task1724.md 验收标准 7/10")
    p("")

    # 1. 双守护角色设定手册（内容守护 / 技术守护）+ 规则与审查清单
    hb = verify_handbook()
    chars = load_characters()["characters"]
    p("[1] IP 双守护角色设定手册（{} 个角色）".format(len(chars)))
    for c in chars:
        p("    {}（{}）守则 {} 条 | 审查清单 {} 项 | 关系：{}".format(
            c["name"], c["duty"], len(c["rules"]), len(c["review_checklist"]),
            c["relationship"]))
    p("    手册完整性校验：{}".format("PASS" if hb["ok"] else "FAIL"))
    p("    权利边界：{}".format(load_characters()["non_exclusive_clause"]))
    p("")

    # 2. 视觉资产库：SVG 配方（>=6 类）+ 渲染/校验 + 资产清单与变更追溯
    recipes = load_recipes()
    lib = AssetLibrary()
    p("[2] 视觉资产库：{} 类原创 SVG 配方".format(len(recipes)))
    for r in recipes:
        res = render_recipe(r["recipe_id"])
        v = validate_svg(res["svg"])
        p("    {}（{}）渲染 {} | 校验 {}".format(
            r["recipe_id"], r["category"], "OK" if res["ok"] else "FAIL",
            "PASS" if v["ok"] else "FAIL"))
    added = []
    for r in recipes:
        a = lib.add(r["recipe_id"], operator="demo", note="演示登记")
        if a["ok"]:
            added.append(a["asset"])
    p("    资产登记 {} 项（校验和 sha256 追溯） | 变更日志 {} 条".format(
        len(added), len(lib.list_changelog())))
    p("")

    # 3. 短剧工作流：剧本→分镜→资产→渲染→内容审核→成片（含返工分支）
    script_path = os.path.join(PROJECT_ROOT, "module_c", "data", "script_sample.json")
    import json as _json
    with open(script_path, "r", encoding="utf-8") as f:
        script = _json.load(f)
    out_dir = os.path.join(PROJECT_ROOT, "output", "episode_demo")
    ep = run_auto(script, out_dir)
    p("[3] 短剧工作流：{}（{}）".format(ep["episode_id"], ep["title"]))
    p("    状态机轨迹：{} 个环节，最终状态 {} | 返工事件 {} 次".format(
        len(ep["states_visited"]), ep["final_state"], len(ep["rework_events"])))
    for ev in ep["rework_events"]:
        p("      返工 -> {}：{} 条违规被内容守护拦截并净化".format(
            ev["stage"], len(ev["violations"])))
    p("    分镜 {} 镜 | 成片帧 {} 帧（SVG，全部通过渲染校验）".format(
        len(ep["storyboard"]), len(ep["frames"])))
    for f in ep["frames"][:3]:
        p("      帧 {}".format(f["path"]))
    p("    工作流日志 -> {} | 审核日志 -> {}".format(
        ep["log_file"], ep["review_log_file"]))
    p("")

    # 4. 授权矩阵 + 衍生品规范 + 内容审核日志
    matrix = load_matrix()
    p("[4] IP 授权文档 + 衍生品规范 + 内容审核")
    p("    授权矩阵 {} 类（期限/版税/审批门禁） | 衍生品规范 {} 类".format(
        len(matrix["license_matrix"]), len(list_derivative_specs())))
    contract = render_license_contract("merchandise_license", "示例品牌（脱敏）", "衍生品联名")
    p("    合同样张（节选）:")
    for line in contract.splitlines()[1:6]:
        p("      " + line)
    safety = load_safety_words()
    ok_line = "守艺人的灯塔：非遗再创作，讲述海洋文化。AI 生成。"
    bad_line = "这只手艺人灯笼据说开光保平安。"
    r_ok = review_content(ok_line, safety=safety, meta={"ai_marking": True})
    r_bad = review_content(bad_line, safety=safety, meta={"ai_marking": True})
    p("    审核样例：合规文本 -> {} | 违规文本（含'开光'）-> {}（命中 {}）".format(
        r_ok["decision"], r_bad["decision"], [w for w, _ in r_bad["hits"]]))
    p("")
    return {
        "ok": hb["ok"] and len(recipes) >= 6 and len(added) == len(recipes)
              and ep["ok"] and len(ep["frames"]) > 0 and len(ep["rework_events"]) > 0
              and r_ok["ok"] and not r_bad["ok"],
        "characters": len(chars), "recipes": len(recipes), "assets": len(added),
        "episode_frames": len(ep["frames"]), "rework_events": len(ep["rework_events"]),
        "licenses": len(matrix["license_matrix"]),
        "derivative_specs": len(list_derivative_specs()),
        "episode_dir": out_dir,
    }


def run_module_d_demo(verbose=True):
    """模块 D：设计共创赛事运营包（验收 8 配套，可选加分项）。"""
    def p(msg):
        if verbose:
            print(msg)

    p("ClawHunt #1724 模块 D：设计共创赛事运营包（JSON 配置驱动，纯标准库）")
    p("蓝本: proposal_Task1724.md 模块 D / M4 交付")
    p("")

    # 1. 赛道定义
    tracks = list_tracks()
    p("[1] 赛道定义：{} 条赛道".format(len(tracks)))
    for t in tracks:
        p("    {}（{}）主题：{} | 奖项：{}".format(
            t["track_id"], t["name"], t["theme"], "、".join(t["awards"])))
    p("")

    # 2. 评审标准与计分表
    from module_d.contest import load_config
    cfg = load_config()
    criteria = cfg["review_criteria"]
    p("[2] 评审标准与计分表（{} 项标准，满分 {}）".format(len(criteria), cfg["scorecard"]["total_max"]))
    for c in criteria:
        p("    {} 权重 {} 满分 {}".format(c["criterion"], c["weight"], c["max_score"]))
    p("    合成参赛作品计分：")
    for e in cfg["sample_entries"]:
        sc = score_entry(e)
        p("      {} -> 总分 {} [{}] {}".format(
            e["entry_id"], sc["total"], sc["verdict"], e["concept"]))
    p("")

    # 3. 打样环节流程（含门禁）
    p("[3] 打样环节流程：{} 阶段".format(len(cfg["sampling_flow"]["stages"])))
    for e in cfg["sample_entries"][:3]:
        flow = run_sampling_flow(e)
        p("    {} 推进到 [{}]{}".format(
            e["entry_id"], flow["final_stage"], "（门禁拦截）" if flow["blocked"] else ""))
    p("")

    # 4. 传播矩阵与 KPI 看板
    board = build_kpi_board()
    p("[4] 传播矩阵与 KPI 看板（{} 渠道）".format(len(cfg["promotion_matrix"])))
    for ind in board["indicators"]:
        p("    {}：当前 {} / 目标 {} -> {}".format(
            ind["indicator"], ind["current"], ind["target"], ind["status"]))
    p("    KPI 全部达标：{}".format("是" if board["all_met"] else "否"))
    p("")
    return {
        "ok": len(tracks) >= 3 and board["all_met"],
        "tracks": len(tracks), "entries": len(cfg["sample_entries"]),
        "kpi_met": board["all_met"],
    }


def main():
    print("ClawHunt #1724 模块 A+B+C+D 最小可运行闭环原型（纯 Python 标准库，零依赖）")
    print("蓝本: proposal_Task1724.md 验收标准 2/3/4/5/6/7/8")
    print()
    auth = run_auth_demo(verbose=True)
    print()
    mfg = run_mfg_demo(verbose=True)
    print()
    order = run_order_demo(verbose=True)
    print()
    b = run_module_b_demo(verbose=True)
    print()
    c = run_module_c_demo(verbose=True)
    print()
    d = run_module_d_demo(verbose=True)
    print("=" * 70)
    print("汇总：授权校验 {} | 可制造性判定 {}/{} | C2M 订单链路 {} | 模块B（注册表{}组件/SEO {} | CRM {}/{}/FDE-{}） | 模块C（角色{}/资产{}/样片帧{}/返工{}） | 模块D（赛道{}/KPI {}）".format(
        "PASS" if auth["ok"] else "FAIL", mfg["score"], mfg["total"],
        "PASS" if order["ok"] else "FAIL", b["components"],
        "PASS" if b["seo_passes"] else "FAIL", b["crm_cases"]["passed"], b["crm_cases"]["total"],
        b["fde"]["readiness"], c["characters"], c["recipes"], c["episode_frames"],
        c["rework_events"], d["tracks"],
        "PASS" if d["kpi_met"] else "FAIL"))
    all_ok = auth["ok"] and mfg["ok"] and order["ok"] and b["ok"] and c["ok"] and d["ok"]
    print("总体：{}".format("全部通过" if all_ok else "存在失败项"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
