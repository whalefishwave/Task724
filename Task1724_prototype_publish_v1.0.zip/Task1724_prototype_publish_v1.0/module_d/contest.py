"""模块 D：设计共创赛事运营包（可选，JSON 配置驱动，纯标准库）。

覆盖：赛道定义 / 评审标准与计分表 / 打样环节流程（含门禁）/ 传播矩阵与 KPI 看板。
示例数据全部为合成/脱敏，确定性输出。
"""

_STUB_NOTE = "核心实现将于中标后提供（full implementation provided after award）"

import json
import os

_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "contest_config.json")


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_config():
    return _load_json(_DATA_PATH)


def list_tracks():
    return [dict(t) for t in load_config()["tracks"]]


def review_criteria():
    return [dict(c) for c in load_config()["review_criteria"]]


def weighted_total(scores):
    """[发布版占位] 加权评分核心实现将于中标后提供。"""
    return 0.0, [{"criterion": "core", "score": 0, "weight": 0.0, "contrib": 0.0,
                  "stub": _STUB_NOTE}]
def score_entry(entry):
    """[发布版占位] 参赛作品评分/进打样判定核心实现将于中标后提供。"""
    return {"entry_id": entry.get("entry_id", ""), "track": entry.get("track", ""),
            "total": 0.0, "rows": [], "verdict": "待定（评分核心将于中标后提供）",
            "sample_required": 0, "pass_threshold": 0, "stub": True}
def run_sampling_flow(entry):
    """[发布版占位] 打样环节门禁流程核心实现将于中标后提供。"""
    return {"entry_id": entry.get("entry_id", ""),
            "stages": [{"stage": "stub", "status": "blocked", "gate": _STUB_NOTE}],
            "final_stage": "stub", "blocked": True, "stub": True}
def build_kpi_board():
    """[发布版占位] 传播矩阵与 KPI 看板核心实现将于中标后提供。"""
    return {"contest_id": "stub", "by_track": {},
            "indicators": [{"indicator": "核心 KPI（中标后提供）", "current": 0,
                            "target": 0, "status": "未达标"}],
            "promotion": [], "sampling_entries": [], "licensed_products": [],
            "all_met": False, "stub": True}
