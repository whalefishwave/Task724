\---  
AIGC:  
Label: "1"  
ContentProducer: 001191440300708461136T1XGW3  
ProduceID: 1fcf3b7f0441803325c1c7498ed7e993_103e123ad36c11f1acf9525400393706  
ReservedCode1: m0HEhr0t9wPRzGQKaFnuKTZpRQMiTv9FYqeasnArFb59n2mSCCXQn0fvY0EMITaXwC48qmL8EHAtLkKnq+Vuh3Gg2Klfy4QS7UpF7UFAubWIpXuTnv9ZlccS3RIKS4DBOxQwvZZKTawwu0F5YiBuyIln60TRbUcBR7QTEKiA3pHtNeFwzyJyPtv9M30=  
ContentPropagator: 001191440300708461136T1XGW3  
PropagateID: 1fcf3b7f0441803325c1c7498ed7e993_103e123ad36c11f1acf9525400393706  
ReservedCode2: m0HEhr0t9wPRzGQKaFnuKTZpRQMiTv9FYqeasnArFb59n2mSCCXQn0fvY0EMITaXwC48qmL8EHAtLkKnq+Vuh3Gg2Klfy4QS7UpF7UFAubWIpXuTnv9ZlccS3RIKS4DBOxQwvZZKTawwu0F5YiBuyIln60TRbUcBR7QTEKiA3pHtNeFwzyJyPtv9M30=  
\---

# prototype_heavy 验收自检报告（G1-G10）

# prototype_heavy Acceptance Self-Check Report (G1-G10)

运行时间：2026-10-29 15:36:46  
Run time: 2026-10-29 15:36:46

- **G1** ✅ 满足: A流程全链=True B六组件=True C双角色+授权=True D赛事门禁=True
  - **G1** ✅ Met: A full pipeline=True B six components=True C dual characters+license=True D contest gate=True
- **G2** ✅ 满足: 缺任一字段均拒绝 6/6，全字段通过=True
  - **G2** ✅ Met: rejects when any field is missing 6/6, all fields present=True
- **G3** ✅ 满足: 与人工规则一致 10/10
  - **G3** ✅ Met: consistent with manual rules 10/10
- **G4** ✅ 满足: 状态=QC 台账 7 条可追溯=True
  - **G4** ✅ Met: status=QC ledger with 7 traceable entries=True
- **G5** ✅ 满足: 可配置行业: ['jewelry', 'wood']
  - **G5** ✅ Met: configurable industries: ['jewelry', 'wood']
- **G6** ✅ 满足: 三语=['zh', 'en', 'de'] 询盘CRM=1 条 闭环=True
  - **G6** ✅ Met: tri-lingual=['zh', 'en', 'de'] inquiry CRM=1 record closed-loop=True
- **G7** ✅ 满足: 双角色=['designer', 'craftsman'] 授权矩阵 allowed=True 样片落盘=True
  - **G7** ✅ Met: dual characters=['designer', 'craftsman'] license matrix allowed=True sample written to disk=True
- **G8** ✅ 满足: pytest: 126 passed, exit=0
  - **G8** ✅ Met: pytest: 126 passed, exit=0
- **G9** ✅ 满足: 命令真实存在 8/8
  - **G9** ✅ Met: commands all real 8/8
- **G10** ✅ 满足: 合成/脱敏标识 21/22 个数据文件
  - **G10** ✅ Met: synthetic/anonymized labels on 21/22 data files

## 结论: 10/10 满足

## Conclusion: 10/10 Met

*（内容由AI生成，仅供参考）*
