# -*- coding: utf-8 -*-
"""prototype_heavy FastAPI 应用入口（Uvicorn 启动）。

启动示例:
    uvicorn app.main:app --host 0.0.0.0 --port 8000

说明: 本仓库为应标原型，核心业务逻辑全部位于 modules/（纯 Python，可离线自测）；
API 层将模块能力以 REST 接口暴露，供 React/Vite 前端与 Streamlit 仪表盘调用。
数据库默认降级为 sqlite/file 后端（测试可跑通）；生产切换 PG16+pgvector
通过环境变量 APP_DB_URL 指向 postgresql+psycopg2://... 实现。
"""
from __future__ import annotations

import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

# 样片静态目录：/media 挂载仓库 output 目录（demo_video / samples 下的视频）
# 挂载前确保目录存在（缺失时创建空目录，避免启动失败）。
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MEDIA_ROOT = os.path.join(ROOT_DIR, "output")
os.makedirs(MEDIA_ROOT, exist_ok=True)

app = FastAPI(title="ClawHunt #1724 prototype_heavy", version="1.0.0")
app.mount("/media", StaticFiles(directory=MEDIA_ROOT), name="media")


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "stack": "FastAPI/Uvicorn + React/Vite + PG16/pgvector + SDXL(mock)"}


@app.get("/api/industries")
def industries() -> dict:
    from modules.module_b.enterprise_service import EnterpriseService
    return {"industries": ["jewelry", "wood"]}


@app.get("/api/components/{industry}")
def components(industry: str) -> dict:
    from modules.module_b.enterprise_service import EnterpriseService
    svc = EnterpriseService(industry)
    return {"industry": industry, "components": svc.summary()["components"]}
