# -*- coding: utf-8 -*-
"""ClawHunt #1724 重技术栈版发布包生成脚本（从 prototype_heavy 原版生成去核心化发布版 prototype_heavy_publish）。

用法:
    python scripts/make_publish_heavy.py build

流程:
    1. 若目标 prototype_heavy_publish 已存在，先整体移动为 prototype_heavy_publish.bak_<时间戳>（不删除）；
    2. 从 prototype_heavy 全量复制到 prototype_heavy_publish（排除 __pycache__/.pytest_cache/publish_stubs_heavy 等）；
    3. 剔除发布版不含的私有资产（拼接中间产物、Neil 私有配音音频、1080p 合成中间目录等；
       正式样本视频 ai_demo_heavy_1080p_voice_neil_bgm_v1.mp4 / demo_ep001.mp4 保留，供「申请查看样片」播放）；
    4. 用 scripts/publish_stubs_heavy/ 覆盖 13 个核心业务模块为占位桩（module_a/b/c/d 全业务闭环，
       均标注「核心实现将于中标后提供 / core implementation provided after award」）；
    5. 输出去核心化清单 JSON（供 README/VERIFICATION 引用）。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import time
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../prototype_heavy
PARENT = os.path.dirname(ROOT)                                       # .../Task1724
PUB = os.path.join(PARENT, "prototype_heavy_publish")
STUBS = os.path.join(ROOT, "scripts", "publish_stubs_heavy")

ZIP_NAME = "Task1724_prototype_heavy_publish_v1.0.zip"               # 发布 zip 文件名（放 PARENT 下）
ZIP_TOP = "Task1724_prototype_heavy_publish_v1.0"                    # zip 内顶层目录名（同零依赖版命名风格）

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", "publish_stubs_heavy", ".git", ".idea", ".vscode"}
EXCLUDE_EXT = {".pyc", ".pyo"}

# 发布版剔除的私有资产（相对 output/）：
# 注意：正式样本视频（output/demo_video/ai_demo_heavy_1080p_voice_neil_bgm_v1.mp4 与
# output/samples/demo_ep001.mp4）必须保留，供前端「申请查看样片（演示）」播放，不得列入剔除清单。
REMOVE_GLOBS = [
    "output/demo_video/video_concat_heavy.mp4",                       # 拼接中间产物
    "output/demo_video/video_concat_heavy_v2.mp4",                    # 拼接中间产物
]
REMOVE_DIRS = [
    "output/demo_video/tts_voices_neil",                              # Neil 配音音频（私有）
    "output/demo_video/_1080p_work",                                  # 1080p 合成中间产物
]

STUB_FILES = [
    "modules/module_a/auth_fields.py",
    "modules/module_a/manufacturability.py",
    "modules/module_a/order_machine.py",
    "modules/module_a/trades.py",
    "modules/module_b/component_registry.py",
    "modules/module_b/enterprise_service.py",
    "modules/module_b/export_stack.py",
    "modules/module_b/fde_handbook.py",
    "modules/module_c/assets.py",
    "modules/module_c/characters.py",
    "modules/module_c/license.py",
    "modules/module_c/pipeline.py",
    "modules/module_d/contest.py",
]


def _ignore(src, names):
    ignored = []
    for n in names:
        full = os.path.join(src, n)
        if os.path.isdir(full):
            if os.path.basename(full) in EXCLUDE_DIRS:
                ignored.append(n)
        else:
            if os.path.splitext(full)[1] in EXCLUDE_EXT:
                ignored.append(n)
    return set(ignored)


def rebuild_publish() -> str | None:
    """重建 prototype_heavy_publish。返回备份目录名（若无备份返回 None）。"""
    backup = None
    if os.path.exists(PUB):
        backup = PUB + ".bak_" + time.strftime("%Y%m%d_%H%M%S")
        shutil.move(PUB, backup)
    shutil.copytree(ROOT, PUB, ignore=_ignore)
    return backup


def remove_private_assets() -> list[str]:
    """剔除发布版中的私有样片/音频/中间产物（相对路径清单，移入带时间戳的备份目录，不物理删除）。"""
    removed = []
    stash = os.path.join(PARENT, "prototype_heavy_publish_removed_" + time.strftime("%Y%m%d_%H%M%S"))
    for rel_dir in REMOVE_DIRS:
        full = os.path.join(PUB, rel_dir)
        if os.path.isdir(full):
            dst = os.path.join(stash, rel_dir.replace(os.sep, "/"))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.move(full, dst)
            removed.append(rel_dir.replace(os.sep, "/") + "/")
    for rel_glob in REMOVE_GLOBS:
        full = os.path.join(PUB, rel_glob)
        if os.path.isfile(full):
            dst = os.path.join(stash, rel_glob.replace(os.sep, "/"))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.move(full, dst)
            removed.append(rel_glob.replace(os.sep, "/"))
    return removed


def apply_stubs() -> list[str]:
    """用 publish_stubs_heavy/ 覆盖核心业务模块为占位桩。"""
    applied = []
    for rel in STUB_FILES:
        src = os.path.join(STUBS, rel)
        dst = os.path.join(PUB, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        applied.append(rel.replace(os.sep, "/"))
    return applied


def pack_zip() -> str:
    """将 prototype_heavy_publish 打包为 Task1724_prototype_heavy_publish_v1.0.zip（顶层目录 ZIP_TOP）。"""
    zip_path = os.path.join(PARENT, ZIP_NAME)
    if os.path.exists(zip_path):
        shutil.move(zip_path, zip_path + ".bak_" + time.strftime("%Y%m%d_%H%M%S"))
    count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root_dir, dirs, files in os.walk(PUB):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in files:
                if os.path.splitext(f)[1] in EXCLUDE_EXT:
                    continue
                full = os.path.join(root_dir, f)
                rel = os.path.relpath(full, PUB)
                arc = os.path.join(ZIP_TOP, rel).replace(os.sep, "/")
                zf.write(full, arc)
                count += 1
    return f"{zip_path} ({count} files)"


def main() -> int:
    backup = rebuild_publish()
    removed = remove_private_assets()
    applied = apply_stubs()
    print(json.dumps({
        "backup": backup,
        "private_assets_removed": removed,
        "stubs_applied": applied,
        "publish_dir": PUB,
        "zip": pack_zip(),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
