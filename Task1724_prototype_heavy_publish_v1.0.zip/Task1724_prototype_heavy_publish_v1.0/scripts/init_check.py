# -*- coding: utf-8 -*-
"""环境与仓库完整性自检（对应 G9：文档命令真实存在、一条命令可复现）。

用法: python scripts/init_check.py
退出码: 0=全绿  1=存在警告/失败
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def check(name: str, ok: bool, detail: str = "") -> None:
    status = "OK " if ok else "WARN"
    print(f"[{status}] {name}" + (f" - {detail}" if detail else ""))
    if not ok:
        CHECKS_FAILED.append((name, detail))


CHECKS_FAILED: list[tuple[str, str]] = []


def main() -> int:
    print("=" * 64)
    print("prototype_heavy 环境与完整性自检")
    print("=" * 64)

    check("Python >= 3.10", sys.version_info >= (3, 10), f"{sys.version.split()[0]}")
    check("pytest 已安装", _importable("pytest"))

    # 目录结构
    required_dirs = [
        "app/api", "core", "modules/module_a", "modules/module_b",
        "modules/module_c", "modules/module_d", "ai", "tests", "scripts",
        "web", "deploy", "data", "docs", "output/samples",
    ]
    for d in required_dirs:
        check(f"目录 {d}", os.path.isdir(os.path.join(ROOT, d)))

    # 关键文件
    required_files = [
        "core/rules_engine.py", "core/rules_demo.yaml",
        "modules/module_a/order_machine.py", "modules/module_a/manufacturability.py",
        "modules/module_a/auth_fields.py", "modules/module_a/trades.py",
        "modules/module_b/component_registry.py", "modules/module_b/enterprise_service.py",
        "modules/module_b/export_stack.py", "modules/module_b/fde_handbook.py",
        "modules/module_c/characters.py", "modules/module_c/assets.py",
        "modules/module_c/license.py", "modules/module_c/pipeline.py",
        "modules/module_d/contest.py",
        "ai/sdxl_client.py", "ai/llm_client.py", "ai/workflow_engine.py",
        "app/main.py", "web/streamlit_app.py",
        "tests/conftest.py",
    ]
    for f in required_files:
        check(f"文件 {f}", os.path.isfile(os.path.join(ROOT, f)))

    # 数据文件（G10：合成脱敏样例）
    data_dir = os.path.join(ROOT, "modules")
    json_count = 0
    for root, _dirs, files in os.walk(data_dir):
        for fn in files:
            if fn.endswith(".json"):
                json_count += 1
    check("模块数据 JSON 文件 >= 20", json_count >= 20, f"共 {json_count} 个")

    # 规则文件可加载
    try:
        sys.path.insert(0, ROOT)
        from core.rules_engine import RuleEngine  # noqa: F401

        RuleEngine.from_file(os.path.join(ROOT, "modules", "module_a", "data", "mfg_rules_jewelry.json"))
        RuleEngine.from_file(os.path.join(ROOT, "core", "rules_demo.yaml"))
        check("规则引擎加载 JSON/YAML", True)
    except Exception as exc:  # pragma: no cover
        check("规则引擎加载 JSON/YAML", False, str(exc))

    # pytest 冒烟（跑一次，只统计）
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", "tests", "-q", "--tb=no"],
            cwd=ROOT, capture_output=True, text=True, timeout=180,
        )
        tail = (proc.stdout or "").strip().splitlines()[-1] if proc.stdout else ""
        check("pytest 冒烟", proc.returncode == 0, tail)
    except Exception as exc:  # pragma: no cover
        check("pytest 冒烟", False, str(exc))

    # 三平台一键脚本（G9）
    deploy_scripts = ["deploy/install_windows.ps1", "deploy/install_macos.sh", "deploy/install_linux.sh", "deploy/docker-compose.yml"]
    for s in deploy_scripts:
        check(f"部署脚本 {s}", os.path.isfile(os.path.join(ROOT, s)))

    print("-" * 64)
    if CHECKS_FAILED:
        print(f"自检完成：{len(CHECKS_FAILED)} 项警告/失败")
        for name, detail in CHECKS_FAILED:
            print(f"  - {name}: {detail}")
        return 1
    print("自检完成：全绿")
    return 0


def _importable(module: str) -> bool:
    try:
        __import__(module)
        return True
    except Exception:
        return False


if __name__ == "__main__":
    sys.exit(main())
