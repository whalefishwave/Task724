# -*- coding: utf-8 -*-
"""G1-G10 十条验收逐条自检（对应 proposal 第 1.2 章）。

用法: python scripts/verify.py
退出码: 0=全部满足  1=存在未满足项
"""
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

RESULTS: list[dict] = []


def record(g: str, ok: bool, detail: str) -> None:
    RESULTS.append({"g": g, "ok": ok, "detail": detail})
    print(f"[{'PASS' if ok else 'FAIL'}] {g} - {detail}")


def main() -> int:
    print("=" * 70)
    print("prototype_heavy 验收自检（G1-G10）")
    print("=" * 70)

    # ---------- G1 四条主流程可点通 ----------
    try:
        from modules.module_a.order_machine import OrderMachine
        from modules.module_a.trades import split_custom_order
        m = OrderMachine(order_id="V-G1")
        for ev in ("pay", "make_work_order", "dispatch", "qc_pass", "ship", "settle"):
            m.transition(ev, actor="auto")
        g1a = m.state == "SETTLED" and len(m.ledger_summary()["timeline"]) >= 7

        from modules.module_b.enterprise_service import EnterpriseService
        svc = EnterpriseService("jewelry")
        g1b = len(svc.summary()["components"]) == 6

        from modules.module_c.characters import CharacterBook
        from modules.module_c.license import LicenseMatrix
        g1c = len(CharacterBook().list_characters()) == 2 and LicenseMatrix().check("merchandise", "non_exclusive")["allowed"]

        from modules.module_d.contest import ContestManager
        cm = ContestManager()
        s = cm.submit("jewelry", "选手", "设计")
        cm.score(s["id"], "评委", 90.0)
        g1d = cm.prototype_gate(s["id"], manufacturable=True)["gate"] in ("passed", "pass", "approved", "allowed")
        record("G1", g1a and g1b and g1c and g1d,
               f"A流程全链={g1a} B六组件={g1b} C双角色+授权={g1c} D赛事门禁={g1d}")
    except Exception as exc:  # pragma: no cover
        record("G1", False, f"异常: {exc}")

    # ---------- G2 授权字段强校验（缺字段 100% 拒绝） ----------
    try:
        from modules.module_a.auth_fields import REQUIRED_FIELDS, validate_auth_fields
        valid = {"pattern_id": "P-1", "source": "self", "holder": "组", "license_type": "non_exclusive",
                 "scope": "珠宝", "expiry": "2030-12-31", "ai_generated": True}
        ok_all = validate_auth_fields(valid)["ok"]
        rejected = 0
        for key in REQUIRED_FIELDS:
            data = dict(valid)
            del data[key]
            if not validate_auth_fields(data)["ok"]:
                rejected += 1
        record("G2", ok_all and rejected == len(REQUIRED_FIELDS), f"缺任一字段均拒绝 {rejected}/{len(REQUIRED_FIELDS)}，全字段通过={ok_all}")
    except Exception as exc:  # pragma: no cover
        record("G2", False, f"异常: {exc}")

    # ---------- G3 可制造性 10/10 与人工一致 ----------
    try:
        from modules.module_a.manufacturability import ManufacturabilityAssessor, load_cases
        cases = load_cases()
        agreed = 0
        for case in cases:
            industry = case.get("industry_hint", "jewelry")
            try:
                assessor = ManufacturabilityAssessor(industry)
            except Exception:
                assessor = ManufacturabilityAssessor("jewelry")
            out = assessor.evaluate(case["design"], case.get("equipment_id"))
            if out["verdict"] == case["expected"]:
                agreed += 1
        record("G3", agreed == len(cases) and len(cases) >= 10, f"与人工规则一致 {agreed}/{len(cases)}")
    except Exception as exc:  # pragma: no cover
        record("G3", False, f"异常: {exc}")

    # ---------- G4 C2M 状态机台账可追溯 ----------
    try:
        from modules.module_a.order_machine import OrderMachine
        m = OrderMachine(order_id="V-G4")
        m.transition("pay", actor="buyer", amount=100)
        m.transition("make_work_order", actor="designer")
        m.transition("dispatch", actor="workshop")
        m.transition("qc_fail", actor="qc", note="重做")
        m.transition("dispatch", actor="workshop")
        m.transition("qc_pass", actor="qc")
        s = m.ledger_summary()
        g4 = s["final_state"] == "QC" and len(s["entries"]) >= 7 and s["entries"][0].get("to") == "CREATED"
        record("G4", g4, f"状态={s['final_state']} 台账 {len(s['entries'])} 条可追溯={g4}")
    except Exception as exc:  # pragma: no cover
        record("G4", False, f"异常: {exc}")

    # ---------- G5 企业 AI 服务层 ≥2 行业配置切换 ----------
    try:
        from modules.module_b.enterprise_service import EnterpriseService
        industries = []
        for industry in ("jewelry", "wood", "ceramics"):
            try:
                svc = EnterpriseService(industry)
                industries.append(svc.summary()["industry"])
            except Exception:
                pass
        record("G5", len(industries) >= 2, f"可配置行业: {industries}")
    except Exception as exc:  # pragma: no cover
        record("G5", False, f"异常: {exc}")

    # ---------- G6 出海三语站点 / SEO / 询盘 CRM 闭环 ----------
    try:
        from modules.module_b.export_stack import ExportStack
        stack = ExportStack()
        langs = list(stack.seo_report().keys())
        lead = stack.submit_inquiry("buyer@example.com", "custom ring", source_lang="en")
        stack.follow_up(lead["lead_id"])
        crm_total = stack.crm_summary()["total"]
        closed = lead["status"] == "FOLLOWED_UP"
        g6 = len(langs) >= 3 and crm_total >= 1 and closed
        record("G6", g6, f"三语={langs} 询盘CRM={crm_total} 条 闭环={closed}")
    except Exception as exc:  # pragma: no cover
        record("G6", False, f"异常: {exc}")

    # ---------- G7 IP 双角色 + 授权矩阵 + 短剧样片落盘 ----------
    try:
        from modules.module_c.characters import CharacterBook
        from modules.module_c.license import LicenseMatrix
        from modules.module_c.pipeline import PipelineMachine
        book = CharacterBook()
        roles = [c["role"] for c in book.list_characters()]
        matrix = LicenseMatrix()
        combo = matrix.check("merchandise", "non_exclusive")
        out_dir = os.path.join(ROOT, "output", "samples")
        os.makedirs(out_dir, exist_ok=True)
        machine = PipelineMachine("V-G7")
        machine.fire("submit")
        machine.fire("approve")
        machine.render()
        pub = machine.publish(os.path.join(out_dir, "verify_ep001.mp4"))
        exists = os.path.isfile(pub.get("output_path", ""))
        g7 = len(roles) == 2 and combo["allowed"] and exists
        record("G7", g7, f"双角色={roles} 授权矩阵 allowed={combo['allowed']} 样片落盘={exists}")
    except Exception as exc:  # pragma: no cover
        record("G7", False, f"异常: {exc}")

    # ---------- G8 核心逻辑单测一条命令全绿（≥40） ----------
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", "tests", "-q", "--tb=no"],
            cwd=ROOT, capture_output=True, text=True, timeout=300,
        )
        tail = (proc.stdout or "").strip().splitlines()
        m = re.search(r"(\d+) passed", tail[-1] if tail else "")
        passed = int(m.group(1)) if m else 0
        record("G8", proc.returncode == 0 and passed >= 40, f"pytest: {passed} passed, exit={proc.returncode}")
    except Exception as exc:  # pragma: no cover
        record("G8", False, f"异常: {exc}")

    # ---------- G9 文档命令真实存在 ----------
    try:
        commands = {
            "python scripts/init_check.py": os.path.isfile(os.path.join(ROOT, "scripts", "init_check.py")),
            "python scripts/demo.py": os.path.isfile(os.path.join(ROOT, "scripts", "demo.py")),
            "python scripts/verify.py": os.path.isfile(os.path.join(ROOT, "scripts", "verify.py")),
            "python -m pytest tests": os.path.isdir(os.path.join(ROOT, "tests")),
            "deploy/install_windows.ps1": os.path.isfile(os.path.join(ROOT, "deploy", "install_windows.ps1")),
            "deploy/install_macos.sh": os.path.isfile(os.path.join(ROOT, "deploy", "install_macos.sh")),
            "deploy/install_linux.sh": os.path.isfile(os.path.join(ROOT, "deploy", "install_linux.sh")),
            "deploy/docker-compose.yml": os.path.isfile(os.path.join(ROOT, "deploy", "docker-compose.yml")),
        }
        all_exist = all(commands.values())
        record("G9", all_exist, f"命令真实存在 {sum(commands.values())}/{len(commands)}")
    except Exception as exc:  # pragma: no cover
        record("G9", False, f"异常: {exc}")

    # ---------- G10 示例数据合成脱敏合规 ----------
    try:
        data_files = []
        for root, _dirs, files in os.walk(os.path.join(ROOT, "modules")):
            for fn in files:
                if fn.endswith(".json"):
                    data_files.append(os.path.join(root, fn))
        masked = 0
        for fp in data_files:
            with open(fp, "r", encoding="utf-8") as f:
                text = f.read()
            if "ai_generated" in text or "masked" in text or "synthetic" in text.lower() or "test" in text.lower():
                masked += 1
        record("G10", masked >= len(data_files) * 0.8, f"合成/脱敏标识 {masked}/{len(data_files)} 个数据文件")
    except Exception as exc:  # pragma: no cover
        record("G10", False, f"异常: {exc}")

    print("-" * 70)
    ok_count = sum(1 for r in RESULTS if r["ok"])
    print(f"验收自检完成：{ok_count}/10 满足")
    report_path = os.path.join(ROOT, "output", "VERIFICATION_heavy.md")
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("# prototype_heavy 验收自检报告（G1-G10）\n\n")
        f.write(f"运行时间：{__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for r in RESULTS:
            f.write(f"- **{r['g']}** {'✅ 满足' if r['ok'] else '❌ 未满足'}: {r['detail']}\n")
        f.write(f"\n## 结论: {ok_count}/10 满足\n")
    print(f"报告已写入: {report_path}")
    return 0 if ok_count == 10 else 1


if __name__ == "__main__":
    sys.exit(main())
