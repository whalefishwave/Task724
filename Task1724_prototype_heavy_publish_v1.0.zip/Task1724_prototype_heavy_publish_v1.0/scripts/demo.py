# -*- coding: utf-8 -*-
"""四条主流程端到端演示（对应 G1：主流程可点通）。

用法: python scripts/demo.py [--no-samples]
退出码: 0=演示成功
"""
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

SAMPLES_DIR = os.path.join(ROOT, "output", "samples")


def demo_module_a() -> None:
    """主流程1：工艺AI共创 + C2M 订单（下单→工艺单→派单→品控→发货→分成）。"""
    from modules.module_a.order_machine import OrderMachine
    from modules.module_a.manufacturability import ManufacturabilityAssessor
    from modules.module_a.trades import split_custom_order

    print("\n[流程1] 工艺AI共创 + C2M 柔性定制")
    m = OrderMachine(order_id="DEMO-A1")
    m.transition("pay", actor="buyer", amount=1280.0, note="支付定金")
    m.transition("make_work_order", actor="designer", note="生成工艺单")
    m.transition("dispatch", actor="workshop", note="派单到匠人工坊")
    m.transition("qc_pass", actor="qc", note="品控通过")
    m.transition("ship", actor="logistics", note="发货")
    m.transition("settle", actor="platform", note="结算分成")
    summary = m.ledger_summary()
    print(f"  状态: {summary['final_state']}  台账事件数: {len(summary['timeline'])}")
    mf = ManufacturabilityAssessor("jewelry").evaluate(
        {"material": "18K金", "dimensions": {"min_width_mm": 0.5}}
    )
    print(f"  可制造性评估: {mf['verdict']} (L1={mf['l1']['decision']})")
    trade = split_custom_order(1280.0)
    print(f"  分成: 设计师 {trade['designer']} / 工坊 {trade['workshop']} / 平台 {trade['platform']}")


def demo_module_b() -> None:
    """主流程2：企业 AI 服务层（行业切换 + 出海询盘 CRM）。"""
    from modules.module_b.enterprise_service import EnterpriseService
    from modules.module_b.export_stack import ExportStack

    print("\n[流程2] 企业 AI 服务层（FDE）")
    for industry in ("jewelry", "wood"):
        svc = EnterpriseService(industry)
        s = svc.summary()
        print(f"  行业切换 -> {industry}: 六组件就绪 agent={s['agent']}")
        print(f"    KB 问答: {svc.kb_query('工艺 成本')['matches'][0]['title']}")

    stack = ExportStack()
    lead = stack.submit_inquiry("buyer@example.com", "I want a custom bracelet", source_lang="en")
    stack.follow_up(lead["lead_id"])
    rep = stack.seo_report()
    print(f"  出海三语站点: {', '.join(rep.keys())}  SEO 报告完成")
    print(f"  询盘 CRM: {lead['lead_id']} -> {stack.crm_summary()['total']} 条线索闭环")


def demo_module_c() -> None:
    """主流程3：文化 IP 双角色 + 授权矩阵 + 短剧样片落盘。"""
    from modules.module_c.characters import CharacterBook
    from modules.module_c.license import LicenseMatrix
    from modules.module_c.pipeline import PipelineMachine

    print("\n[流程3] 文化 IP 内容与授权管线")
    book = CharacterBook()
    roles = ", ".join(c["name"] for c in book.list_characters())
    print(f"  双角色: {roles}")
    matrix = LicenseMatrix()
    out = matrix.check("merchandise", "non_exclusive")
    print(f"  授权矩阵: 商品-非独占 -> {'允许' if out['allowed'] else '禁止'}")

    os.makedirs(SAMPLES_DIR, exist_ok=True)
    machine = PipelineMachine("EP-DEMO")
    machine.fire("submit")
    machine.fire("approve")
    machine.render()
    result = machine.publish(os.path.join(SAMPLES_DIR, "demo_ep001.mp4"))
    print(f"  短剧样片落盘: {result['output_path']}  (状态 {machine.state})")


def demo_module_d() -> None:
    """主流程4：设计共创赛事包（三赛道 / 打分 / 门禁 / KPI）。"""
    from modules.module_d.contest import ContestManager

    print("\n[流程4] 设计共创赛事包")
    cm = ContestManager()
    sub = cm.submit("jewelry", "选手甲", "缠枝莲手镯")
    cm.score(sub["id"], "评委A", 88.0)
    cm.score(sub["id"], "评委B", 92.0)
    gate = cm.prototype_gate(sub["id"], manufacturable=True)
    dash = cm.kpi_dashboard()
    print(f"  提交 {sub['id']} -> 均分 {cm.final_score(sub['id'])} -> 门禁 {gate['gate']}")
    print(f"  KPI 看板: 总提交 {dash['total_submissions']} 赛道 {list(dash['by_track'].keys())}")


def main() -> int:
    parser = argparse.ArgumentParser(description="四条主流程演示")
    parser.add_argument("--no-samples", action="store_true", help="跳过短剧样片落盘")
    args = parser.parse_args()

    demo_module_a()
    demo_module_b()
    demo_module_c()
    demo_module_d()
    print("\n演示完成（四条主流程全部可点通）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
