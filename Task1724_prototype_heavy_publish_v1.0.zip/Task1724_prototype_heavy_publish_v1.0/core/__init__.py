"""prototype_heavy 核心包：自研 JSON/YAML 规则引擎与通用工具。"""
