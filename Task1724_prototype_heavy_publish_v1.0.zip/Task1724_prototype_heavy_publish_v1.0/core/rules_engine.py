# -*- coding: utf-8 -*-
"""自研 JSON/YAML 规则引擎（proposal 2.5 章承诺）。

设计目标：
- 规则以 JSON / YAML 文件驱动，非程序员可编辑并生效；
- 支持字段值、范围、枚举、必填、自定义谓词等多种条件；
- 返回结构化命中结果（rule_id / 决策 / 理由），供上层业务复用；
- 不依赖任何第三方库：YAML 用内置子集解析（缩进映射），JSON 用标准库。

规则文件格式（JSON 或 YAML 均可）:
{
  "rules": [
    {"id": "J-001", "when": {"material": "18K金", "stone": "钻石"}, "then": {"decision": "pass", "reason": "..."}},
    {"id": "J-002", "when": {"min_width": 0.8}, "then": {"decision": "warn", "reason": "..."}}
  ]
}
"""
import json
import os
import re

RULE_EXTENSIONS = (".json", ".yaml", ".yml")


def _parse_yaml_simple(text: str) -> dict:
    """极简 YAML block 解析器：支持顶层 key/value、列表项（- key: value）与嵌套映射。

    仅覆盖本仓库规则文件的子集语法（缩进 2/4 空格）；注释 # 开头。
    """
    raw_lines = []
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        raw_lines.append((len(raw) - len(raw.lstrip(" ")), stripped))

    pos = 0

    def parse_block(indent: int):
        nonlocal pos
        result = {}
        while pos < len(raw_lines):
            i, s = raw_lines[pos]
            if i < indent:
                break
            if s.startswith("- "):
                # 列表块
                items = []
                while pos < len(raw_lines) and raw_lines[pos][1].startswith("- "):
                    i2, s2 = raw_lines[pos]
                    rest = s2[2:].strip()
                    item = {}
                    if ":" in rest:
                        k, _, v = rest.partition(":")
                        item[k.strip().strip("\"'")] = _convert_scalar(v.strip())
                    pos += 1
                    if pos < len(raw_lines) and raw_lines[pos][0] > i2 and not raw_lines[pos][1].startswith("- "):
                        sub = parse_block(raw_lines[pos][0])
                        if sub is not None and isinstance(sub, dict):
                            item.update(sub)
                        elif sub is not None:
                            item.setdefault("value", sub)
                    items.append(item)
                result["__list__"] = items
                continue
            k, _, v = s.partition(":")
            k = k.strip().strip("\"'")
            v = v.strip()
            if v in ("", "{", "}"):
                pos += 1
                if pos < len(raw_lines) and raw_lines[pos][0] > i:
                    sub = parse_block(raw_lines[pos][0])
                    result[k] = sub if sub is not None else {}
                else:
                    result[k] = {}
                continue
            result[k] = _convert_scalar(v)
            pos += 1
        if "__list__" in result and set(result.keys()) == {"__list__"}:
            return result["__list__"]
        if "__list__" in result:
            result["__items__"] = result.pop("__list__")
        return result

    data = parse_block(0)
    if isinstance(data, list):
        return {"rules": data}
    if "__items__" in data:
        data["rules"] = data.pop("__items__")
    return data


def _convert_scalar(val: str):
    if val.lower() == "true":
        return True
    if val.lower() == "false":
        return False
    import re

    if re.fullmatch(r"-?\d+(\.\d+)?", val):
        return float(val) if "." in val else int(val)
    return val.strip("\"'")


def _coerce_number(value):
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return value
    try:
        return float(value)
    except (TypeError, ValueError):
        return value


def _match_condition(condition: dict, ctx: dict) -> bool:
    """判断单个条件是否满足。condition 形如 {"field": "material", "op": "eq", "value": "18K金"}。"""
    field = condition.get("field")
    op = condition.get("op", "eq")
    expected = condition.get("value")
    actual = ctx.get(field)
    if op == "eq":
        return actual == expected
    if op == "ne":
        return actual != expected
    if op == "in":
        return actual in (expected or [])
    if op == "not_in":
        return actual not in (expected or [])
    if op == "contains":
        return expected in (actual or "")
    if op == "has":
        return bool(actual)
    if op == "missing":
        return field not in ctx or actual in (None, "")
    if op in ("gt", "gte", "lt", "lte"):
        a = _coerce_number(actual)
        e = _coerce_number(expected)
        if a is None or e is None:
            return False
        if op == "gt":
            return a > e
        if op == "gte":
            return a >= e
        if op == "lt":
            return a < e
        if op == "lte":
            return a <= e
    if op == "regex":
        return bool(re.search(str(expected), str(actual or "")))
    raise ValueError(f"未知操作符: {op}")


class RuleEngine:
    """JSON/YAML 驱动的规则引擎。"""

    def __init__(self, rules: list | None = None):
        self.rules = rules or []

    # ---------- 加载 ----------
    @classmethod
    def from_file(cls, path: str) -> "RuleEngine":
        if not os.path.exists(path):
            raise FileNotFoundError(f"规则文件不存在: {path}")
        ext = os.path.splitext(path)[1].lower()
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        if ext == ".json":
            data = json.loads(text)
        elif ext in (".yaml", ".yml"):
            data = _parse_yaml_simple(text)
        else:
            raise ValueError(f"不支持的规则格式: {ext}")
        rules = data.get("rules", data if isinstance(data, list) else [])
        return cls(rules)

    def add_rule(self, rule: dict) -> None:
        self.rules.append(rule)

    # ---------- 匹配 ----------
    def evaluate(self, ctx: dict, industry: str | None = None):
        """对上下文逐条求值。返回命中列表 [{rule_id, decision, reason, weight}]。

        rule.when 支持:
          - 单条件 {"field":..., "op":..., "value":...}
          - 多条件列表 [cond1, cond2, ...]（AND 语义）
        """
        hits = []
        for rule in self.rules:
            if industry and rule.get("industry") and rule["industry"] != industry:
                continue
            when = rule.get("when", {})
            matched = False
            if isinstance(when, list):
                matched = all(_match_condition(c, ctx) for c in when if isinstance(c, dict))
            elif isinstance(when, dict):
                # 兼容简写: {"material": "18K金"} 等价 {field: material, op: eq, value: 18K金}
                if "field" in when:
                    matched = _match_condition(when, ctx)
                else:
                    matched = all(
                        _match_condition({"field": k, "op": "eq", "value": v}, ctx)
                        for k, v in when.items()
                    )
            if matched:
                hits.append(
                    {
                        "rule_id": rule.get("id", "?") or "?",
                        "decision": rule.get("then", {}).get("decision", "pass"),
                        "reason": rule.get("then", {}).get("reason", ""),
                        "weight": rule.get("weight", 1),
                    }
                )
        return hits

    def decide(self, ctx: dict, industry: str | None = None) -> dict:
        """综合决策：所有命中规则中取最高严重度（block > warn > pass），返回结构化结果。"""
        hits = self.evaluate(ctx, industry)
        severity = {"pass": 0, "warn": 1, "block": 2}
        if not hits:
            return {"decision": "pass", "reasons": ["未命中任何规则"], "hits": [], "suggestions": []}
        top = max(hits, key=lambda h: severity.get(h["decision"], 0))
        warnings = [h for h in hits if h["decision"] == "warn"]
        return {
            "decision": top["decision"],
            "reasons": [h["reason"] for h in hits if h["reason"]],
            "hits": hits,
            "suggestions": [h["reason"] for h in warnings],
        }


class YamlRuleEngine(RuleEngine):
    """YAML 规则引擎（别名，语义一致）。"""

    @classmethod
    def from_file(cls, path: str) -> "RuleEngine":
        return super().from_file(path)
