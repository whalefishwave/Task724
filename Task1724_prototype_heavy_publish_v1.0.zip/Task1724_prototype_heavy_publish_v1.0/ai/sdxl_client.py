# -*- coding: utf-8 -*-
"""AI 图像层：Stable Diffusion SDXL / ComfyUI 集成接口 + 离线 mock 降级。

承诺（proposal 2.5 章）：代码提供 SDXL/ComfyUI 集成接口；测试/无 GPU 环境走 mock 降级，
预生成合成样例，保证不依赖重型推理。
"""
from __future__ import annotations

import base64
import os
import uuid


class SDXLError(Exception):
    """SDXL 生成错误。"""


class SDXLClient:
    """SDXL/ComfyUI 客户端。

    mode:
      - "comfy": 通过 ComfyUI HTTP API 提交工作流（生产）；
      - "api": 通过商用文生图 API（生产备选）；
      - "mock": 离线生成合成 SVG 占位图（测试/降级，默认）。
    """

    def __init__(self, mode: str = "mock", endpoint: str = "http://127.0.0.1:8188", api_key: str = ""):
        if mode not in ("comfy", "api", "mock"):
            raise SDXLError(f"未知模式: {mode}")
        self.mode = mode
        self.endpoint = endpoint
        self.api_key = api_key

    def generate(self, prompt: str, negative_prompt: str = "", output_dir: str = "", size: str = "1024x1024", seed: int = 42) -> dict:
        if self.mode == "mock":
            return self._mock_generate(prompt, output_dir, size, seed)
        if self.mode == "comfy":
            return self._comfy_generate(prompt, negative_prompt, output_dir, size, seed)
        return self._api_generate(prompt, negative_prompt, output_dir, size, seed)

    # ---------- ComfyUI HTTP API ----------
    def _comfy_generate(self, prompt, negative_prompt, output_dir, size, seed) -> dict:
        # 生产接入：向 ComfyUI 提交 SDXL 工作流 JSON，轮询 /history 取图。
        # 为保持离线可测，这里给出真实调用骨架；未配置 endpoint 时报错提示走 mock。
        if not self.endpoint:
            raise SDXLError("ComfyUI endpoint 未配置")
        import urllib.request

        workflow = {
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "size": size,
            "seed": seed,
        }
        req = urllib.request.Request(
            f"{self.endpoint}/prompt",
            data=json_dumps(workflow).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8")
        return {"path": "", "mode": "comfy", "response": body[:200]}

    # ---------- 商用 API ----------
    def _api_generate(self, prompt, negative_prompt, output_dir, size, seed) -> dict:
        if not self.api_key:
            raise SDXLError("api_key 未配置")
        # 生产：调用商用文生图 API（如第三方），此处保留接口骨架
        return {"path": "", "mode": "api", "note": "商用 API 调用骨架"}

    # ---------- 离线 mock ----------
    def _mock_generate(self, prompt, output_dir, size, seed) -> dict:
        os.makedirs(output_dir, exist_ok=True)
        name = f"mock_{seed}_{uuid.uuid4().hex[:6]}.svg"
        path = os.path.join(output_dir, name)
        w, h = size.split("x")
        svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'
            f"<rect width='100%' height='100%' fill='#2b3a55'/>"
            f"<text x='50%' y='46%' fill='#e8c98a' font-size='28' text-anchor='middle' "
            f"font-family='sans-serif'>AI Concept (SDXL mock)</text>"
            f"<text x='50%' y='58%' fill='#cfd8dc' font-size='16' text-anchor='middle' "
            f"font-family='sans-serif'>{prompt[:60]}</text>"
            f"<text x='50%' y='94%' fill='#90a4ae' font-size='12' text-anchor='middle'>"
            f"ai_generated=true | seed={seed} | mock</text>"
            f"</svg>"
        )
        with open(path, "w", encoding="utf-8") as f:
            f.write(svg)
        return {"path": path, "mode": "mock", "prompt": prompt, "size": size}


def json_dumps(obj) -> str:
    import json

    return json.dumps(obj, ensure_ascii=False)
