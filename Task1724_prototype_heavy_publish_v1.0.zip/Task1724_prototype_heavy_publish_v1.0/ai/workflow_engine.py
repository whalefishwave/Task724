# -*- coding: utf-8 -*-
"""工作流编排引擎（LangGraph 风格，自研轻量实现）。

proposal 2.5 承诺"LangGraph 或 n8n"。本仓库提供：
- 自研 graph 编排引擎（节点/边/状态/条件路由），语义对齐 LangGraph；
- 生产可平滑替换为 LangGraph / n8n 服务（接口一致）。
"""
from __future__ import annotations

from dataclasses import dataclass, field


class WorkflowError(Exception):
    """工作流编排错误。"""


@dataclass
class WorkflowNode:
    name: str
    fn: callable
    routes: dict[str, str] = field(default_factory=dict)  # 条件路由: {condition_value: next_node}

    def run(self, state: dict) -> dict:
        return self.fn(state)


class WorkflowEngine:
    """有向图工作流引擎。支持顺序执行（按注册顺序）与条件路由（_next / routes）。"""

    def __init__(self, name: str = "workflow"):
        self.name = name
        self.nodes: dict[str, WorkflowNode] = {}
        self.order: list[str] = []
        self.start = ""

    def add_node(self, name: str, fn: callable, routes: dict[str, str] | None = None) -> "WorkflowEngine":
        self.nodes[name] = WorkflowNode(name, fn, routes or {})
        if name not in self.order:
            self.order.append(name)
        if not self.start:
            self.start = name
        return self

    def _default_next(self, index: int) -> str:
        """注册顺序中的下一个节点（线性编排默认流）。"""
        if index + 1 < len(self.order):
            return self.order[index + 1]
        return ""

    def compile(self) -> None:
        if not self.nodes:
            raise WorkflowError("工作流为空")
        # 校验路由目标存在
        for node in self.nodes.values():
            for target in node.routes.values():
                if target not in self.nodes:
                    raise WorkflowError(f"节点 {node.name} 路由到不存在的节点 {target}")

    def run(self, initial: dict | None = None) -> dict:
        self.compile()
        state = dict(initial or {})
        trace = []
        current = self.start
        from_branch = False
        guard = 0
        while current:
            guard += 1
            if guard > max(len(self.nodes) * 20, 50):
                raise WorkflowError("检测到循环，终止执行")
            node = self.nodes[current]
            index = self.order.index(current)
            out = node.run(state)
            if not isinstance(out, dict):
                out = {"_output": out}
            state.update(out)
            trace.append(current)
            branch = out.get("_next")
            if branch:
                if branch not in self.nodes:
                    raise WorkflowError(f"节点 {current} 指定了不存在的下一节点 {branch}")
                current = branch
                from_branch = True
            elif current in node.routes:
                current = node.routes[current]
                from_branch = True
            elif not from_branch:
                current = self._default_next(index)
                from_branch = False
            else:
                # 分支到达的末端节点：不再默认续走注册顺序
                current = ""
        return {"workflow": self.name, "trace": trace, "final_state": state}
