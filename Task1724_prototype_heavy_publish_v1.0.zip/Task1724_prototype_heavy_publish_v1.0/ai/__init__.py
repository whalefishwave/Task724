"""AI 层：SDXL/ComfyUI、LLM 双轨、工作流编排。"""
