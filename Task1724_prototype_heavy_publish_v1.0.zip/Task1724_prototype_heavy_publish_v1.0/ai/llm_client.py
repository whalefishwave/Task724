# -*- coding: utf-8 -*-
"""AI 语言层：开源 LLM 本地 / API 双轨 + mock 降级。

- local: 本地开源模型（如 Qwen）推理接口（骨架）；
- api: 商用 API 按量（骨架，需要 api_key）；
- mock: 确定性模板响应（默认，保证测试离线可跑）。
"""
from __future__ import annotations


class LLMError(Exception):
    """LLM 调用错误。"""


class LLMClient:
    """语言模型客户端（双轨）。"""

    def __init__(self, mode: str = "mock", endpoint: str = "", api_key: str = ""):
        if mode not in ("local", "api", "mock"):
            raise LLMError(f"未知模式: {mode}")
        self.mode = mode
        self.endpoint = endpoint
        self.api_key = api_key

    def chat(self, prompt: str) -> dict:
        if self.mode == "mock":
            return {"content": f"[mock-llm] 已受理：{prompt[:80]}", "mode": "mock"}
        if self.mode == "local":
            # 生产：调用本地开源 LLM 的 HTTP 服务（如 vLLM / llama.cpp server）
            if not self.endpoint:
                raise LLMError("本地 LLM endpoint 未配置")
            return {"content": "(local-llm response)", "mode": "local"}
        if self.mode == "api":
            if not self.api_key:
                raise LLMError("api_key 未配置")
            return {"content": "(api-llm response)", "mode": "api"}
        raise LLMError("未知模式")

    def complete_json(self, prompt: str) -> dict:
        """请求 JSON 结构化输出；mock 模式返回空 dict（由调用方降级）。"""
        if self.mode == "mock":
            return {}
        raw = self.chat(prompt)
        return {"content": raw.get("content", "")}
