# ClawHunt #1724 应标原型（重技术栈版 prototype_heavy）

# ClawHunt #1724 Bid Prototype (Full-Stack Edition: prototype_heavy)

> 独立于纯标准库轻量版 `prototype` 的全新仓库，技术栈按提案 2.5 章承诺：**FastAPI + Uvicorn / React + Vite + Streamlit / PostgreSQL 16 + pgvector / SDXL(ComfyUI 接口 + mock 降级) / 本地或 API 双轨 LLM / 自研 JSON-YAML 规则引擎 + 工作流编排 / pytest + Playwright / Docker Compose + 三平台一键脚本**。  
> A standalone repository independent of the pure-standard-library lightweight edition `prototype`. The technology stack follows the commitments in section 2.5 of the proposal: **FastAPI + Uvicorn / React + Vite + Streamlit / PostgreSQL 16 + pgvector / SDXL (ComfyUI interface + mock fallback) / dual-track local-or-API LLM / in-house JSON-YAML rule engine + workflow orchestration / pytest + Playwright / Docker Compose + one-click scripts for three platforms**.

## 目录结构

## Directory Structure

```
prototype_heavy/
├── app/            # FastAPI 应用层（uvicorn 入口 app.main:app）
├── web/            # React + Vite 前端骨架（npm run dev 接 /api 代理）
├── ai/             # SDXL/ComfyUI 客户端(mock 降级)、LLM 双轨客户端、工作流引擎
├── core/           # 自研 JSON/YAML 规则引擎 + 演示规则
├── modules/
│   ├── module_a/   # 工艺AI共创 + C2M（授权强校验/可制造性/订单状态机/三类交易）
│   ├── module_b/   # 六产业共享企业AI服务层 FDE（六组件/行业切换/出海栈/一企一档）
│   ├── module_c/   # 文化IP管线（双角色/视觉资产/短剧工作流/授权矩阵/合规标识）
│   └── module_d/   # 设计共创赛事包（三赛道/评审/打样门禁/KPI看板）
├── tests/          # pytest 套件（一条命令全绿）
├── scripts/        # init_check / demo / verify 自检三件套
├── deploy/         # Docker Compose + 三平台一键安装脚本
└── output/         # 自检报告与样片产物
```

## 快速开始

## Quick Start

```bash
# Windows
powershell -ExecutionPolicy Bypass -File deploy\install_windows.ps1
# Linux / macOS
bash deploy/install_linux.sh
bash deploy/install_macos.sh
```

## 一键部署（Docker Compose / 四平台一键脚本）

## One-Click Deployment (Docker Compose / Four-Platform One-Click Scripts)

`deploy/` 提供容器化一键部署，`docker-compose.yml` 定义三服务：  
`deploy/` provides containerized one-click deployment; `docker-compose.yml` defines three services:

| 服务 / Service | 镜像 / Image                              | 端口 / Port | 说明 / Notes                                                                          |
| ------------ | --------------------------------------- | --------- | ----------------------------------------------------------------------------------- |
| `db`         | `pgvector/pgvector:pg16`                | 5432      | PostgreSQL 16 + pgvector，卷 `pgdata` 持久化，healthcheck 就绪后才启动 app                      |
| `app`        | `python:3.11-slim`（`deploy/Dockerfile`） | 8000      | FastAPI（`uvicorn app.main:app`），`output` 卷挂载 `../output:/app/output`，样片更新无需重建镜像     |
| `web`        | `node:22-alpine`                        | 5173      | React + Vite 前端（`npm install && npm run dev --host 0.0.0.0`），代理 `/api` 到 `app:8000` |

| `db` | `pgvector/pgvector:pg16` | 5432 | PostgreSQL 16 + pgvector, persistent volume `pgdata`, app starts only after db healthcheck passes |  
| `app` | `python:3.11-slim` (`deploy/Dockerfile`) | 8000 | FastAPI (`uvicorn app.main:app`), volume-mounted `output` at `../output:/app/output`, sample updates need no image rebuild |  
| `web` | `node:22-alpine` | 5173 | React + Vite frontend (`npm install && npm run dev --host 0.0.0.0`), proxying `/api` to `app:8000` |

四平台一键安装脚本（均幂等、可重复运行；完整部署见 Ubuntu 专版）：  
Four-platform one-click install scripts (idempotent, safe to re-run; full deployment via the Ubuntu-specific script):

| 平台 / Platform                                                                                      | 一键命令 / One-click command                                              | 形态 / Mode                                        |
| -------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- | ------------------------------------------------ |
| Windows                                                                                            | `powershell -ExecutionPolicy Bypass -File deploy\install_windows.ps1` | 本机开发自检 / local dev self-check                    |
| Linux（通用，含 Ubuntu / Debian / CentOS / Fedora） / Linux (generic: Ubuntu / Debian / CentOS / Fedora) | `bash deploy/install_linux.sh`                                        | 本机开发自检 / local dev self-check                    |
| macOS                                                                                              | `bash deploy/install_macos.sh`                                        | 本机开发自检 / local dev self-check                    |
| Ubuntu（专版，含干净机器） / Ubuntu (dedicated, incl. clean machine)                                         | `sudo bash deploy/install_ubuntu_onekey.sh`                           | 完整部署（装 npm/docker/compose 并起全栈）/ full deployment |

平台说明：  
Platform notes:

- Windows / Linux / macOS 三平台脚本为本机开发自检形态：创建 `.venv`、`pip install -r requirements.txt`、优先用 Docker 启动 PG16+pgvector（无 Docker 时测试降级 sqlite/file 后端）、依次执行 `init_check / demo / pytest / verify` 自检四连。  
  The Windows / Linux / macOS scripts are local dev self-check mode: create `.venv`, `pip install -r requirements.txt`, start PG16+pgvector via Docker when available (tests fall back to sqlite/file backends otherwise), then run `init_check / demo / pytest / verify` in sequence.
- Ubuntu 专版为完整一键部署：自动检测并安装 Node.js 22 LTS(npm) / docker / docker compose，`npm install` 前端依赖，`docker compose up -d --build` 启动 `db + app + web`，最后打印访问地址 `http://<服务器IP>:5173`；非 root 时自动 sudo，docker 组权限不足时自动回退 `sudo docker compose`。  
  The Ubuntu-specific script is full one-click deployment: auto-detects and installs Node.js 22 LTS (npm) / docker / docker compose, runs `npm install` for frontend deps, `docker compose up -d --build` to start `db + app + web`, and prints the access URL `http://<server-IP>:5173`; auto-sudo for non-root users, falls back to `sudo docker compose` when docker-group permission is not refreshed.

手动执行 Docker Compose：  
Or run Docker Compose manually:

```bash
cd deploy
docker compose up -d --build    # 服务 db / app / web；端口 5432:5432、8000:8000、5173:5173
docker compose ps
docker compose logs -f app
docker compose down
```

## 自检命令（全部真实存在、可运行）

## Self-Check Commands (all real and runnable)

```bash
python scripts/init_check.py        # 结构/依赖/pytest 冒烟
python scripts/demo.py              # 四条主流程演示
python -m pytest tests -q           # 核心逻辑单测（≥40 用例全绿）
python scripts/verify.py            # G1-G10 逐条验收自检，输出 output/VERIFICATION_heavy.md
```

## 数据库与 AI 降级说明

## Database and AI Fallback Notes

- 生产：PostgreSQL 16 + pgvector（`deploy/docker-compose.yml` 一键起）；
  - Production: PostgreSQL 16 + pgvector (started with one command via `deploy/docker-compose.yml`);
- 本机测试：无 Docker/PG 时经环境变量切换 sqlite/file 后端，pytest 不依赖数据库；
  - Local testing: when Docker/PG is unavailable, switch to the sqlite/file backend via environment variables; pytest does not depend on a database;
- AI 图像：SDXL/ComfyUI 提供集成接口（`ai/sdxl_client.py`），`SDXL_MODE=mock` 离线降级；
  - AI imaging: SDXL/ComfyUI provide an integration interface (`ai/sdxl_client.py`); `SDXL_MODE=mock` degrades to offline mode;
- AI 语言：本地/API 双轨（`ai/llm_client.py`），`LLM_MODE=mock` 离线降级。
  - AI language: dual local/API tracks (`ai/llm_client.py`); `LLM_MODE=mock` degrades to offline mode.
