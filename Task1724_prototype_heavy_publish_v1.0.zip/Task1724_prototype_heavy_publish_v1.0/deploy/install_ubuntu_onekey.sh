#!/usr/bin/env bash
# ============================================================
# ClawHunt #1724 · 重技术栈版 Ubuntu 一键安装启动脚本
# 适用仓库目录：prototype_heavy（源码演示版，含私有样片）
#              prototype_heavy_publish（防白嫖发布版，样片已剔除）
# 功能：自动检测并安装 npm / docker / docker compose，
#       随后安装前端依赖（npm install）并启动全部服务（docker compose up）
# 用法：chmod +x install_ubuntu_onekey.sh && ./install_ubuntu_onekey.sh
# 说明：脚本幂等，可重复运行；非 root 用户涉及 sudo 时自动请求密码
# ============================================================
set -euo pipefail

# ---------- 颜色输出（用于 [OK]/[SKIP]/[FAIL] 状态） ----------
RED=$'\033[0;31m'
GREEN=$'\033[0;32m'
YELLOW=$'\033[0;33m'
NC=$'\033[0m'

ok()   { echo -e "${GREEN}[OK]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $*"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; }

# ---------- 标题与仓库目录识别 ----------
echo "=============================================="
echo "  ClawHunt #1724 · Ubuntu 一键安装启动脚本"
echo "=============================================="

# deploy/ 的上级目录即仓库根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_NAME="$(basename "${REPO_DIR}")"

case "${REPO_NAME}" in
  prototype_heavy)
    echo "识别仓库目录：${REPO_NAME}（源码演示版，含私有样片，供买方演示）"
    ;;
  prototype_heavy_publish)
    echo "识别仓库目录：${REPO_NAME}（防白嫖发布版，样片已剔除，对外交付形态）"
    ;;
  *)
    echo "警告：未识别到标准仓库目录名（当前：${REPO_NAME}），脚本仍将按通用流程继续。"
    ;;
esac

# 非 root 运行时提示后续将需要 sudo 密码
if [ "$(id -u)" -ne 0 ]; then
  echo "检测到非 root 用户，需要 sudo 的步骤将自动请求密码。"
fi

# ---------- 前置工具检查 ----------
if ! command -v curl >/dev/null 2>&1; then
  fail "缺少 curl，请先手动执行：sudo apt-get update && sudo apt-get install -y curl"
  exit 1
fi

# ---------- 依赖 1：npm（Node.js 22 LTS） ----------
if command -v npm >/dev/null 2>&1; then
  skip "npm 已存在：node $(node -v 2>/dev/null || echo '?') / npm $(npm -v 2>/dev/null || echo '?')"
else
  echo "检测到 npm 缺失，开始安装 Node.js 22 LTS（NodeSource 官方源）..."
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
  if command -v npm >/dev/null 2>&1; then
    ok "npm 安装完成：node $(node -v) / npm $(npm -v)"
  else
    fail "npm 安装后仍不可用，请手动安装 Node.js 22 LTS。"
    exit 1
  fi
fi

# ---------- 依赖 2：docker ----------
if command -v docker >/dev/null 2>&1; then
  skip "docker 已存在：$(docker --version 2>/dev/null || echo '?')"
else
  echo "检测到 docker 缺失，使用官方脚本安装..."
  curl -fsSL https://get.docker.com | sudo sh
  sudo systemctl enable --now docker
  if command -v docker >/dev/null 2>&1; then
    ok "docker 安装完成：$(docker --version)"
  else
    fail "docker 安装失败，请手动安装后重试。"
    exit 1
  fi
fi

# ---------- 依赖 3：docker compose ----------
DOCKER_COMPOSE="docker compose"          # 默认使用 v2 插件形式
if docker compose version >/dev/null 2>&1; then
  skip "docker compose 已存在：$(docker compose version)"
elif docker-compose version >/dev/null 2>&1; then
  DOCKER_COMPOSE="docker-compose"        # 兼容 v1 独立命令
  skip "docker-compose（v1）已存在：$(docker-compose version)"
else
  echo "检测到 docker compose 缺失，先尝试安装官方 compose 插件..."
  if sudo apt-get install -y docker-compose-plugin; then
    :
  else
    echo "apt 插件安装失败，改为安装独立二进制 docker compose v2 ..."
    sudo mkdir -p /usr/local/lib/docker/cli-plugins
    sudo curl -fsSL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m)" -o /usr/local/lib/docker/cli-plugins/docker-compose
    sudo chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
  fi
  if docker compose version >/dev/null 2>&1; then
    ok "docker compose 安装完成：$(docker compose version)"
  else
    fail "docker compose 安装失败，请手动安装后重试。"
    exit 1
  fi
fi

# ---------- docker 组检查 ----------
if id -nG | grep -qw docker; then
  skip "当前用户已在 docker 组。"
else
  echo "当前用户不在 docker 组，执行：sudo usermod -aG docker ${USER}"
  sudo usermod -aG docker "$USER"
  echo "已加入 docker 组，需重新登录（或执行 newgrp docker）后普通权限的 docker 才生效。"
  echo "脚本将继续尝试直接调用 docker compose；若失败会自动回退到 sudo docker compose。"
fi

# ---------- 部署流程 ----------
echo "----------------------------------------------"
echo "开始部署：清理并安装前端依赖，随后启动服务"
echo "----------------------------------------------"

# 4. 前端依赖（cd 到仓库 web 目录）
cd "${REPO_DIR}/web"
echo "清理旧 node_modules 并执行 npm install ..."
rm -rf node_modules
npm install
ok "前端依赖安装完成"

# 5. 启动服务（cd 到仓库 deploy 目录）
cd "${REPO_DIR}/deploy"

compose_up() {
  if [ "${DOCKER_COMPOSE}" = "docker-compose" ]; then
    docker-compose up -d --build
  else
    docker compose up -d --build
  fi
}

if compose_up 2>/dev/null; then
  ok "docker compose up 成功"
else
  echo "compose 调用失败，尝试使用 sudo 重试一次（常见于 docker 组权限未刷新）..."
  if sudo docker compose up -d --build; then
    ok "sudo docker compose up 成功"
  else
    fail "docker compose up 失败，请检查 docker 服务状态：sudo systemctl status docker"
    exit 1
  fi
fi

# ---------- 完成与访问地址 ----------
echo "=============================================="
echo "部署完成！"
echo "访问地址：http://<服务器IP>:5173"
echo "查询服务器 IP 命令：hostname -I"
echo "（若 docker 权限提示，请重新登录后再运行一次本脚本即可）"
echo "=============================================="
ok "一键安装启动流程结束"
