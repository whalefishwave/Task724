#!/usr/bin/env bash
# ClawHunt #1724 prototype_heavy —— Linux 一键安装脚本
# 用法: bash deploy/install_linux.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "[1/4] 创建虚拟环境"
python3 -m venv "$ROOT/.venv" || true

echo "[2/4] 安装依赖"
"$ROOT/.venv/bin/python" -m pip install --upgrade pip
"$ROOT/.venv/bin/python" -m pip install -r "$ROOT/requirements.txt"

echo "[3/4] 数据库：优先 Docker 起 PG16+pgvector（无 Docker 时测试降级 sqlite/file）"
if command -v docker >/dev/null 2>&1; then
    docker compose -f "$ROOT/deploy/docker-compose.yml" up -d db
else
    echo "    未检测到 Docker，测试将使用 sqlite/file 降级后端（生产仍按 PG16+pgvector 配置）"
fi

echo "[4/4] 自检：init_check / demo / pytest / verify"
"$ROOT/.venv/bin/python" "$ROOT/scripts/init_check.py"
"$ROOT/.venv/bin/python" "$ROOT/scripts/demo.py"
"$ROOT/.venv/bin/python" -m pytest "$ROOT/tests" -q
"$ROOT/.venv/bin/python" "$ROOT/scripts/verify.py"

echo "安装完成。启动后端: .venv/bin/python -m uvicorn app.main:app --port 8000"
