# ClawHunt #1724 prototype_heavy —— Windows 一键安装脚本
# 用法: powershell -ExecutionPolicy Bypass -File deploy\install_windows.ps1
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

Write-Host "[1/4] 创建虚拟环境"
if (-not (Test-Path "$Root\.venv")) { python -m venv "$Root\.venv" }

Write-Host "[2/4] 安装依赖"
& "$Root\.venv\Scripts\python.exe" -m pip install --upgrade pip
& "$Root\.venv\Scripts\python.exe" -m pip install -r "$Root\requirements.txt"

Write-Host "[3/4] 数据库：优先 Docker 起 PG16+pgvector（无 Docker 时测试降级 sqlite/file）"
if (Get-Command docker -ErrorAction SilentlyContinue) {
    docker compose -f "$Root\deploy\docker-compose.yml" up -d db
} else {
    Write-Host "    未检测到 Docker，测试将使用 sqlite/file 降级后端（生产仍按 PG16+pgvector 配置）"
}

Write-Host "[4/4] 自检：init_check / demo / pytest / verify"
& "$Root\.venv\Scripts\python.exe" "$Root\scripts\init_check.py"
& "$Root\.venv\Scripts\python.exe" "$Root\scripts\demo.py"
& "$Root\.venv\Scripts\python.exe" -m pytest "$Root\tests" -q
& "$Root\.venv\Scripts\python.exe" "$Root\scripts\verify.py"

Write-Host "安装完成。启动后端: .venv\Scripts\python -m uvicorn app.main:app --port 8000"
