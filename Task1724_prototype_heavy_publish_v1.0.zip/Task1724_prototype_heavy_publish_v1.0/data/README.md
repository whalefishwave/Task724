# 根级 data 目录

# Root-Level data Directory

本目录用于存放应标答辩演示用数据（跨模块公共示例数据、脱敏样例、合成数据清单）。  
实际模块数据位于 modules/*/data/ 下，均由合成生成并带 ai_generated / data_policy 标识。  
This directory stores data used for bid-defense demos (cross-module shared sample data, anonymized samples, and the synthetic data manifest).  
Actual module data lives under modules/*/data/; all of it is synthetically generated and carries ai_generated / data_policy labels.
