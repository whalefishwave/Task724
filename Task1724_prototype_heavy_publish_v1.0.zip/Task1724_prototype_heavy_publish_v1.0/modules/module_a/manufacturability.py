# -*- coding: utf-8 -*-
"""可制造性评估引擎（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含 L1 规则层 / L2 AI 层真实判定逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class ManufacturabilityError(Exception):
    """可制造性评估异常（占位桩保留异常类型）。"""


class ManufacturabilityAssessor:
    """可制造性评估器（发布版占位桩，保留签名）。"""

    def __init__(self, industry: str = "jewelry", llm=None, data_dir: str | None = None):
        self.industry = industry
        self.llm = llm

    def _norm_design(self, design: dict):
        """设计输入规范化（占位桩）。"""
        return {"_stub": True, "design": design, "note": NOTICE}

    def l1_rule_check(self, design: dict):
        """L1 规则层判定（占位桩）。"""
        return {"decision": "provided_after_award", "hits": [], "note": NOTICE}

    def l2_ai_check(self, design: dict, l1: dict):
        """L2 AI 层判定（占位桩）。"""
        return {"degraded": True, "decision": "provided_after_award", "note": NOTICE}

    def evaluate(self, design: dict, equipment_id: str | None = None):
        """双层可制造性判定（占位桩：返回占位结论）。"""
        return {
            "verdict": "provided_after_award",
            "l1": {"decision": "provided_after_award", "hits": [], "note": NOTICE},
            "l2": {"degraded": True, "decision": "provided_after_award", "note": NOTICE},
            "equipment_note": NOTICE,
            "note": NOTICE,
        }

    def run_cases(self, cases: list[dict]):
        """批量案例跑分（占位桩）。"""
        return {"total": len(cases), "passed": 0, "rate": 0.0, "note": NOTICE}


def _load_json(path: str):
    """读取 JSON（占位桩：返回空）。"""
    return {}


def load_cases(data_dir: str | None = None):
    """加载人工评审案例（占位桩：不返回真实案例数据）。"""
    return []
