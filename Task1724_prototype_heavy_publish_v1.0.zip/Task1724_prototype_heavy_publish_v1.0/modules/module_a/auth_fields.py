# -*- coding: utf-8 -*-
"""授权字段强校验（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含任何真实校验逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"

# 授权字段清单（结构公开，校验逻辑不随发布版分发）
REQUIRED_FIELDS = [
    "pattern_id", "source", "holder", "license_type", "scope", "expiry", "ai_generated",
]


class AuthValidationError(Exception):
    """授权字段校验异常（占位桩保留异常类型）。"""


class AuthRecord:
    """授权记录（发布版占位桩，保留签名）。"""

    @classmethod
    def from_dict(cls, data: dict, record_id: str | None = None):
        return {
            "ok": False,
            "record_id": record_id or "provided_after_award",
            "reason": NOTICE,
        }


def validate_auth_fields(data: dict):
    """校验授权字段（占位桩：拒绝并提示中标后提供）。"""
    return {"ok": False, "reason": NOTICE}


def register_auth_record(store: dict, data: dict, record_id: str | None = None):
    """登记授权记录（占位桩：不写入任何业务数据）。"""
    return {"ok": False, "record_id": record_id or "provided_after_award", "reason": NOTICE}
