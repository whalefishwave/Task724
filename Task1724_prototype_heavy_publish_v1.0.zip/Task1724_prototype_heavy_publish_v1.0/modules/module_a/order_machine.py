# -*- coding: utf-8 -*-
"""C2M 订单状态机（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含真实状态迁移与台账逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"

# 公开结构常量：状态名清单（迁移规则与台账逻辑不随发布版分发）
STATES = ["CREATED", "PAID", "PROCESSING", "DISPATCHED", "QC", "SHIPPED", "SETTLED"]
REFUND_STATES = ["REFUND_REQUESTED", "REFUNDED", "DISPUTE"]
ALL_STATES = STATES + REFUND_STATES
TRANSITIONS = {}  # 占位：真实迁移表核心实现将于中标后提供


class InvalidTransitionError(Exception):
    """非法状态迁移异常（占位桩保留异常类型）。"""


class OrderMachine:
    """C2M 柔性定制订单状态机（发布版占位桩，保留签名）。"""

    def __init__(self, order_id: str | None = None, initial: str = "CREATED", meta: dict | None = None):
        self.order_id = order_id or "provided_after_award"
        self.state = "PROVIDED_AFTER_AWARD"
        self.meta = meta or {}

    def _record(self, from_state, to_state, event, amount, actor, note=""):
        """台账记录（占位桩）。"""
        return {"_stub": True, "event": event, "note": NOTICE}

    def transition(self, event: str, actor: str = "system", amount: float = 0.0, note: str = ""):
        """状态迁移（占位桩：不执行真实迁移）。"""
        return {"ok": False, "state": self.state, "reason": NOTICE}

    def request_refund(self, amount: float, actor: str = "buyer"):
        return {"ok": False, "reason": NOTICE}

    def approve_refund(self, amount: float, actor: str = "platform"):
        return {"ok": False, "reason": NOTICE}

    def reject_refund(self, amount: float, actor: str = "platform"):
        return {"ok": False, "reason": NOTICE}

    def open_dispute(self, amount: float, actor: str = "buyer"):
        return {"ok": False, "reason": NOTICE}

    def resolve_dispute(self, amount: float, actor: str = "platform"):
        return {"ok": False, "reason": NOTICE}

    def ledger_summary(self):
        """台账摘要（占位桩）。"""
        return {"final_state": self.state, "timeline": [], "entries": [], "note": NOTICE}

    @classmethod
    def replay(cls, ledger: list[dict]):
        """按台账重放（占位桩）。"""
        return cls(order_id="replay_provided_after_award")
