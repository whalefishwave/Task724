# -*- coding: utf-8 -*-
"""工艺交易分成（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含真实分成比例与交易规则。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"

# 公开结构常量：交易类型清单（分成规则与费率不随发布版分发）
TRADE_TYPES = ("custom", "license", "royalty")


class TradeError(Exception):
    """交易异常（占位桩保留异常类型）。"""


class SplitRule:
    """分成规则（发布版占位桩，保留签名）。"""

    def __init__(self, shares=None, tiers=None, platform_fee_rate=0.0):
        self.shares = shares if shares is not None else {}
        self.tiers = tiers if tiers is not None else []
        self.platform_fee_rate = platform_fee_rate

    def apply(self, amount: float):
        return {"designer": "provided_after_award", "workshop": "provided_after_award", "platform": "provided_after_award", "note": NOTICE}


# 占位常量：默认分成/版税规则实例（真实比例不随发布版分发）
DEFAULT_CUSTOM_SPLIT = SplitRule(
    shares={"designer": None, "workshop": None, "platform": None},
    platform_fee_rate=None,
)
DEFAULT_LICENSE_SPLIT = SplitRule(shares={"licensor": None, "platform": None})
ROYALTY_TIERS = SplitRule(tiers=None, platform_fee_rate=None)


def create_trade(trade_type: str, amount: float, parties: dict | None = None):
    """创建交易（占位桩）。"""
    return {"trade_id": "provided_after_award", "type": trade_type, "amount": amount, "status": "PENDING_PROVIDED", "note": NOTICE}


def split_custom_order(amount: float):
    """C2M 定制订单分成（占位桩）。"""
    return {"designer": "provided_after_award", "workshop": "provided_after_award", "platform": "provided_after_award", "note": NOTICE}


def split_license_fee(amount: float):
    """授权费分成（占位桩）。"""
    return {"licensor": "provided_after_award", "platform": "provided_after_award", "note": NOTICE}


def split_royalty(amount: float):
    """版税分成（占位桩）。"""
    return {"ip_owner": "provided_after_award", "creator": "provided_after_award", "note": NOTICE}
