# -*- coding: utf-8 -*-
"""FDE 服务手册 / 一企一档（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含手册知识内容与档案脱敏真实逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class FdeHandbook:
    """FDE 服务手册（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None):
        self._data_dir = data_dir

    def get_section(self, key: str):
        """获取手册章节（占位桩）。"""
        return {"key": key, "content": NOTICE}

    def summary(self):
        """手册概览（占位桩）。"""
        return {"sections": 0, "note": NOTICE}


class EnterpriseProfile:
    """一企一档（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None, profile_path: str | None = None):
        self._data_dir = data_dir
        self._profile_path = profile_path

    def masked_view(self):
        """脱敏视图（占位桩）。"""
        return {"masked": True, "note": NOTICE}

    def summary(self):
        """档案概览（占位桩）。"""
        return {"masked": True, "note": NOTICE}
