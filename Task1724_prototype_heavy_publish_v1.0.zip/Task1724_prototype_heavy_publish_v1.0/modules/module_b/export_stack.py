# -*- coding: utf-8 -*-
"""出海三语站点 / SEO / 询盘 CRM（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含多语站点生成、SEO 与 CRM 闭环真实逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class ExportStackError(Exception):
    """出海栈异常（占位桩保留异常类型）。"""


class ExportStack:
    """出海三语站点 / SEO / CRM（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None, output_dir: str | None = None):
        self._data_dir = data_dir
        self._output_dir = output_dir

    def _load_site(self, lang: str):
        """加载站点内容（占位桩）。"""
        return {"lang": lang, "note": NOTICE}

    def generate_sites(self, output_dir: str | None = None):
        """生成三语站点（占位桩）。"""
        return {"generated": [], "note": NOTICE}

    def _render_site(self, lang: str, site: dict):
        """渲染站点（占位桩）。"""
        return {"lang": lang, "rendered": False, "note": NOTICE}

    def seo_metadata(self, lang: str):
        """SEO 元数据（占位桩）。"""
        return {"lang": lang, "title": "provided_after_award", "note": NOTICE}

    def seo_report(self):
        """SEO 报告（占位桩）。"""
        return {"zh": {"note": NOTICE}}

    def submit_inquiry(self, email: str, message: str, source_lang: str = "en"):
        """提交询盘（占位桩）。"""
        return {"lead_id": "provided_after_award", "email": email, "status": "PROVIDED_AFTER_AWARD", "note": NOTICE}

    def _assign_sales(self, lang: str):
        """分配销售（占位桩）。"""
        return {"sales": None, "note": NOTICE}

    def follow_up(self, lead_id: str, action: str = "contacted"):
        """线索跟进（占位桩）。"""
        return {"lead_id": lead_id, "status": "PROVIDED_AFTER_AWARD", "note": NOTICE}

    def crm_summary(self):
        """CRM 汇总（占位桩）。"""
        return {"total": 0, "by_status": {}, "note": NOTICE}
