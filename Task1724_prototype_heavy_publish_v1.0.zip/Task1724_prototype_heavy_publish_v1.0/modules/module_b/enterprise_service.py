# -*- coding: utf-8 -*-
"""六产业共享企业 AI 服务层 FDE（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含 KB 问答、Agent 编排、工作流与行业服务真实逻辑。
"""
from __future__ import annotations

from modules.module_b.component_registry import ComponentRegistry  # noqa: F401（占位桩类型引用）

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class EnterpriseServiceError(Exception):
    """企业 AI 服务层异常（占位桩保留异常类型）。"""


class EnterpriseService:
    """企业 AI 服务层（发布版占位桩，保留签名）。"""

    def __init__(self, industry: str, registry: ComponentRegistry | None = None, llm=None):
        self.industry = industry
        self.registry = registry
        self.llm = llm

    def kb_query(self, question: str, top_k: int = 3):
        """企业知识库问答（占位桩）。"""
        return {"matches": [{"title": "核心实现将于中标后提供（KB 问答）", "score": 0.0}], "note": NOTICE}

    def agent_run(self, task: str):
        """行业智能体任务（占位桩）。"""
        return {"task": task, "result": "provided_after_award", "note": NOTICE}

    def run_workflow(self, trigger: str, payload: dict | None = None):
        """服务工作流（占位桩）。"""
        return {"trigger": trigger, "trace": [], "note": NOTICE}

    def summary(self):
        """服务概览（占位桩）。"""
        return {"industry": self.industry, "components": [], "agent": "provided_after_award", "note": NOTICE}
