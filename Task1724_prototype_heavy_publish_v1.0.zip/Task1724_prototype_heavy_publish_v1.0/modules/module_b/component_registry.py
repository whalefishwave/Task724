# -*- coding: utf-8 -*-
"""六产业组件注册表（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含行业组件能力库真实数据与校验逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class ComponentNotFoundError(Exception):
    """组件不存在异常（占位桩保留异常类型）。"""


class ComponentRegistry:
    """六产业组件注册表（发布版占位桩，保留签名）。"""

    def __init__(self, config: dict | None = None, data_dir: str | None = None):
        self._config = config or {}
        self._stub = True

    def _validate(self):
        """配置校验（占位桩）。"""
        return {"ok": False, "reason": NOTICE}

    @classmethod
    def from_industry(cls, industry: str, data_dir: str | None = None):
        """按行业构建（占位桩）。"""
        return cls(config={"industry": industry})

    def get_component(self, name: str):
        """获取组件（占位桩）。"""
        raise ComponentNotFoundError(NOTICE)

    def list_components(self):
        """组件清单（占位桩）。"""
        return []

    def capabilities(self, name: str):
        """组件能力（占位桩）。"""
        return {"capabilities": [], "note": NOTICE}


def load_industry_configs(data_dir: str | None = None):
    """加载行业配置（占位桩）。"""
    return {}
