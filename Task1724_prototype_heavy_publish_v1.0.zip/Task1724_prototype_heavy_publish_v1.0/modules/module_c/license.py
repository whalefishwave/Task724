# -*- coding: utf-8 -*-
"""IP 授权矩阵（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含授权规则、合同生成与合规判定真实逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class LicenseError(Exception):
    """授权异常（占位桩保留异常类型）。"""


class LicenseMatrix:
    """IP 授权矩阵（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None):
        self._data_dir = data_dir

    def check(self, usage: str, license_type: str):
        """授权组合校验（占位桩：默认禁止并提示中标后提供）。"""
        return {"allowed": False, "usage": usage, "license_type": license_type, "reason": NOTICE}

    def generate_contract(self, licensee: str, ip_name: str, usage: str, license_type: str):
        """生成授权合同（占位桩）。"""
        return {"contract_id": "provided_after_award", "content": NOTICE}

    def summary(self):
        """矩阵概览（占位桩）。"""
        return {"rules": 0, "note": NOTICE}
