# -*- coding: utf-8 -*-
"""文化 IP 双角色设定（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含角色设定与授权声明真实内容。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class CharacterSheetError(Exception):
    """角色档案异常（占位桩保留异常类型）。"""


class CharacterBook:
    """IP 角色书（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None):
        self._data_dir = data_dir

    def get_character(self, role: str):
        """获取角色（占位桩）。"""
        return {"role": role, "name": "provided_after_award", "note": NOTICE}

    def list_characters(self):
        """角色清单（占位桩）。"""
        return []

    def non_exclusive_statement(self):
        """非独占声明（占位桩）。"""
        return NOTICE

    def summary(self):
        """角色书概览（占位桩）。"""
        return {"characters": 0, "note": NOTICE}
