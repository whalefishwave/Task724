# -*- coding: utf-8 -*-
"""文化 IP 视觉资产库（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含视觉配方与资产生成真实逻辑。
"""
from __future__ import annotations

from ai.sdxl_client import SDXLClient  # noqa: F401（占位桩类型引用）

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class AssetRegistryError(Exception):
    """资产注册表异常（占位桩保留异常类型）。"""


class VisualAssetLibrary:
    """视觉资产库（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None, sdxl: SDXLClient | None = None):
        self._data_dir = data_dir
        self._sdxl = sdxl

    def generate_asset(self, recipe_key: str, output_dir: str):
        """生成视觉资产（占位桩）。"""
        return {"path": None, "recipe": recipe_key, "note": NOTICE}

    def list_assets(self):
        """资产清单（占位桩）。"""
        return []

    def list_recipes(self):
        """视觉配方清单（占位桩）。"""
        return []
