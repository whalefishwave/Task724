# -*- coding: utf-8 -*-
"""短剧样片生成管线（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含分镜渲染、样片合成与发布真实逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"

# 公开结构常量：管线状态/事件名清单（迁移规则与处理逻辑不随发布版分发）
PIPELINE_STATES = ["DRAFT", "REVIEWING", "APPROVED", "RENDERING", "PUBLISHED"]
PIPELINE_EVENTS = ["submit", "approve", "rework", "render", "publish"]
TRANSITIONS = {}  # 占位：真实迁移表核心实现将于中标后提供


class PipelineInvalidEventError(Exception):
    """非法管线事件异常（占位桩保留异常类型）。"""


class PipelineMachine:
    """短剧样片管线状态机（发布版占位桩，保留签名）。"""

    def __init__(self, episode_id: str):
        self.episode_id = episode_id
        self.state = "CREATED"
        self._log_entries: list[dict] = []

    def _log(self, event, state, note=""):
        """管线日志（占位桩）。"""
        self._log_entries.append({"event": event, "state": state, "note": NOTICE})

    def fire(self, event: str, note: str = ""):
        """触发事件（占位桩：不执行真实状态迁移）。"""
        return {"ok": False, "event": event, "state": self.state, "reason": NOTICE}

    def publish(self, output_path: str, note: str = "发布成片"):
        """发布成片（占位桩：不生成真实文件）。"""
        return {"output_path": None, "published": False, "reason": NOTICE}

    def render(self, note: str = "渲染分镜"):
        """渲染分镜（占位桩）。"""
        return {"rendered": False, "reason": NOTICE}

    def worklog(self):
        """管线日志（占位桩）。"""
        return list(self._log_entries)
