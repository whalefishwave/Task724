"""prototype_heavy 包：模块 A 工艺AI共创+C2M。"""
