# -*- coding: utf-8 -*-
"""设计共创赛事包（发布版占位桩）。

核心实现将于中标后提供 / core implementation provided after award.
本文件仅保留类与函数签名，返回占位结果；不包含评审打分、门禁判定与 KPI 看板真实逻辑。
"""
from __future__ import annotations

NOTICE = "核心实现将于中标后提供 / core implementation provided after award"


class ContestError(Exception):
    """赛事异常（占位桩保留异常类型）。"""


class ContestManager:
    """设计共创赛事管理器（发布版占位桩，保留签名）。"""

    def __init__(self, data_dir: str | None = None):
        self._data_dir = data_dir

    def list_tracks(self):
        """赛道清单（占位桩）。"""
        return []

    def submit(self, track: str, author: str, title: str):
        """提交作品（占位桩）。"""
        return {"id": "provided_after_award", "track": track, "author": author, "title": title, "note": NOTICE}

    def score(self, submission_id: str, judge: str, score: float, comment: str = ""):
        """评委打分（占位桩）。"""
        return {"ok": False, "reason": NOTICE}

    def _get(self, submission_id: str):
        """取作品（占位桩）。"""
        return {"id": submission_id, "note": NOTICE}

    def final_score(self, submission_id: str):
        """最终得分（占位桩）。"""
        return 0.0

    def prototype_gate(self, submission_id: str, manufacturable: bool):
        """打样门禁（占位桩：默认拦截）。"""
        return {"gate": "blocked_provided_after_award", "reason": NOTICE}

    def kpi_dashboard(self):
        """KPI 看板（占位桩）。"""
        return {"total_submissions": 0, "by_track": {}, "note": NOTICE}
