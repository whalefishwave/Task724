# -*- coding: utf-8 -*-
"""AI 层单测：SDXL mock、LLM 双轨 mock、工作流引擎。"""
import os
import tempfile

import pytest

from ai.llm_client import LLMClient, LLMError
from ai.sdxl_client import SDXLClient, SDXLError
from ai.workflow_engine import WorkflowEngine, WorkflowError


class TestSDXLClient:
    def test_mock_generate_svg(self):
        with tempfile.TemporaryDirectory() as td:
            out = SDXLClient(mode="mock").generate("golden filigree", output_dir=td)
            assert out["mode"] == "mock"
            assert os.path.exists(out["path"])

    def test_unknown_mode_raises(self):
        with pytest.raises(SDXLError):
            SDXLClient(mode="turbo")

    def test_comfy_requires_endpoint(self):
        with pytest.raises(SDXLError):
            SDXLClient(mode="comfy", endpoint="").generate("p", output_dir="x")

    def test_api_requires_key(self):
        with pytest.raises(SDXLError):
            SDXLClient(mode="api", api_key="").generate("p", output_dir="x")


class TestLLMClient:
    def test_mock_chat(self):
        out = LLMClient(mode="mock").chat("评估工艺")
        assert out["mode"] == "mock"
        assert "评估工艺" in out["content"]

    def test_local_requires_endpoint(self):
        with pytest.raises(LLMError):
            LLMClient(mode="local").chat("x")

    def test_api_requires_key(self):
        with pytest.raises(LLMError):
            LLMClient(mode="api").chat("x")

    def test_unknown_mode_raises(self):
        with pytest.raises(LLMError):
            LLMClient(mode="quantum")


class TestWorkflowEngine:
    def test_simple_linear(self):
        engine = WorkflowEngine("linear")
        engine.add_node("a", lambda s: {"x": 1})
        engine.add_node("b", lambda s: {"y": s.get("x", 0) + 1})
        out = engine.run()
        assert out["trace"] == ["a", "b"]
        assert out["final_state"]["y"] == 2

    def test_conditional_route(self):
        def decide(s):
            return {"_next": "high" if s.get("amount", 0) > 100 else "low"}

        engine = WorkflowEngine("branch")
        engine.add_node("start", decide)
        engine.add_node("high", lambda s: {"level": "high"})
        engine.add_node("low", lambda s: {"level": "low"})
        out = engine.run({"amount": 500})
        assert out["trace"] == ["start", "high"]
        assert out["final_state"]["level"] == "high"

    def test_conditional_low_branch(self):
        engine = WorkflowEngine("branch2")
        engine.add_node("start", lambda s: {"_next": "high" if s.get("amount", 0) > 100 else "low"})
        engine.add_node("high", lambda s: {"level": "high"})
        engine.add_node("low", lambda s: {"level": "low"})
        out = engine.run({"amount": 10})
        assert out["trace"] == ["start", "low"]

    def test_empty_workflow_raises(self):
        with pytest.raises(WorkflowError):
            WorkflowEngine("empty").run()

    def test_bad_route_target_raises(self):
        engine = WorkflowEngine("bad")
        engine.add_node("a", lambda s: {}, routes={"x": "missing"})
        with pytest.raises(WorkflowError):
            engine.run()

    def test_cycle_detected(self):
        engine = WorkflowEngine("cycle")
        engine.add_node("a", lambda s: {"_next": "b"})
        engine.add_node("b", lambda s: {"_next": "a"})
        with pytest.raises(WorkflowError):
            engine.run({"": 0})
