# -*- coding: utf-8 -*-
"""可制造性判定单测（G3：10/10 与人工一致）。"""
import pytest

from modules.module_a.manufacturability import ManufacturabilityAssessor, ManufacturabilityError, load_cases


@pytest.fixture(scope="module")
def assessor():
    return ManufacturabilityAssessor(industry="jewelry")


@pytest.fixture(scope="module")
def wood_assessor():
    return ManufacturabilityAssessor(industry="wood")


class TestManufacturabilityCases:
    def test_ten_cases_all_match(self, assessor, wood_assessor):
        """10 个人工评审案例，双层判定结果与人工 100% 一致。"""
        cases = load_cases()
        assert len(cases) == 10
        results = []
        for case in cases:
            ind = case.get("industry_hint", "jewelry")
            a = wood_assessor if ind == "wood" else assessor
            out = a.evaluate(case["design"], case.get("equipment_id"))
            results.append((case["id"], out["verdict"], case["expected"]))
        assert all(actual == expected for _, actual, expected in results), results

    def test_case_rate_report(self, assessor):
        cases = load_cases()
        rep = assessor.run_cases([c for c in cases if c.get("industry_hint") != "wood"])
        assert rep["total"] == 8
        assert rep["passed"] == 8
        assert rep["rate"] == 1.0

    def test_missing_material_rejected(self, assessor):
        with pytest.raises(ManufacturabilityError):
            assessor.evaluate({"stone": "钻石"})

    def test_unknown_industry_rejected(self):
        with pytest.raises(ManufacturabilityError):
            ManufacturabilityAssessor(industry="ceramic")

    def test_equipment_capacity_check(self, assessor):
        out = assessor.evaluate(
            {"material": "18K金", "stone": "无", "dimensions": {"min_width_mm": 300, "min_thickness_mm": 2}},
            equipment_id="jc-laser",
        )
        assert out["verdict"] == "block"
        assert "设备" in out["equipment_note"]

    def test_llm_secondary_check_degrades(self):
        """无 LLM 时 L2 降级采用规则层结论，保持确定性。"""
        a = ManufacturabilityAssessor(industry="jewelry", llm=None)
        out = a.evaluate({"material": "银", "stone": "无", "technique": "花丝", "dimensions": {"min_width_mm": 15, "min_thickness_mm": 1.0}})
        assert out["l2"]["degraded"] is True
        assert out["verdict"] == "pass"
