# -*- coding: utf-8 -*-
"""企业 AI 服务层（FDE）单测（G5：≥2 行业配置切换）。"""
import pytest

from modules.module_b.component_registry import ComponentNotFoundError, ComponentRegistry
from modules.module_b.enterprise_service import EnterpriseService
from modules.module_b.fde_handbook import EnterpriseProfile, FdeHandbook


class TestEnterpriseService:
    def test_jewelry_config(self):
        svc = EnterpriseService("jewelry")
        s = svc.summary()
        assert s["industry"] == "jewelry"
        assert len(s["components"]) == 6
        assert s["kb_entries"] == 3

    def test_wood_config(self):
        svc = EnterpriseService("wood")
        s = svc.summary()
        assert s["industry"] == "wood"
        assert s["agent"] == "木作工艺智能体"

    def test_two_industries_switch_by_config_only(self):
        j = EnterpriseService("jewelry")
        w = EnterpriseService("wood")
        assert j.kb_query("18K金")["matches"][0]["id"] == "kb-j-1"
        assert w.kb_query("黑胡桃")["matches"][0]["id"] == "kb-w-1"

    def test_kb_query_returns_ranked(self):
        svc = EnterpriseService("jewelry")
        out = svc.kb_query("微镶 成本")
        assert out["industry"] == "jewelry"
        assert len(out["matches"]) >= 1

    def test_agent_run(self):
        svc = EnterpriseService("jewelry")
        out = svc.agent_run("评估这款手镯的工艺")
        assert out["ok"] is True
        assert out["agent"] == "珠宝工艺智能体"

    def test_agent_run_with_llm_mock(self):
        from ai.llm_client import LLMClient

        svc = EnterpriseService("jewelry", llm=LLMClient(mode="mock"))
        out = svc.agent_run("推荐工艺")
        assert out["answer"]

    def test_run_workflow(self):
        svc = EnterpriseService("jewelry")
        out = svc.run_workflow("新订单")
        assert len(out["steps"]) == 3
        assert out["final_state"] == {}

    def test_unknown_industry_raises(self):
        with pytest.raises(ComponentNotFoundError):
            EnterpriseService("aerospace")

    def test_registry_components_all_six(self):
        r = ComponentRegistry.from_industry("jewelry")
        assert {c["name"] for c in r.list_components()} == {
            "knowledge_base", "agent", "workflow", "showcase", "crm", "analytics"
        }

    def test_component_missing_raises(self):
        r = ComponentRegistry.from_industry("jewelry")
        with pytest.raises(ComponentNotFoundError):
            r.get_component("unknown_comp")


class TestFdeHandbook:
    def test_handbook_summary(self):
        h = FdeHandbook()
        s = h.summary()
        assert s["title"] == "FDE 企业数字化赋能手册"
        assert "onboarding" in s["sections"]

    def test_get_section(self):
        h = FdeHandbook()
        sec = h.get_section("service_catalog")
        assert len(sec["services"]) == 6

    def test_profile_masked(self):
        p = EnterpriseProfile()
        masked = p.masked_view()
        assert masked["contact_name"] == "***"
        assert masked["phone"] == "***"

    def test_profile_summary(self):
        p = EnterpriseProfile()
        s = p.summary()
        assert s["enterprise_id"].startswith("E-")
        assert "capabilities" in s
