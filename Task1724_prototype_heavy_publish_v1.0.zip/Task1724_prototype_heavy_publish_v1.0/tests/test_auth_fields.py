# -*- coding: utf-8 -*-
"""授权字段强校验单测（G2）。"""
import pytest

from modules.module_a.auth_fields import AuthValidationError, validate_auth_fields, register_auth_record

VALID = {
    "pattern_id": "P-001",
    "source": "self",
    "holder": "内部设计组",
    "license_type": "non_exclusive",
    "scope": "珠宝行业",
    "expiry": "2030-12-31",
    "ai_generated": True,
}


class TestAuthFields:
    def test_valid_record_passes(self):
        r = validate_auth_fields(VALID)
        assert r["ok"] is True
        assert r["errors"] == []

    @pytest.mark.parametrize("missing", [
        "source", "holder", "license_type", "scope", "expiry", "ai_generated",
    ])
    def test_missing_each_required_field_rejected(self, missing):
        data = dict(VALID)
        del data[missing]
        r = validate_auth_fields(data)
        assert r["ok"] is False
        assert missing in r["missing"]
        assert len(r["errors"]) >= 1

    def test_all_fields_missing_rejected(self):
        r = validate_auth_fields({})
        assert r["ok"] is False
        assert len(r["missing"]) == 6

    def test_invalid_license_type_rejected(self):
        data = dict(VALID, license_type="whatever")
        r = validate_auth_fields(data)
        assert r["ok"] is False
        assert any("license_type" in e for e in r["errors"])

    def test_invalid_source_rejected(self):
        data = dict(VALID, source="stolen")
        r = validate_auth_fields(data)
        assert r["ok"] is False

    def test_invalid_expiry_format_rejected(self):
        data = dict(VALID, expiry="2030/12/31")
        r = validate_auth_fields(data)
        assert r["ok"] is False

    def test_null_expiry_allowed_for_public_domain(self):
        data = dict(VALID, source="open_source", holder="公有领域", license_type="public_domain", expiry=None)
        r = validate_auth_fields(data)
        assert r["ok"] is True

    def test_register_valid_saves(self):
        store = {}
        rec = register_auth_record(store, dict(VALID), record_id="R-1")
        assert store["R-1"] is rec
        assert rec.holder == "内部设计组"

    def test_register_invalid_raises(self):
        store = {}
        with pytest.raises(AuthValidationError):
            register_auth_record(store, {})
        assert store == {}
