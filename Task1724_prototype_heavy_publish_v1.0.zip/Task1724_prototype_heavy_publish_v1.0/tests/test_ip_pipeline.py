# -*- coding: utf-8 -*-
"""模块 C：IP 管线单测（G7：双角色 / 授权矩阵 / 短剧样片落盘）。"""
import os
import tempfile

import pytest

from modules.module_c.characters import CharacterBook, CharacterSheetError
from modules.module_c.license import LicenseError, LicenseMatrix
from modules.module_c.pipeline import (
    PIPELINE_EVENTS,
    PIPELINE_STATES,
    PipelineInvalidEventError,
    PipelineMachine,
)
from modules.module_c.assets import AssetRegistryError, VisualAssetLibrary


class TestCharacters:
    def test_two_roles_present(self):
        book = CharacterBook()
        roles = book.list_characters()
        assert {r["role"] for r in roles} == {"designer", "craftsman"}

    def test_get_designer(self):
        c = CharacterBook().get_character("designer")
        assert c["name"] == "织星"

    def test_get_craftsman(self):
        c = CharacterBook().get_character("craftsman")
        assert c["name"] == "老凿"

    def test_non_exclusive_statement(self):
        stmt = CharacterBook().non_exclusive_statement()
        assert "非独占" in stmt

    def test_unknown_role_raises(self):
        with pytest.raises(CharacterSheetError):
            CharacterBook().get_character("god")


class TestLicenseMatrix:
    def test_merchandise_non_exclusive_allowed(self):
        m = LicenseMatrix()
        out = m.check("merchandise", "non_exclusive")
        assert out["allowed"] is True

    def test_game_exclusive_allowed(self):
        m = LicenseMatrix()
        assert m.check("game", "exclusive")["allowed"] is True

    def test_game_non_exclusive_blocked(self):
        m = LicenseMatrix()
        assert m.check("game", "non_exclusive")["allowed"] is False

    def test_short_video_public_domain_blocked(self):
        m = LicenseMatrix()
        assert m.check("short_video", "public_domain")["allowed"] is False

    def test_generate_contract_ok(self):
        m = LicenseMatrix()
        contract = m.generate_contract("某品牌方", "织星与老凿", "merchandise", "non_exclusive")
        assert "某品牌方" in contract
        assert "织星与老凿" in contract
        assert "非独占声明" in contract
        assert "AI 生成内容标识" in contract

    def test_generate_contract_forbidden_raises(self):
        m = LicenseMatrix()
        with pytest.raises(LicenseError):
            m.generate_contract("某游戏厂", "IP", "game", "non_exclusive")


class TestPipelineMachine:
    def test_full_flow_to_published(self):
        m = PipelineMachine("EP-001")
        m.fire("submit")
        m.fire("approve")
        m.render()
        out = m.publish(output_path=r"output\samples\ep001.mp4")
        assert m.state == "PUBLISHED"
        assert out["output_path"].endswith("ep001.mp4")

    def test_initial_state(self):
        m = PipelineMachine("EP-002")
        assert m.state == "DRAFT"

    def test_publish_before_render_raises(self):
        m = PipelineMachine("EP-003")
        m.fire("submit")
        m.fire("approve")
        with pytest.raises(PipelineInvalidEventError):
            m.publish("x.mp4")

    def test_rework_returns_draft(self):
        m = PipelineMachine("EP-004")
        m.fire("submit")
        m.fire("approve")
        m.fire("rework")
        assert m.state == "DRAFT"

    def test_worklog_trace(self):
        m = PipelineMachine("EP-005")
        m.fire("submit")
        m.fire("approve")
        m.render()
        m.publish(r"output\samples\ep005.mp4")
        log = m.worklog()
        assert log["final_state"] == "PUBLISHED"
        assert len(log["steps"]) == 5
        assert log["published_path"] == r"output\samples\ep005.mp4"

    def test_invalid_event_raises(self):
        m = PipelineMachine("EP-006")
        with pytest.raises(PipelineInvalidEventError):
            m.fire("publish")  # DRAFT 不允许 publish

    def test_states_and_events_are_distinct(self):
        # 历史踩坑防护：事件名与状态名不得混用
        assert "publish" in PIPELINE_EVENTS
        assert "PUBLISHED" in PIPELINE_STATES
        assert "PUBLISHED" not in PIPELINE_EVENTS
        assert "publish" not in PIPELINE_STATES


class TestVisualAssets:
    def test_generate_asset_mock_svg(self):
        with tempfile.TemporaryDirectory() as td:
            lib = VisualAssetLibrary()
            entry = lib.generate_asset("hero_visual", td)
            assert entry["mode"] == "mock"
            assert os.path.exists(entry["path"])
            with open(entry["path"], encoding="utf-8") as f:
                svg = f.read()
            assert "ai_generated=true" in svg

    def test_generate_unknown_recipe_raises(self):
        with tempfile.TemporaryDirectory() as td:
            lib = VisualAssetLibrary()
            with pytest.raises(AssetRegistryError):
                lib.generate_asset("not_a_recipe", td)

    def test_list_recipes(self):
        lib = VisualAssetLibrary()
        recipes = lib.list_recipes()
        assert len(recipes) >= 4

    def test_assets_registered(self):
        with tempfile.TemporaryDirectory() as td:
            lib = VisualAssetLibrary()
            lib.generate_asset("character_designer", td)
            assert len(lib.list_assets()) >= 2  # 含初始登记
