# -*- coding: utf-8 -*-
"""三类共创交易分成单测（G8 核心逻辑）。"""
import pytest

from modules.module_a.trades import (
    DEFAULT_CUSTOM_SPLIT,
    DEFAULT_LICENSE_SPLIT,
    ROYALTY_TIERS,
    SplitRule,
    TradeError,
    create_trade,
    split_custom_order,
    split_license_fee,
    split_royalty,
)


class TestTrades:
    def test_custom_split_ratio(self):
        out = split_custom_order(1000)
        assert out["trade_type"] == "custom"
        assert out["designer"] == 450.0
        assert out["workshop"] == 400.0
        assert out["platform"] == 100.0
        assert out["mode"] == "ratio"

    def test_custom_split_rounding(self):
        out = split_custom_order(333.33)
        # 自定义分成 45/40/10（另含平台费 5%），三份合计应为 95% ≈ 316.66
        assert round(out["designer"] + out["workshop"] + out["platform"], 2) == 316.66

    def test_license_split(self):
        out = split_license_fee(1000)
        assert out["licensor"] == 700.0
        assert out["platform"] == 300.0

    def test_royalty_tier_under_5000(self):
        out = split_royalty(4000)
        assert out["creator"] == 1200.0
        assert out["mode"] == "tier"

    def test_royalty_tier_mid(self):
        out = split_royalty(10000)
        assert out["creator"] == 4000.0

    def test_royalty_tier_high(self):
        out = split_royalty(50000)
        assert out["creator"] == 25000.0

    def test_royalty_platform_fee(self):
        out = split_royalty(10000)
        assert out["platform_fee"] == 500.0

    def test_unknown_trade_type(self):
        with pytest.raises(TradeError):
            create_trade("nonsense", 100)

    def test_negative_amount_rejected(self):
        with pytest.raises(TradeError):
            DEFAULT_CUSTOM_SPLIT.apply(-10)

    def test_ratio_over_100_rejected(self):
        with pytest.raises(TradeError):
            SplitRule(shares={"a": 0.6, "b": 0.6}).apply(100)

    def test_empty_rule_rejected(self):
        with pytest.raises(TradeError):
            SplitRule().apply(100)
