# -*- coding: utf-8 -*-
"""模块 D：设计共创赛事包单测。"""
import pytest

from modules.module_d.contest import ContestError, ContestManager


@pytest.fixture(scope="module")
def contest():
    return ContestManager()


class TestContest:
    def test_three_tracks(self, contest):
        assert {t["id"] for t in contest.list_tracks()} == {"jewelry", "wood", "ip"}

    def test_submit_ok(self, contest):
        sub = contest.submit("jewelry", "选手甲", "缠枝莲手镯")
        assert sub["status"] == "SUBMITTED"
        assert sub["track"] == "jewelry"

    def test_submit_unknown_track_raises(self, contest):
        with pytest.raises(ContestError):
            contest.submit("nope", "选手", "作品")

    def test_score_submission(self, contest):
        sub = contest.submit("ip", "选手乙", "短剧脚本")
        contest.score(sub["id"], "评委A", 88.0)
        contest.score(sub["id"], "评委B", 92.0)
        assert contest.final_score(sub["id"]) == 90.0

    def test_double_score_raises(self, contest):
        sub = contest.submit("wood", "选手丙", "茶盘")
        contest.score(sub["id"], "评委A", 80.0)
        with pytest.raises(ContestError):
            contest.score(sub["id"], "评委A", 90.0)  # 同一评委重复打分被拒绝

    def test_score_missing_submission_raises(self, contest):
        with pytest.raises(ContestError):
            contest.score("S-9999", "评委", 90)

    def test_gate_passed(self, contest):
        sub = contest.submit("jewelry", "选手丁", "银花丝胸针")
        out = contest.prototype_gate(sub["id"], manufacturable=True)
        assert out["gate"] == "passed"
        assert sub["status"] == "GATED"

    def test_gate_rejected(self, contest):
        sub = contest.submit("jewelry", "选手戊", "超细镂空件")
        out = contest.prototype_gate(sub["id"], manufacturable=False)
        assert out["gate"] == "rejected"
        assert sub["status"] == "GATE_REJECTED"

    def test_kpi_dashboard(self, contest):
        dash = contest.kpi_dashboard()
        assert dash["total_submissions"] >= 5
        assert set(dash["by_track"].keys()) == {"jewelry", "wood", "ip"}

    def test_kpi_avg_score(self, contest):
        dash = contest.kpi_dashboard()
        # 已打分的 ip 赛道平均分应为 90.0
        assert dash["by_track"]["ip"]["avg_score"] == 90.0
