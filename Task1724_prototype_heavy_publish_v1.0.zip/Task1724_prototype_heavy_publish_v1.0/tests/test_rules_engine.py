# -*- coding: utf-8 -*-
"""自研 JSON/YAML 规则引擎单测。"""
import os

import pytest

from core.rules_engine import RuleEngine

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RULES_JSON = os.path.join(ROOT, "modules", "module_a", "data", "mfg_rules_jewelry.json")
RULES_YAML = os.path.join(ROOT, "core", "rules_demo.yaml")


@pytest.fixture(scope="module")
def engine():
    return RuleEngine.from_file(RULES_JSON)


class TestRuleEngine:
    def test_load_json_file(self, engine):
        assert len(engine.rules) >= 5

    def test_simple_eq_match(self, engine):
        hits = engine.evaluate({"material": "18K金", "stone": "钻石"}, industry="jewelry")
        assert any(h["rule_id"] == "J-001" for h in hits)

    def test_industry_filter(self, engine):
        hits = engine.evaluate({"material": "18K金", "stone": "钻石"}, industry="wood")
        assert all(h["rule_id"].startswith("W-") for h in hits) or hits == []

    def test_comparison_gt(self, engine):
        hits = engine.evaluate({"min_width": 0.2}, industry="jewelry")
        assert any(h["rule_id"] == "J-003" for h in hits)

    def test_decide_block_wins(self, engine):
        d = engine.decide({"min_width": 0.2, "material": "18K金"}, industry="jewelry")
        assert d["decision"] == "block"

    def test_decide_no_match_pass(self, engine):
        d = engine.decide({"material": "铂金"}, industry="jewelry")
        assert d["decision"] == "pass"

    def test_list_conditions_and(self, engine):
        hits = engine.evaluate({"min_thickness": 0.2}, industry="jewelry")
        assert any(h["rule_id"] == "J-005" for h in hits)

    def test_unknown_operator_raises(self):
        with pytest.raises(ValueError):
            RuleEngine([{"id": "X", "when": {"field": "a", "op": "bogus", "value": 1}, "then": {}}]).evaluate({"a": 1})

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            RuleEngine.from_file(os.path.join(ROOT, "no_such.json"))

    def test_yaml_parse(self):
        eng = RuleEngine.from_file(RULES_YAML)
        hits = eng.evaluate({"material": "18K金"}, industry="jewelry")
        assert any(h["rule_id"] == "Y-001" for h in hits)

    def test_yaml_block_rule(self):
        eng = RuleEngine.from_file(RULES_YAML)
        d = eng.decide({"material": "18K金", "min_thickness": 0.2}, industry="jewelry")
        assert d["decision"] == "block"
