# -*- coding: utf-8 -*-
"""出海增长栈单测（G6：三语站点 / SEO / 询盘 CRM 闭环）。"""
import os
import tempfile

import pytest

from modules.module_b.export_stack import ExportStack, ExportStackError


@pytest.fixture(scope="module")
def stack():
    return ExportStack()


class TestExportStack:
    def test_three_lang_sites_loaded(self, stack):
        assert set(stack.sites.keys()) == {"zh", "en", "de"}

    def test_generate_sites_three_html(self, stack):
        with tempfile.TemporaryDirectory() as td:
            written = stack.generate_sites(td)
            assert len(written) == 3
            for lang in ("zh", "en", "de"):
                p = os.path.join(td, f"site_{lang}", "index.html")
                assert os.path.exists(p)
                with open(p, encoding="utf-8") as f:
                    html = f.read()
                assert f'lang="{lang}"' in html
                assert "ai_generated" in html

    def test_seo_metadata_zh(self, stack):
        seo = stack.seo_metadata("zh")
        assert seo["title"] == "山海工坊 - 非遗工艺定制"

    def test_seo_metadata_en(self, stack):
        seo = stack.seo_metadata("en")
        assert "Heritage" in seo["title"]

    def test_seo_metadata_de(self, stack):
        seo = stack.seo_metadata("de")
        assert "Handwerkskunst" in seo["title"]

    def test_seo_report_three_langs(self, stack):
        rep = stack.seo_report()
        assert set(rep.keys()) == {"zh", "en", "de"}

    def test_submit_inquiry_creates_lead(self, stack):
        lead = stack.submit_inquiry("buyer@example.com", "I want a custom bracelet", source_lang="en")
        assert lead["status"] == "NEW"
        assert lead["assigned_sales"] == "sales-global"

    def test_inquiry_german_routing(self, stack):
        lead = stack.submit_inquiry("kaeufer@example.de", "Interesse an Holztablett", source_lang="de")
        assert lead["assigned_sales"] == "sales-de"

    def test_inquiry_missing_fields_rejected(self, stack):
        with pytest.raises(ExportStackError):
            stack.submit_inquiry("", "msg")

    def test_follow_up_lead(self, stack):
        lead = stack.submit_inquiry("f@example.com", "hello", source_lang="en")
        updated = stack.follow_up(lead["lead_id"])
        assert updated["status"] == "FOLLOWED_UP"

    def test_follow_up_unknown_raises(self, stack):
        with pytest.raises(ExportStackError):
            stack.follow_up("L-99999")

    def test_crm_summary_count(self, stack):
        summary = stack.crm_summary()
        assert summary["total"] >= 3
