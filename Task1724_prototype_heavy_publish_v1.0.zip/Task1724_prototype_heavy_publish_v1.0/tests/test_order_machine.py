# -*- coding: utf-8 -*-
"""C2M 订单状态机 + 台账单测（G4）。"""
import pytest

from modules.module_a.order_machine import (
    ALL_STATES,
    InvalidTransitionError,
    OrderMachine,
    TRANSITIONS,
)


@pytest.fixture
def machine():
    return OrderMachine(order_id="ORD-T1")


class TestOrderMachine:
    def test_initial_state_created(self, machine):
        assert machine.state == "CREATED"
        assert len(machine.ledger) == 1

    def test_happy_path(self, machine):
        for event in ["pay", "make_work_order", "dispatch", "qc_pass", "ship", "settle"]:
            entry = machine.transition(event, actor="test")
            assert entry["event"] == event
        assert machine.state == "SETTLED"

    def test_qc_fail_returns_to_processing(self, machine):
        machine.transition("pay")
        machine.transition("make_work_order")
        machine.transition("dispatch")
        machine.transition("qc_fail")
        assert machine.state == "PROCESSING"

    def test_invalid_transition_raises(self, machine):
        with pytest.raises(InvalidTransitionError):
            machine.transition("settle")  # CREATED 不允许 settle

    def test_request_refund_from_paid(self):
        m = OrderMachine(order_id="ORD-R1")
        m.transition("pay")
        m.request_refund(amount=100.0)
        assert m.state == "REFUND_REQUESTED"

    def test_approve_refund(self):
        m = OrderMachine(order_id="ORD-R2")
        m.transition("pay")
        m.request_refund(amount=100.0)
        m.approve_refund(amount=100.0)
        assert m.state == "REFUNDED"

    def test_reject_refund_back_to_paid(self):
        m = OrderMachine(order_id="ORD-R3")
        m.transition("pay")
        m.request_refund(amount=100.0)
        m.reject_refund(amount=100.0)
        assert m.state == "PAID"

    def test_dispute_branch(self):
        m = OrderMachine(order_id="ORD-R4")
        m.transition("pay")
        m.request_refund(amount=100.0)
        m.open_dispute(amount=100.0)
        assert m.state == "DISPUTE"
        m.resolve_dispute(amount=80.0)
        assert m.state == "SETTLED"

    def test_refund_not_allowed_after_settled(self):
        m = OrderMachine(order_id="ORD-R5")
        for event in ["pay", "make_work_order", "dispatch", "qc_pass", "ship", "settle"]:
            m.transition(event)
        with pytest.raises(InvalidTransitionError):
            m.request_refund(100.0)

    def test_ledger_traceable(self, machine):
        machine.transition("pay", actor="buyer", amount=1280.0, note="支付定金")
        summary = machine.ledger_summary()
        assert summary["order_id"] == "ORD-T1"
        assert summary["final_state"] == "PAID"
        assert len(summary["entries"]) == 2
        assert summary["total_amount_tracked"] == 1280.0
        # 每条台账记录为 (event, from_state, to_state, ts)，可用 (from, to) 定位
        assert summary["timeline"][0][0] == "init"
        assert summary["timeline"][0][2] == "CREATED"
        assert summary["timeline"][1][0] == "pay"
        assert summary["timeline"][1][2] == "PAID"

    def test_replay_recovers_state(self):
        m = OrderMachine(order_id="ORD-REPLAY")
        for event in ["pay", "make_work_order", "dispatch"]:
            m.transition(event, actor="sys")
        clone = OrderMachine.replay(m.ledger)
        assert clone.order_id == "ORD-REPLAY"
        assert clone.state == "DISPATCHED"
        assert clone.ledger == m.ledger

    def test_transitions_cover_all_states(self):
        assert set(TRANSITIONS.keys()) == {
            "pay", "make_work_order", "dispatch", "qc_pass", "qc_fail", "ship", "settle",
            "request_refund", "approve_refund", "reject_refund", "open_dispute", "resolve_dispute",
        }
        assert "SETTLED" in ALL_STATES
        assert "DISPUTE" in ALL_STATES
