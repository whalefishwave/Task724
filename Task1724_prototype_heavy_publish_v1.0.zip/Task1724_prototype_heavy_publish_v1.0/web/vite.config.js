import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// 前端开发服务器代理到 FastAPI 后端
// - 宿主机直接 npm run dev：默认 http://localhost:8000
// - Docker Compose（web 容器内）：docker-compose.yml 注入 APP_API_TARGET=http://app:8000
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': process.env.APP_API_TARGET || 'http://localhost:8000',
      '/media': process.env.APP_API_TARGET || 'http://localhost:8000',
    },
  },
});
