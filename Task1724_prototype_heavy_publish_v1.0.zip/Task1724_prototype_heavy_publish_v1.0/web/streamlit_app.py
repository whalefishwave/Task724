# -*- coding: utf-8 -*-
"""Streamlit 仪表盘（企业 AI 服务层六组件可视化 + 赛事 KPI 看板）。

启动: streamlit run web/streamlit_app.py
依赖: streamlit>=1.33（见 requirements.txt 可选段）
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import streamlit as st
except ImportError:  # 未安装时给出提示而非崩溃
    print("未安装 streamlit，请先执行: pip install streamlit")
    raise SystemExit(0)

from modules.module_b.enterprise_service import EnterpriseService  # noqa: E402
from modules.module_d.contest import ContestManager  # noqa: E402


def main() -> None:
    st.set_page_config(page_title="ClawHunt #1724 FDE 服务层", layout="wide")
    st.title("六产业共享企业 AI 服务层（FDE）仪表盘")
    industry = st.selectbox("行业配置切换", ["jewelry", "wood"])
    svc = EnterpriseService(industry)
    st.json(svc.summary())
    st.subheader("赛事 KPI 看板")
    st.json(ContestManager().kpi_dashboard())


if __name__ == "__main__":
    main()
