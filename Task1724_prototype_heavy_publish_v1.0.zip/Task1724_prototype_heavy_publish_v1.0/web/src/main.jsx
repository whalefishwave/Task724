import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';

/* =====================================================================
 * ClawHunt #1724 · prototype_heavy · 多标签页可交互工作台
 * - 页签：A 创意工作台 / B 企业AI服务层 / C IP工作室 / D 赛事包
 *         订单与工厂 / 契约与规则 / 验收与部署
 * - 真实接口：/api/health · /api/industries · /api/components/{industry}
 * - 授权强校验(G2)与订单状态机追溯(G4)为前端交互演示（不编造端点）
 * ===================================================================== */

const STATUS_FLOW = [
  { key: 'DRAFT', zh: '草稿', en: 'Draft', de: 'Entwurf' },
  { key: 'ORDERED', zh: '已下单', en: 'Ordered', de: 'Bestellt' },
  { key: 'PRODUCING', zh: '生产中', en: 'Producing', de: 'In Produktion' },
  { key: 'QC', zh: '质检中', en: 'QC Check', de: 'Qualitätsprüfung' },
  { key: 'PACKED', zh: '已打包', en: 'Packed', de: 'Verpackt' },
  { key: 'SHIPPED', zh: '已发货', en: 'Shipped', de: 'Versendet' },
  { key: 'ACCEPTED', zh: '已验收', en: 'Accepted', de: 'Abgenommen' },
];

const I18N = {
  zh: {
    brand: 'ClawHunt #1724',
    chip: '重技术栈原型 · 多标签工作台',
    heroTitle: '工艺AI共创 + C2M 柔性定制平台',
    heroSub: '区域特色产业 AI 赋能一期 · 六产业共享企业 AI 服务层 FDE · 全链路可演示工作台',
    stackNote: 'FastAPI/Uvicorn · React 18 + Vite · PG16+pgvector · SDXL(mock) · 本地/API 双轨 LLM · Docker Compose',
    footer: '业务核心在 modules/，API 层由 FastAPI 暴露；A/B/验收页数据来自真实接口，交互演示不调用后端',
    tabs: {
      a: 'A 创意工作台', b: 'B 企业AI服务层', c: 'C IP工作室', d: 'D 赛事包',
      orders: '订单与工厂', contracts: '契约与规则', ops: '验收与部署',
    },
    a: {
      title: '创意工作台 · MODULE A',
      sub: '概念生成 → 授权强校验（G2）→ 可制造性判定',
      conceptTitle: '概念生成表单（演示）',
      conceptHint: '选择行业后自动读取真实行业组件，生成演示概念摘要',
      material: '材料', process: '工艺', style: '风格', conceptNote: '创意备注',
      industryLabel: '目标行业', placeholderConcept: '例如：将传统银器工艺与现代极简风格结合…',
      generate: '生成概念', clearing: '清理',
      conceptResult: '生成的概念摘要',
      noIndustry: '请先选择行业',
      conceptLine: '面向「{industry}」的 AI 共创概念：{style} × {material}，主工艺 {process}，建议优先复用行业组件并走授权校验后再进入打样。',
      authTitle: '授权强校验演示（G2 · 缺任一字段即拒绝）',
      authDesc: '模拟后端强校验：授权方 / 授权类型 / 地域 / 期限 / 使用范围 / 分成比例 六项必填，少任意一项都拒绝（6/6 通过才算通过）。',
      authFields: { holder: '被授权方', type: '授权类型', region: '地域范围', term: '授权期限', scope: '使用范围', ratio: '分成比例' },
      authPlaceholders: { holder: '如：XX 工坊有限公司', type: '如：独占授权', region: '如：中国大陆', term: '如：2026-01-01 ~ 2026-12-31', scope: '如：电商渠道', ratio: '如：30%' },
      runAuth: '执行强校验', authPass: '校验通过 · 授权合法', authReject: '校验拒绝 · 缺少字段',
      missingList: '缺失字段', allPass: '六项全部通过',
      manufactTitle: '可制造性判定展示',
      manufactHint: '基于真实行业组件清单（/api/components/{industry}）做可制造性判定',
      manufactDecision: '判定结果', manufactReady: '可制造 · 组件齐备', manufactBlock: '待补充 · 组件不足',
      compLabel: '可用组件',
    },
    b: {
      title: '企业AI服务层 · MODULE B（FDE）',
      sub: '六产业共享服务 · 行业配置切换（真实接口）· 出海询盘闭环',
      industryTitle: '行业组件切换（真实接口）',
      industryHint: 'GET /api/industries → GET /api/components/{industry}',
      currentIndustry: '当前行业', switchTo: '切换到该行业', loading: '加载中…', noData: '暂无数据',
      compTitle: '行业组件能力',
      inquiryTitle: '出海询盘表单（演示）',
      inquiryHint: '后端暂未暴露询盘端点，以下为本地演示闭环',
      inqCompany: '企业名称', inqContact: '联系人', inqCountry: '目标市场', inqLang: '咨询语言',
      inqMsg: '需求描述', submitInquiry: '提交询盘', inquiryOk: '已收录询盘',
      inquiries: '询盘台账（CRM 演示）', emptyInquiries: '暂无询盘记录',
      countries: ['中国大陆', '欧洲', '北美', '东南亚', '中东'],
      languages: ['中文', 'English', 'Deutsch'],
    },
    c: {
      title: 'IP工作室 · MODULE C',
      sub: '设计师 × 匠人双角色共创 · 授权矩阵 · 样片入口（发布版按防白嫖约定隐藏资产）',
      roleTitle: '双角色共创',
      roles: [
        { k: 'designer', n: '设计师', d: '概念创意 / 视觉资产 / IP 形象设计，产出可登记资产' },
        { k: 'craftsman', n: '匠人', d: '工艺实现 / 打样制造 / 质检反馈，与设计师协同迭代' },
      ],
      matrixTitle: '授权矩阵（演示规则）',
      matrixHint: '发布版不暴露真实授权数据，以下为演示结构',
      matrixHead: ['资产', '独占授权', '非独占授权', '地域限制', '分成比例'],
      matrixRows: [
        ['IP 视觉形象', '√', '—', '中国大陆', '30%'],
        ['工艺参数集', '√', '√', '全球', '25%'],
        ['短剧样片', '—', '√', '指定渠道', '20%'],
      ],
      sampleTitle: '样片入口',
      sampleHint: 'AI 配音 / 1080p 样片 / 视觉资产为私有资产，已在发布版剔除；核心实现于中标后提供。',
      sampleAction: '申请查看样片（演示）',
    },
    d: {
      title: '设计共创赛事包 · MODULE D',
      sub: '三赛道报名（演示）· 智能评审门禁 · KPI 看板',
      trackTitle: '三赛道',
      tracks: [
        { k: 'craft', n: '工艺创新赛道', d: '材料 × 工艺 × 传统再造' },
        { k: 'ip', n: 'IP 衍生赛道', d: '文化 IP × 商业衍生设计' },
        { k: 'combo', n: '跨界融合赛道', d: '多产业 C2M 柔性定制' },
      ],
      regTitle: '赛事报名（演示）',
      regName: '团队 / 个人名称', regTrack: '报名赛道', regCity: '所在地区', regDesc: '作品简介',
      submitReg: '提交报名', regOk: '报名已受理（演示）',
      entries: '报名台账', emptyEntries: '暂无报名',
      gateTitle: '打样门禁（演示规则）',
      gateRules: ['提交报名 → 资格审核 → 智能评审打分 → 通过后解锁打样资源', '发布版不暴露真实评审模型，门禁规则为演示'],
    },
    orders: {
      title: '订单与工厂',
      sub: '订单创建（演示）· 订单状态机追溯 G4 台账（可视化）',
      createTitle: '订单创建表单（演示）',
      createHint: '后端暂未暴露订单端点，本地演示生成订单并驱动状态机',
      ordProduct: '产品', ordQty: '数量', ordBatch: '批次', ordDeadline: '交期',
      ordPlaceholders: { product: '如：银饰 C2M 定制项链', qty: '如：200', batch: '如：B-2026-003', deadline: '如：2026-12-01' },
      createOrder: '创建订单', orders: '订单列表',
      emptyOrders: '暂无订单', status: '当前状态',
      stepperTitle: '订单状态机追溯（G4 · 台账可追溯）',
      stepperHint: '点击事件按钮推进状态，右侧台账记录每一步（含时间戳）',
      trigger: '触发事件', timeline: '追溯台账', emptyTimeline: '尚无事件记录',
      eventPlaceholder: '选择订单',
      evtCreate: '创建', evtOrder: '派单', evtProduce: '生产', evtQc: '质检', evtPack: '打包', evtShip: '发货', evtAccept: '验收',
      noOrderHint: '先在上方创建订单，再驱动状态机',
    },
    contracts: {
      title: '契约与规则',
      sub: '授权契约类型 · 分成规则 · 合规标识（发布版为演示结构）',
      typesTitle: '授权契约类型（演示）',
      types: [
        { n: '独占授权契约', d: '被授权方在约定地域/渠道独占使用，分成比例最高' },
        { n: '非独占授权契约', d: '多被授权方并行，按实际销售额分成' },
        { n: '定制生产契约', d: 'C2M 一单一产，含交期与验收条款' },
      ],
      rulesTitle: '分成与迁移规则（演示）',
      rules: [
        '授权分成比例在发布版中占位为 null，真实比例于中标后按业务确认',
        '状态机迁移规则：DRAFT→ORDERED→PRODUCING→QC→PACKED→SHIPPED→ACCEPTED',
        'G2 强校验：六字段缺一即拒绝，防止授权要素不完整进入生产',
      ],
      complianceTitle: '合规标识覆盖（G10）',
      complianceHint: '数据文件 21/22 已覆盖合成/脱敏标识，发布版保留声明',
    },
    ops: {
      title: '验收与部署',
      sub: 'G1–G10 自检清单 · 服务端口 · 后端健康状态（真实接口）',
      healthTitle: '后端服务健康',
      healthOk: '在线', healthBad: '不可达', healthChecking: '检测中…',
      healthErrorHint: '请检查 app 容器 8000 端口（docker compose ps）或 vite 代理 APP_API_TARGET',
      verifyTitle: 'G1–G10 验收自检清单（output/VERIFICATION_heavy.md）',
      verify: [
        ['G1', '四流程全链闭环：A工艺共创 / B六组件 / C双角色+授权 / D赛事门禁'],
        ['G2', '授权强校验：缺任一字段拒绝 6/6，全字段通过'],
        ['G3', '可制造性规则与人工一致 10/10'],
        ['G4', '订单状态机：QC 台账 7 条可追溯'],
        ['G5', '企业AI服务层可配置行业：jewelry / wood'],
        ['G6', '出海栈三语（zh / en / de）+ 询盘 CRM 闭环'],
        ['G7', '双角色共创 + 授权矩阵 + 样片落盘'],
        ['G8', 'pytest 126 passed，exit=0'],
        ['G9', '自检命令真实可运行 8/8'],
        ['G10', '合成 / 脱敏标识覆盖数据文件 21/22'],
      ],
      portsTitle: '服务端口',
      ports: [
        ['5173', '前端仪表盘（本页）', 'http://<IP>:5173'],
        ['8000', 'FastAPI 后端 + Swagger', 'http://<IP>:8000/docs'],
        ['5432', 'PostgreSQL 16（仅内网）', '不对外暴露'],
      ],
      colPort: '端口', colUse: '用途', colHow: '访问方式',
    },
    common: {
      backends: '后端', frontend: '前端', database: '数据库', statusOk: '正常', statusFail: '异常',
    },
  },

  en: {
    brand: 'ClawHunt #1724',
    chip: 'Heavy Stack Prototype · Multi-Tab Workbench',
    heroTitle: 'AI Co-Creation + C2M Flexible Customization Platform',
    heroSub: 'Regional Industry AI Enablement Phase 1 · FDE Shared Enterprise AI Service Layer · Full-Pipeline Demo Workbench',
    stackNote: 'FastAPI/Uvicorn · React 18 + Vite · PG16+pgvector · SDXL(mock) · Local/API Dual LLM · Docker Compose',
    footer: 'Core logic lives in modules/, exposed via FastAPI; tabs A/B/ops use real endpoints, interaction demos are frontend-only',
    tabs: {
      a: 'A Studio', b: 'B Enterprise AI', c: 'C IP Studio', d: 'D Contest',
      orders: 'Orders & Factory', contracts: 'Contracts & Rules', ops: 'Acceptance & Deploy',
    },
    a: {
      title: 'Co-Creation Studio · MODULE A',
      sub: 'Concept Generation → Authorization Check (G2) → Manufacturability',
      conceptTitle: 'Concept Generation Form (Demo)',
      conceptHint: 'Select an industry to load real components and generate a demo concept summary',
      material: 'Material', process: 'Process', style: 'Style', conceptNote: 'Concept Notes',
      industryLabel: 'Target Industry', placeholderConcept: 'e.g. combine traditional silver craft with modern minimalism…',
      generate: 'Generate Concept', clearing: 'Clear',
      conceptResult: 'Generated Concept Summary',
      noIndustry: 'Please select an industry first',
      conceptLine: 'AI co-creation concept for "{industry}": {style} × {material}, core process {process}; reuse industry components and pass authorization check before sampling.',
      authTitle: 'Authorization Strict Check Demo (G2 · Reject if any field missing)',
      authDesc: 'Simulates backend strict validation: holder / type / region / term / scope / ratio are all required; missing any one field means rejection (pass only when 6/6).',
      authFields: { holder: 'Licensee', type: 'License Type', region: 'Region', term: 'Term', scope: 'Usage Scope', ratio: 'Royalty Ratio' },
      authPlaceholders: { holder: 'e.g. XX Crafts Co., Ltd.', type: 'e.g. Exclusive', region: 'e.g. Mainland China', term: 'e.g. 2026-01-01 ~ 2026-12-31', scope: 'e.g. E-commerce', ratio: 'e.g. 30%' },
      runAuth: 'Run Strict Check', authPass: 'PASS · Authorization Valid', authReject: 'REJECTED · Missing Fields',
      missingList: 'Missing Fields', allPass: 'All 6 fields provided',
      manufactTitle: 'Manufacturability Assessment',
      manufactHint: 'Based on real component list from /api/components/{industry}',
      manufactDecision: 'Verdict', manufactReady: 'Manufacturable · Components Ready', manufactBlock: 'Blocked · Components Insufficient',
      compLabel: 'Available Components',
    },
    b: {
      title: 'Enterprise AI Service Layer · MODULE B (FDE)',
      sub: 'Six-Industry Shared Services · Industry Switching (Real API) · Overseas Inquiry Loop',
      industryTitle: 'Industry & Component Switching (Real API)',
      industryHint: 'GET /api/industries → GET /api/components/{industry}',
      currentIndustry: 'Current Industry', switchTo: 'Switch to this industry', loading: 'Loading…', noData: 'No data',
      compTitle: 'Industry Components',
      inquiryTitle: 'Overseas Inquiry Form (Demo)',
      inquiryHint: 'No inquiry endpoint exposed yet; this is a local demo loop',
      inqCompany: 'Company', inqContact: 'Contact', inqCountry: 'Target Market', inqLang: 'Language',
      inqMsg: 'Requirement', submitInquiry: 'Submit Inquiry', inquiryOk: 'Inquiry recorded',
      inquiries: 'Inquiry Ledger (CRM demo)', emptyInquiries: 'No inquiries yet',
      countries: ['Mainland China', 'Europe', 'North America', 'Southeast Asia', 'Middle East'],
      languages: ['中文', 'English', 'Deutsch'],
    },
    c: {
      title: 'IP Studio · MODULE C',
      sub: 'Designer × Craftsman Co-Creation · License Matrix · Sample Entry (assets hidden in publish edition)',
      roleTitle: 'Dual-Role Co-Creation',
      roles: [
        { k: 'designer', n: 'Designer', d: 'Concept / visual assets / IP design, registers assets' },
        { k: 'craftsman', n: 'Craftsman', d: 'Process realization / sampling / QC feedback, iterates with designer' },
      ],
      matrixTitle: 'License Matrix (Demo Rules)',
      matrixHint: 'Publish edition hides real license data; demo structure shown',
      matrixHead: ['Asset', 'Exclusive', 'Non-Exclusive', 'Region', 'Royalty'],
      matrixRows: [
        ['IP Visual Identity', '√', '—', 'Mainland China', '30%'],
        ['Craft Parameter Set', '√', '√', 'Global', '25%'],
        ['Short-Video Sample', '—', '√', 'Chosen Channels', '20%'],
      ],
      sampleTitle: 'Sample Entry',
      sampleHint: 'AI voiceover / 1080p samples / visual assets are private and excluded from the publish edition; core delivered after award.',
      sampleAction: 'Request Sample (Demo)',
      sampleModalTitle: 'Sample Preview',
      sampleMain: 'Main Sample (AI Voice, 1080p)',
      sampleEp: 'IP Short-Video Sample',
      sampleLoading: 'Loading…',
      sampleReady: 'Playable',
      sampleHidden: 'Demo samples are hidden per the anti-free-ride agreement; provided after award',
      sampleClose: 'Close',
    },
    d: {
      title: 'Design Co-Creation Contest · MODULE D',
      sub: 'Three Tracks Registration (Demo) · Smart Review Gate · KPI Board',
      trackTitle: 'Three Tracks',
      tracks: [
        { k: 'craft', n: 'Craft Innovation', d: 'Material × Process × Tradition Reinvention' },
        { k: 'ip', n: 'IP Derivative', d: 'Cultural IP × Commercial Design' },
        { k: 'combo', n: 'Cross-Industry Fusion', d: 'Multi-Industry C2M Customization' },
      ],
      regTitle: 'Contest Registration (Demo)',
      regName: 'Team / Individual', regTrack: 'Track', regCity: 'Region', regDesc: 'Work Description',
      submitReg: 'Submit Registration', regOk: 'Registration received (Demo)',
      entries: 'Registration Ledger', emptyEntries: 'No registrations',
      gateTitle: 'Sampling Gate (Demo Rules)',
      gateRules: ['Register → Eligibility → AI review scoring → unlock sampling after pass', 'Publish edition hides the real review model; gate rules are demo'],
    },
    orders: {
      title: 'Orders & Factory',
      sub: 'Order Creation (Demo) · Order State Machine Trace G4 Ledger (Visualized)',
      createTitle: 'Order Creation Form (Demo)',
      createHint: 'No order endpoint exposed yet; local demo generates orders and drives the state machine',
      ordProduct: 'Product', ordQty: 'Qty', ordBatch: 'Batch', ordDeadline: 'Deadline',
      ordPlaceholders: { product: 'e.g. Silver C2M custom necklace', qty: 'e.g. 200', batch: 'e.g. B-2026-003', deadline: 'e.g. 2026-12-01' },
      createOrder: 'Create Order', orders: 'Order List',
      emptyOrders: 'No orders', status: 'Status',
      stepperTitle: 'Order State Machine Trace (G4 · Traceable Ledger)',
      stepperHint: 'Click event buttons to advance status; ledger records every step with timestamp',
      trigger: 'Trigger Event', timeline: 'Trace Ledger', emptyTimeline: 'No events yet',
      eventPlaceholder: 'Select an order',
      evtCreate: 'Create', evtOrder: 'Dispatch', evtProduce: 'Produce', evtQc: 'QC', evtPack: 'Pack', evtShip: 'Ship', evtAccept: 'Accept',
      noOrderHint: 'Create an order above first, then drive the state machine',
    },
    contracts: {
      title: 'Contracts & Rules',
      sub: 'License Contract Types · Royalty Rules · Compliance Marking (demo structure in publish)',
      typesTitle: 'License Contract Types (Demo)',
      types: [
        { n: 'Exclusive License', d: 'Exclusive use in agreed region/channel, highest royalty' },
        { n: 'Non-Exclusive License', d: 'Parallel licensees, royalty on actual sales' },
        { n: 'Custom Production Contract', d: 'C2M one-order-one-production with delivery & acceptance terms' },
      ],
      rulesTitle: 'Royalty & Transition Rules (Demo)',
      rules: [
        'Royalty ratios are placeholders (null) in publish edition; real values confirmed after award',
        'State machine transitions: DRAFT→ORDERED→PRODUCING→QC→PACKED→SHIPPED→ACCEPTED',
        'G2 strict check: reject if any of the 6 fields missing to prevent incomplete licensing into production',
      ],
      complianceTitle: 'Compliance Marking Coverage (G10)',
      complianceHint: '21/22 data files covered with synthetic/anonymization marks; declaration kept in publish',
    },
    ops: {
      title: 'Acceptance & Deployment',
      sub: 'G1–G10 Checklist · Service Ports · Backend Health (Real API)',
      healthTitle: 'Backend Health',
      healthOk: 'Online', healthBad: 'Unreachable', healthChecking: 'Checking…',
      healthErrorHint: 'Check app container port 8000 (docker compose ps) or vite proxy APP_API_TARGET',
      verifyTitle: 'G1–G10 Acceptance Checklist (output/VERIFICATION_heavy.md)',
      verify: [
        ['G1', 'Four flows closed-loop: A co-creation / B six components / C dual-role+license / D contest gate'],
        ['G2', 'Strict authorization check: reject 6/6 when any field missing, pass when all present'],
        ['G3', 'Manufacturability rules match human review 10/10'],
        ['G4', 'Order state machine: 7 traceable QC ledger entries'],
        ['G5', 'FDE configurable industries: jewelry / wood'],
        ['G6', 'Trilingual (zh / en / de) + inquiry CRM loop'],
        ['G7', 'Dual-role co-creation + license matrix + sample on disk'],
        ['G8', 'pytest 126 passed, exit=0'],
        ['G9', 'Self-check commands runnable 8/8'],
        ['G10', 'Synthetic/anonymization marks cover 21/22 data files'],
      ],
      portsTitle: 'Service Ports',
      ports: [
        ['5173', 'Frontend dashboard (this page)', 'http://<IP>:5173'],
        ['8000', 'FastAPI backend + Swagger', 'http://<IP>:8000/docs'],
        ['5432', 'PostgreSQL 16 (internal only)', 'Not exposed'],
      ],
      colPort: 'Port', colUse: 'Purpose', colHow: 'Access',
    },
    common: {
      backends: 'Backend', frontend: 'Frontend', database: 'Database', statusOk: 'OK', statusFail: 'FAIL',
    },
  },

  de: {
    brand: 'ClawHunt #1724',
    chip: 'Heavy-Stack-Prototyp · Multi-Tab-Workbench',
    heroTitle: 'KI-Co-Creation + C2M Flexible Customization Platform',
    heroSub: 'Regional Industry KI Enablement Phase 1 · FDE Shared Enterprise KI Service Layer · Full-Pipeline Demo Workbench',
    stackNote: 'FastAPI/Uvicorn · React 18 + Vite · PG16+pgvector · SDXL(mock) · Local/API Dual LLM · Docker Compose',
    footer: 'Kernlogik in modules/, über FastAPI exponiert; Tabs A/B/ops nutzen echte Endpunkte, Interaktions-Demos nur Frontend',
    tabs: {
      a: 'A Studio', b: 'B Enterprise-KI', c: 'C IP-Studio', d: 'D Wettbewerb',
      orders: 'Aufträge & Fabrik', contracts: 'Verträge & Regeln', ops: 'Abnahme & Deploy',
    },
    a: {
      title: 'Co-Creation-Studio · MODUL A',
      sub: 'Konzeptgenerierung → Autorisierungsprüfung (G2) → Fertigbarkeit',
      conceptTitle: 'Konzeptgenerierungs-Formular (Demo)',
      conceptHint: 'Branche wählen lädt echte Komponenten und erzeugt eine Demo-Konzeptzusammenfassung',
      material: 'Material', process: 'Verfahren', style: 'Stil', conceptNote: 'Konzeptnotizen',
      industryLabel: 'Zielbranche', placeholderConcept: 'z.B. traditionelles Silberhandwerk mit modernem Minimalismus…',
      generate: 'Konzept generieren', clearing: 'Zurücksetzen',
      conceptResult: 'Generierte Konzeptzusammenfassung',
      noIndustry: 'Bitte zuerst Branche wählen',
      conceptLine: 'KI-Co-Creation-Konzept für "{industry}": {style} × {material}, Kernverfahren {process}; Komponenten wiederverwenden und vor dem Musterbau Autorisierungsprüfung bestehen.',
      authTitle: 'Strenge Autorisierungsprüfung (G2 · Ablehnung bei fehlendem Feld)',
      authDesc: 'Simuliert Backend-Strengprüfung: Lizenznehmer / Typ / Region / Laufzeit / Umfang / Anteil sind Pflichtfelder; fehlt eines → Ablehnung (nur 6/6 besteht).',
      authFields: { holder: 'Lizenznehmer', type: 'Lizenztyp', region: 'Region', term: 'Laufzeit', scope: 'Nutzungsumfang', ratio: 'Lizenzanteil' },
      authPlaceholders: { holder: 'z.B. XX Werkstätten GmbH', type: 'z.B. Exklusiv', region: 'z.B. Festlandchina', term: 'z.B. 2026-01-01 ~ 2026-12-31', scope: 'z.B. E-Commerce', ratio: 'z.B. 30%' },
      runAuth: 'Strenge Prüfung ausführen', authPass: 'BESTANDEN · Autorisierung gültig', authReject: 'ABGELEHNT · Felder fehlen',
      missingList: 'Fehlende Felder', allPass: 'Alle 6 Felder vorhanden',
      manufactTitle: 'Fertigbarkeitsbewertung',
      manufactHint: 'Basiert auf echter Komponentenliste von /api/components/{industry}',
      manufactDecision: 'Urteil', manufactReady: 'Fertigbar · Komponenten bereit', manufactBlock: 'Blockiert · Komponenten unzureichend',
      compLabel: 'Verfügbare Komponenten',
    },
    b: {
      title: 'Enterprise-KI-Service-Schicht · MODUL B (FDE)',
      sub: 'Sechs-Branchen-Dienste · Branchenwechsel (Echte API) · Overseas-Inquiry-Loop',
      industryTitle: 'Branchen- & Komponentenwechsel (Echte API)',
      industryHint: 'GET /api/industries → GET /api/components/{industry}',
      currentIndustry: 'Aktuelle Branche', switchTo: 'Zu dieser Branche wechseln', loading: 'Laden…', noData: 'Keine Daten',
      compTitle: 'Branchenkomponenten',
      inquiryTitle: 'Anfrageformular (Demo)',
      inquiryHint: 'Noch kein Anfrage-Endpunkt; lokaler Demo-Loop',
      inqCompany: 'Unternehmen', inqContact: 'Kontakt', inqCountry: 'Zielmarkt', inqLang: 'Sprache',
      inqMsg: 'Anforderung', submitInquiry: 'Anfrage senden', inquiryOk: 'Anfrage erfasst',
      inquiries: 'Anfrage-Ledger (CRM-Demo)', emptyInquiries: 'Noch keine Anfragen',
      countries: ['Festlandchina', 'Europa', 'Nordamerika', 'Südostasien', 'Naher Osten'],
      languages: ['中文', 'English', 'Deutsch'],
    },
    c: {
      title: 'IP-Studio · MODUL C',
      sub: 'Designer × Handwerker Co-Creation · Lizenzmatrix · Muster-Eingang (Assets in Publish-Version entfernt)',
      roleTitle: 'Zwei-Rollen-Co-Creation',
      roles: [
        { k: 'designer', n: 'Designer', d: 'Konzept / visuelle Assets / IP-Design, registriert Assets' },
        { k: 'craftsman', n: 'Handwerker', d: 'Verfahrensumsetzung / Musterbau / QC-Feedback, iteriert mit Designer' },
      ],
      matrixTitle: 'Lizenzmatrix (Demo-Regeln)',
      matrixHint: 'Publish-Version versteckt echte Lizenzdaten; Demo-Struktur',
      matrixHead: ['Asset', 'Exklusiv', 'Nicht-exklusiv', 'Region', 'Anteil'],
      matrixRows: [
        ['IP-Visual-Identität', '√', '—', 'Festlandchina', '30%'],
        ['Verfahrensparameter', '√', '√', 'Global', '25%'],
        ['Kurzvideo-Muster', '—', '√', 'Ausgewählte Kanäle', '20%'],
      ],
      sampleTitle: 'Muster-Eingang',
      sampleHint: 'KI-Sprachausgabe / 1080p-Muster / visuelle Assets sind privat und aus der Publish-Version ausgeschlossen; Kern nach Zuschlag geliefert.',
      sampleAction: 'Muster anfordern (Demo)',
      sampleModalTitle: 'Muster-Vorschau',
      sampleMain: 'Hauptmuster (KI-Stimme, 1080p)',
      sampleEp: 'IP-Kurzvideo-Muster',
      sampleLoading: 'Laden…',
      sampleReady: 'Abspielbar',
      sampleHidden: 'Demo-Muster gemäß Anti-Free-Ride-Vereinbarung verborgen; nach Zuschlag geliefert',
      sampleClose: 'Schließen',
    },
    d: {
      title: 'Design-Co-Creation-Wettbewerb · MODUL D',
      sub: 'Drei-Track-Anmeldung (Demo) · Smart-Review-Gate · KPI-Board',
      trackTitle: 'Drei Tracks',
      tracks: [
        { k: 'craft', n: 'Handwerksinnovation', d: 'Material × Verfahren × Tradition neu' },
        { k: 'ip', n: 'IP-Derivat', d: 'Kulturelles IP × kommerzielles Design' },
        { k: 'combo', n: 'Branchenübergreifend', d: 'Multi-Industrie C2M Customization' },
      ],
      regTitle: 'Wettbewerbsanmeldung (Demo)',
      regName: 'Team / Person', regTrack: 'Track', regCity: 'Region', regDesc: 'Werkbeschreibung',
      submitReg: 'Anmeldung senden', regOk: 'Anmeldung eingegangen (Demo)',
      entries: 'Anmeldungs-Ledger', emptyEntries: 'Keine Anmeldungen',
      gateTitle: 'Musterbau-Gate (Demo-Regeln)',
      gateRules: ['Anmelden → Eignung → KI-Review-Scoring → Muster-Ressourcen nach Bestehen', 'Publish-Version versteckt das echte Review-Modell; Gate-Regeln sind Demo'],
    },
    orders: {
      title: 'Aufträge & Fabrik',
      sub: 'Auftragserstellung (Demo) · Auftrags-Zustandsmaschine G4 Ledger (visualisiert)',
      createTitle: 'Auftragserstellungs-Formular (Demo)',
      createHint: 'Noch kein Auftrags-Endpunkt; lokale Demo erzeugt Aufträge und treibt die Zustandsmaschine',
      ordProduct: 'Produkt', ordQty: 'Menge', ordBatch: 'Charge', ordDeadline: 'Liefertermin',
      ordPlaceholders: { product: 'z.B. Silber C2M Halskette', qty: 'z.B. 200', batch: 'z.B. B-2026-003', deadline: 'z.B. 2026-12-01' },
      createOrder: 'Auftrag erstellen', orders: 'Auftragsliste',
      emptyOrders: 'Keine Aufträge', status: 'Status',
      stepperTitle: 'Auftrags-Zustandsmaschine (G4 · Rückverfolgbares Ledger)',
      stepperHint: 'Ereignis-Buttons klicken zum Fortschritt; Ledger zeichnet jeden Schritt mit Zeitstempel',
      trigger: 'Ereignis auslösen', timeline: 'Trace-Ledger', emptyTimeline: 'Noch keine Ereignisse',
      eventPlaceholder: 'Auftrag wählen',
      evtCreate: 'Erstellen', evtOrder: 'Disponieren', evtProduce: 'Produzieren', evtQc: 'QC', evtPack: 'Verpacken', evtShip: 'Versenden', evtAccept: 'Abnehmen',
      noOrderHint: 'Zuerst oben einen Auftrag erstellen, dann Zustandsmaschine treiben',
    },
    contracts: {
      title: 'Verträge & Regeln',
      sub: 'Lizenzvertragstypen · Anteilsregeln · Compliance-Kennzeichnung (Demo-Struktur im Publish)',
      typesTitle: 'Lizenzvertragstypen (Demo)',
      types: [
        { n: 'Exklusivlizenz', d: 'Exklusive Nutzung in vereinbarter Region / Kanal, höchster Anteil' },
        { n: 'Nicht-exklusive Lizenz', d: 'Parallele Lizenznehmer, Anteil auf tatsächlichen Umsatz' },
        { n: 'Kundenauftragsvertrag', d: 'C2M Einzelfertigung mit Liefer- und Abnahmeklauseln' },
      ],
      rulesTitle: 'Anteils- & Übergangsregeln (Demo)',
      rules: [
        'Lizenzanteile sind im Publish Platzhalter (null); echte Werte nach Zuschlag bestätigt',
        'Zustandsübergänge: DRAFT→ORDERED→PRODUCING→QC→PACKED→SHIPPED→ACCEPTED',
        'G2-Strengprüfung: fehlt eines der 6 Felder → Ablehnung, um unvollständige Lizenzen zu verhindern',
      ],
      complianceTitle: 'Compliance-Kennzeichnung (G10)',
      complianceHint: '21/22 Datendateien mit Synthetik-/Anonymisierungs-Kennzeichnung; Erklärung im Publish behalten',
    },
    ops: {
      title: 'Abnahme & Deployment',
      sub: 'G1–G10-Checkliste · Service-Ports · Backend-Health (Echte API)',
      healthTitle: 'Backend-Health',
      healthOk: 'Online', healthBad: 'Nicht erreichbar', healthChecking: 'Prüfe…',
      healthErrorHint: 'App-Container Port 8000 prüfen (docker compose ps) oder Vite-Proxy APP_API_TARGET',
      verifyTitle: 'G1–G10-Abnahme-Checkliste (output/VERIFICATION_heavy.md)',
      verify: [
        ['G1', 'Vier Flüsse im Kreis: A Co-Creation / B sechs Komponenten / C Zwei-Rollen+Lizenz / D Wettbewerbs-Gate'],
        ['G2', 'Strenge Autorisierung: Ablehnung 6/6 bei fehlendem Feld, Bestehen bei vollständig'],
        ['G3', 'Fertigbarkeitsregeln = manuelle Prüfung 10/10'],
        ['G4', 'Auftrags-Zustandsmaschine: 7 rückverfolgbare QC-Ledger-Einträge'],
        ['G5', 'FDE konfigurierbare Branchen: jewelry / wood'],
        ['G6', 'Dreisprachig (zh / en / de) + Anfrage-CRM-Loop'],
        ['G7', 'Zwei-Rollen-Co-Creation + Lizenzmatrix + Muster auf Datenträger'],
        ['G8', 'pytest 126 passed, exit=0'],
        ['G9', 'Selbstprüf-Befehle lauffähig 8/8'],
        ['G10', 'Synthetik-/Anonymisierungs-Kennzeichnung deckt 21/22 Datendateien'],
      ],
      portsTitle: 'Service-Ports',
      ports: [
        ['5173', 'Frontend-Dashboard (diese Seite)', 'http://<IP>:5173'],
        ['8000', 'FastAPI-Backend + Swagger', 'http://<IP>:8000/docs'],
        ['5432', 'PostgreSQL 16 (nur intern)', 'Nicht exponiert'],
      ],
      colPort: 'Port', colUse: 'Zweck', colHow: 'Zugriff',
    },
    common: {
      backends: 'Backend', frontend: 'Frontend', database: 'Datenbank', statusOk: 'OK', statusFail: 'FEHLER',
    },
  },
};

const STACK = [
  ['FastAPI + Uvicorn', 'API 服务层'],
  ['React 18 + Vite', '前端仪表盘'],
  ['PostgreSQL 16 + pgvector', '向量数据库'],
  ['SDXL / ComfyUI（mock 降级）', 'AIGC 图像'],
  ['本地 / API 双轨 LLM', '大模型接入'],
  ['Docker Compose', '三平台一键部署'],
];

const TABS = [
  { id: 'a', icon: 'A', cls: 'tab-a' },
  { id: 'b', icon: 'B', cls: 'tab-b' },
  { id: 'c', icon: 'C', cls: 'tab-c' },
  { id: 'd', icon: 'D', cls: 'tab-d' },
  { id: 'orders', icon: '◈', cls: 'tab-orders' },
  { id: 'contracts', icon: '⚖', cls: 'tab-contracts' },
  { id: 'ops', icon: '◉', cls: 'tab-ops' },
];

/* ---------- 小组件 ---------- */
function Field({ label, children }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
    </label>
  );
}

function Badge({ tone = 'ok', children }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

/* ---------- 页签 A：创意工作台 ---------- */
function StudioATab({ t, lang, industries, comps, compsError }) {
  const [industry, setIndustry] = useState(industries && industries.length ? industries[0] : '');
  const [material, setMaterial] = useState('');
  const [process, setProcess] = useState('');
  const [style, setStyle] = useState('');
  const [note, setNote] = useState('');
  const [concept, setConcept] = useState(null);

  // G2 强校验 demo
  const [auth, setAuth] = useState({ holder: '', type: '', region: '', term: '', scope: '', ratio: '' });
  const [authResult, setAuthResult] = useState(null);

  const authKeys = ['holder', 'type', 'region', 'term', 'scope', 'ratio'];
  const runAuth = () => {
    const missing = authKeys.filter((k) => !auth[k].trim());
    setAuthResult(missing.length ? { pass: false, missing } : { pass: true, missing: [] });
  };

  const compsHere = (industry && comps[industry]) || [];
  const manufacturable = compsHere.length >= 3;

  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.a.title}</h2>
        <p className="panel-sub">{t.a.sub}</p>
      </div>

      <div className="grid-2">
        <section className="card">
          <div className="card-title">{t.a.conceptTitle}</div>
          <p className="hint">{t.a.conceptHint}</p>
          <Field label={t.a.industryLabel}>
            <select value={industry} onChange={(e) => setIndustry(e.target.value)}>
              {industries.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </Field>
          <div className="grid-3">
            <Field label={t.a.material}><input value={material} onChange={(e) => setMaterial(e.target.value)} placeholder={t.a.authPlaceholders.type.split(' ')[0]} /></Field>
            <Field label={t.a.process}><input value={process} onChange={(e) => setProcess(e.target.value)} /></Field>
            <Field label={t.a.style}><input value={style} onChange={(e) => setStyle(e.target.value)} /></Field>
          </div>
          <Field label={t.a.conceptNote}>
            <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder={t.a.placeholderConcept} />
          </Field>
          <div className="btn-row">
            <button className="btn btn-primary" onClick={() => setConcept({ industry, material, process, style, note })}>{t.a.generate}</button>
            <button className="btn" onClick={() => { setConcept(null); setMaterial(''); setProcess(''); setStyle(''); setNote(''); }}>{t.a.clearing}</button>
          </div>
          {concept && (
            <div className="result-box">
              <div className="card-title">{t.a.conceptResult}</div>
              <p>{t.a.conceptLine.replace('{industry}', concept.industry || '-').replace('{style}', concept.style || '—').replace('{material}', concept.material || '—').replace('{process}', concept.process || '—')}</p>
              {concept.note && <p className="muted small">{concept.note}</p>}
            </div>
          )}
        </section>

        <section className="card">
          <div className="card-title">{t.a.authTitle}</div>
          <p className="hint">{t.a.authDesc}</p>
          <div className="grid-2">
            {authKeys.map((k) => (
              <Field key={k} label={t.a.authFields[k]}>
                <input value={auth[k]} onChange={(e) => setAuth({ ...auth, [k]: e.target.value })} placeholder={t.a.authPlaceholders[k]} />
              </Field>
            ))}
          </div>
          <button className="btn btn-primary" onClick={runAuth}>{t.a.runAuth}</button>
          {authResult && (
            <div className={`demo-result ${authResult.pass ? 'pass' : 'reject'}`}>
              {authResult.pass
                ? <div><strong>{t.a.authPass}</strong><div className="muted small">{t.a.allPass}</div></div>
                : <div><strong>{t.a.authReject}</strong><div className="muted small">{t.a.missingList}：{authResult.missing.map((m) => t.a.authFields[m]).join(' / ')}</div></div>}
            </div>
          )}
        </section>
      </div>

      <section className="card">
        <div className="card-title">{t.a.manufactTitle}</div>
        <p className="hint">{t.a.manufactHint}</p>
        {compsError && <div className="error-box">{compsError}</div>}
        <div className="flex-line">
          <Badge tone={manufacturable ? 'ok' : 'warn'}>{manufacturable ? t.a.manufactReady : t.a.manufactBlock}</Badge>
          <span className="muted small">{t.a.compLabel}（{industry}）：{compsHere.length > 0 ? compsHere.map((c) => c.name).join(' · ') : '—'}</span>
        </div>
      </section>
    </div>
  );
}

/* ---------- 页签 B：企业AI服务层 ---------- */
function EnterpriseTab({ t, lang, industries, comps, compsError }) {
  const [cur, setCur] = useState(industries && industries.length ? industries[0] : '');
  const [inquiry, setInquiry] = useState({ company: '', contact: '', country: t.b.countries[0], langSel: t.b.languages[0], msg: '' });
  const [ledger, setLedger] = useState([]);

  const submitInquiry = () => {
    if (!inquiry.company.trim() || !inquiry.contact.trim()) return;
    setLedger((prev) => [{ ...inquiry, at: new Date().toLocaleString(lang === 'de' ? 'de-DE' : lang === 'en' ? 'en-GB' : 'zh-CN') }, ...prev]);
    setInquiry({ ...inquiry, company: '', contact: '', msg: '' });
  };

  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.b.title}</h2>
        <p className="panel-sub">{t.b.sub}</p>
      </div>

      <div className="grid-2">
        <section className="card">
          <div className="card-title">{t.b.industryTitle}</div>
          <p className="hint">{t.b.industryHint}</p>
          {industries.length === 0 && <div className="muted">{t.b.loading}</div>}
          <div className="ind-switch">
            {industries.map((n) => (
              <button key={n} className={`ind-btn ${cur === n ? 'active' : ''}`} onClick={() => setCur(n)}>
                {n}
                {cur === n && <Badge tone="ok">{t.b.currentIndustry}</Badge>}
              </button>
            ))}
          </div>
          <div className="card-title small-title">{t.b.compTitle} · {cur}</div>
          {compsError && <div className="error-box">{compsError}</div>}
          {comps[cur] && comps[cur].length > 0 ? (
            <div className="comp-grid">
              {comps[cur].map((c) => (
                <div className="comp-card" key={c.name}>
                  <div className="comp-name">{c.name}</div>
                  <div className="muted small">{c.desc || '—'}</div>
                </div>
              ))}
            </div>
          ) : <div className="muted">{t.b.loading}</div>}
        </section>

        <section className="card">
          <div className="card-title">{t.b.inquiryTitle}</div>
          <p className="hint">{t.b.inquiryHint}</p>
          <Field label={t.b.inqCompany}><input value={inquiry.company} onChange={(e) => setInquiry({ ...inquiry, company: e.target.value })} /></Field>
          <Field label={t.b.inqContact}><input value={inquiry.contact} onChange={(e) => setInquiry({ ...inquiry, contact: e.target.value })} /></Field>
          <div className="grid-2">
            <Field label={t.b.inqCountry}>
              <select value={inquiry.country} onChange={(e) => setInquiry({ ...inquiry, country: e.target.value })}>
                {t.b.countries.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <Field label={t.b.inqLang}>
              <select value={inquiry.langSel} onChange={(e) => setInquiry({ ...inquiry, langSel: e.target.value })}>
                {t.b.languages.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
          </div>
          <Field label={t.b.inqMsg}><textarea rows={3} value={inquiry.msg} onChange={(e) => setInquiry({ ...inquiry, msg: e.target.value })} /></Field>
          <button className="btn btn-primary" onClick={submitInquiry}>{t.b.submitInquiry}</button>

          <div className="card-title small-title">{t.b.inquiries}</div>
          {ledger.length === 0 ? <div className="muted small">{t.b.emptyInquiries}</div> : (
            <div className="ledger">
              {ledger.map((it, i) => (
                <div className="ledger-item" key={i}>
                  <strong>{it.company}</strong>
                  <span className="muted small">{it.contact} · {it.country} · {it.langSel} · {it.at}</span>
                  {it.msg && <div className="muted small">{it.msg}</div>}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

/* ---------- 页签 C：IP工作室 ---------- */
const SAMPLE_VIDEOS = [
  { url: '/media/demo_video/ai_demo_heavy_1080p_voice_neil_bgm_v1.mp4', labelKey: 'sampleMain' },
  { url: '/media/samples/demo_ep001.mp4', labelKey: 'sampleEp' },
];

function SampleModal({ t, onClose }) {
  const [states, setStates] = useState({});
  const mark = (url, status) => setStates((prev) => ({ ...prev, [url]: status }));
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <span className="modal-title">{t.c.sampleModalTitle}</span>
          <button className="modal-close" onClick={onClose} title={t.c.sampleClose}>×</button>
        </div>
        <div className="modal-body">
          {SAMPLE_VIDEOS.map((s) => (
            <div className="sample-item" key={s.url}>
              <div className="sample-label">{t.c[s.labelKey]}</div>
              {states[s.url] === 'missing' ? (
                <div className="placeholder-box">{t.c.sampleHidden}</div>
              ) : (
                <>
                  <video className="sample-player" controls preload="metadata"
                    onCanPlay={() => mark(s.url, 'ready')}
                    onError={() => mark(s.url, 'missing')}>
                    <source src={s.url} type="video/mp4" />
                  </video>
                  {states[s.url] === 'ready' && <div className="muted small">{t.c.sampleReady} · {s.url}</div>}
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function IpStudioTab({ t }) {
  const [showSample, setShowSample] = useState(false);
  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.c.title}</h2>
        <p className="panel-sub">{t.c.sub}</p>
      </div>
      <div className="grid-2">
        <section className="card">
          <div className="card-title">{t.c.roleTitle}</div>
          <div className="role-grid">
            {t.c.roles.map((r) => (
              <div className="role-card" key={r.k}>
                <div className="role-name">{r.n}</div>
                <div className="muted small">{r.d}</div>
              </div>
            ))}
          </div>
        </section>
        <section className="card">
          <div className="card-title">{t.c.sampleTitle}</div>
          <p className="hint">{t.c.sampleHint}</p>
          <button className="btn btn-primary" onClick={() => setShowSample(true)}>{t.c.sampleAction}</button>
          {showSample && <SampleModal t={t} onClose={() => setShowSample(false)} />}
        </section>
      </div>
      <section className="card">
        <div className="card-title">{t.c.matrixTitle}</div>
        <p className="hint">{t.c.matrixHint}</p>
        <table className="matrix-table">
          <thead><tr>{t.c.matrixHead.map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>
            {t.c.matrixRows.map((row, i) => (
              <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}

/* ---------- 页签 D：赛事包 ---------- */
function ContestTab({ t, lang }) {
  const [reg, setReg] = useState({ name: '', track: t.d.tracks[0].k, city: '', desc: '' });
  const [entries, setEntries] = useState([]);
  const submit = () => {
    if (!reg.name.trim()) return;
    const track = t.d.tracks.find((x) => x.k === reg.track);
    setEntries((prev) => [{ ...reg, trackName: track ? track.n : reg.track, at: new Date().toLocaleString(lang === 'de' ? 'de-DE' : lang === 'en' ? 'en-GB' : 'zh-CN') }, ...prev]);
    setReg({ name: '', track: reg.track, city: '', desc: '' });
  };
  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.d.title}</h2>
        <p className="panel-sub">{t.d.sub}</p>
      </div>
      <section className="card">
        <div className="card-title">{t.d.trackTitle}</div>
        <div className="track-grid">
          {t.d.tracks.map((tr) => (
            <div className="track-card" key={tr.k}>
              <div className="track-name">{tr.n}</div>
              <div className="muted small">{tr.d}</div>
            </div>
          ))}
        </div>
      </section>
      <div className="grid-2">
        <section className="card">
          <div className="card-title">{t.d.regTitle}</div>
          <Field label={t.d.regName}><input value={reg.name} onChange={(e) => setReg({ ...reg, name: e.target.value })} /></Field>
          <Field label={t.d.regTrack}>
            <select value={reg.track} onChange={(e) => setReg({ ...reg, track: e.target.value })}>
              {t.d.tracks.map((tr) => <option key={tr.k} value={tr.k}>{tr.n}</option>)}
            </select>
          </Field>
          <Field label={t.d.regCity}><input value={reg.city} onChange={(e) => setReg({ ...reg, city: e.target.value })} /></Field>
          <Field label={t.d.regDesc}><textarea rows={2} value={reg.desc} onChange={(e) => setReg({ ...reg, desc: e.target.value })} /></Field>
          <button className="btn btn-primary" onClick={submit}>{t.d.submitReg}</button>
        </section>
        <section className="card">
          <div className="card-title">{t.d.entries}</div>
          {entries.length === 0 ? <div className="muted small">{t.d.emptyEntries}</div> : (
            <div className="ledger">
              {entries.map((it, i) => (
                <div className="ledger-item" key={i}>
                  <strong>{it.name}</strong>
                  <span className="muted small">{it.trackName} · {it.city || '—'} · {it.at}</span>
                  {it.desc && <div className="muted small">{it.desc}</div>}
                </div>
              ))}
            </div>
          )}
          <div className="card-title small-title">{t.d.gateTitle}</div>
          {t.d.gateRules.map((r, i) => <div className="rule-line" key={i}>· {r}</div>)}
        </section>
      </div>
    </div>
  );
}

/* ---------- 页签：订单与工厂 ---------- */
function OrdersTab({ t, lang }) {
  const [orders, setOrders] = useState([]);
  const [form, setForm] = useState({ product: '', qty: '', batch: '', deadline: '' });
  const [active, setActive] = useState(null);
  const [events, setEvents] = useState({});

  const createOrder = () => {
    if (!form.product.trim()) return;
    const id = `ORD-${Date.now().toString().slice(-6)}`;
    const order = { id, product: form.product, qty: form.qty || '—', batch: form.batch || '—', deadline: form.deadline || '—', idx: 0 };
    setOrders((prev) => [order, ...prev]);
    setEvents((prev) => ({ ...prev, [id]: [{ step: 0, evt: 'CREATE', at: new Date().toLocaleString(lang === 'de' ? 'de-DE' : lang === 'en' ? 'en-GB' : 'zh-CN') }] }));
    setActive(id);
    setForm({ product: '', qty: '', batch: '', deadline: '' });
  };

  const advance = (evtKey, stepTo) => {
    if (!active) return;
    const cur = orders.find((o) => o.id === active);
    if (!cur || cur.idx >= STATUS_FLOW.length - 1) return;
    const nextIdx = Math.min(stepTo, STATUS_FLOW.length - 1);
    const nextOrders = orders.map((o) => (o.id === active ? { ...o, idx: nextIdx } : o));
    setOrders(nextOrders);
    setEvents((prev) => ({
      ...prev,
      [active]: [...(prev[active] || []), { step: nextIdx, evt: evtKey, at: new Date().toLocaleString(lang === 'de' ? 'de-DE' : lang === 'en' ? 'en-GB' : 'zh-CN') }],
    }));
  };

  const activeOrder = active ? orders.find((o) => o.id === active) : null;
  const activeEvents = active ? events[active] || [] : [];
  const evtButtons = [
    ['evtOrder', 1], ['evtProduce', 2], ['evtQc', 3], ['evtPack', 4], ['evtShip', 5], ['evtAccept', 6],
  ];

  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.orders.title}</h2>
        <p className="panel-sub">{t.orders.sub}</p>
      </div>
      <div className="grid-2">
        <section className="card">
          <div className="card-title">{t.orders.createTitle}</div>
          <p className="hint">{t.orders.createHint}</p>
          <Field label={t.orders.ordProduct}><input value={form.product} onChange={(e) => setForm({ ...form, product: e.target.value })} placeholder={t.orders.ordPlaceholders.product} /></Field>
          <div className="grid-3">
            <Field label={t.orders.ordQty}><input value={form.qty} onChange={(e) => setForm({ ...form, qty: e.target.value })} placeholder={t.orders.ordPlaceholders.qty} /></Field>
            <Field label={t.orders.ordBatch}><input value={form.batch} onChange={(e) => setForm({ ...form, batch: e.target.value })} placeholder={t.orders.ordPlaceholders.batch} /></Field>
            <Field label={t.orders.ordDeadline}><input value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} placeholder={t.orders.ordPlaceholders.deadline} /></Field>
          </div>
          <button className="btn btn-primary" onClick={createOrder}>{t.orders.createOrder}</button>
          <div className="card-title small-title">{t.orders.orders}</div>
          {orders.length === 0 ? <div className="muted small">{t.orders.emptyOrders}</div> : (
            <div className="order-list">
              {orders.map((o) => (
                <button key={o.id} className={`order-item ${active === o.id ? 'active' : ''}`} onClick={() => setActive(o.id)}>
                  <strong>{o.id}</strong>
                  <span className="muted small">{o.product} · {t.orders.status}: {STATUS_FLOW[o.idx][lang === 'de' ? 'de' : lang === 'en' ? 'en' : 'zh']}</span>
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="card">
          <div className="card-title">{t.orders.stepperTitle}</div>
          <p className="hint">{t.orders.stepperHint}</p>
          {!activeOrder ? (
            <div className="muted">{t.orders.noOrderHint}</div>
          ) : (
            <>
              <div className="stepper">
                {STATUS_FLOW.map((s, i) => (
                  <React.Fragment key={s.key}>
                    <div className={`step ${i <= activeOrder.idx ? 'done' : ''}`}>
                      <span className="step-dot">{i + 1}</span>
                      <span className="step-label">{s[lang === 'de' ? 'de' : lang === 'en' ? 'en' : 'zh']}</span>
                    </div>
                    {i < STATUS_FLOW.length - 1 && <span className="step-arrow">→</span>}
                  </React.Fragment>
                ))}
              </div>
              <div className="card-title small-title">{t.orders.trigger}</div>
              <div className="btn-row">
                {evtButtons.map(([k, to]) => (
                  <button key={k} className="btn btn-small" disabled={activeOrder.idx >= to - 1 && activeOrder.idx >= to} onClick={() => advance(k, to)}>{t.orders[k]}</button>
                ))}
              </div>
              <div className="card-title small-title">{t.orders.timeline}</div>
              {activeEvents.length === 0 ? <div className="muted small">{t.orders.emptyTimeline}</div> : (
                <div className="timeline">
                  {activeEvents.map((e, i) => (
                    <div className="timeline-item" key={i}>
                      <span className="timeline-dot" />
                      <div>
                        <strong>{e.evt}</strong>
                        <span className="muted small"> → {STATUS_FLOW[e.step][lang === 'de' ? 'de' : lang === 'en' ? 'en' : 'zh']} · {e.at}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </section>
      </div>
    </div>
  );
}

/* ---------- 页签：契约与规则 ---------- */
function ContractsTab({ t }) {
  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.contracts.title}</h2>
        <p className="panel-sub">{t.contracts.sub}</p>
      </div>
      <div className="grid-2">
        <section className="card">
          <div className="card-title">{t.contracts.typesTitle}</div>
          <div className="role-grid">
            {t.contracts.types.map((ty, i) => (
              <div className="role-card" key={i}>
                <div className="role-name">{ty.n}</div>
                <div className="muted small">{ty.d}</div>
              </div>
            ))}
          </div>
        </section>
        <section className="card">
          <div className="card-title">{t.contracts.complianceTitle}</div>
          <p className="hint">{t.contracts.complianceHint}</p>
        </section>
      </div>
      <section className="card">
        <div className="card-title">{t.contracts.rulesTitle}</div>
        {t.contracts.rules.map((r, i) => <div className="rule-line" key={i}>· {r}</div>)}
      </section>
    </div>
  );
}

/* ---------- 页签：验收与部署 ---------- */
function OpsTab({ t, health }) {
  const healthColor = health.loading ? '#9fb3d1' : health.ok ? '#2dd4bf' : '#f87171';
  return (
    <div className="tab-panel">
      <div className="panel-head">
        <h2>{t.ops.title}</h2>
        <p className="panel-sub">{t.ops.sub}</p>
      </div>

      <section className="card status-card" style={{ borderColor: healthColor }}>
        <div className="card-title">{t.ops.healthTitle} · GET /api/health</div>
        <div className="status-line">
          <span className="dot" style={{ background: healthColor }} />
          <span className="status-text" style={{ color: healthColor }}>
            {health.loading ? t.ops.healthChecking : health.ok ? t.ops.healthOk : t.ops.healthBad}
          </span>
          {!health.loading && health.ok && health.stack && <span className="muted small">{health.stack}</span>}
        </div>
        {!health.loading && !health.ok && <div className="error-box small">{t.ops.healthErrorHint}（{health.error}）</div>}
      </section>

      <section className="card">
        <div className="card-title">{t.ops.verifyTitle}</div>
        <div className="verify-grid">
          {t.ops.verify.map(([g, text]) => (
            <div className="verify-item" key={g}>
              <span className="verify-g">{g}</span>
              <span className="verify-t">{text}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <div className="card-title">{t.ops.portsTitle}</div>
        <table className="port-table">
          <thead><tr><th>{t.ops.colPort}</th><th>{t.ops.colUse}</th><th>{t.ops.colHow}</th></tr></thead>
          <tbody>
            {t.ops.ports.map(([p, use, how]) => (
              <tr key={p}><td><code>{p}</code></td><td>{use}</td><td className="muted">{how}</td></tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}

/* ---------- 主应用 ---------- */
function App() {
  const [lang, setLang] = useState('zh');
  const [tab, setTab] = useState('a');
  const [health, setHealth] = useState({ loading: true, ok: null, msg: '', stack: '', error: '' });
  const [industries, setIndustries] = useState([]);
  const [comps, setComps] = useState({});
  const [compsError, setCompsError] = useState('');

  useEffect(() => {
    async function getJSON(url) {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    }

    (async () => {
      try {
        const h = await getJSON('/api/health');
        setHealth({ loading: false, ok: true, msg: h.status || 'ok', stack: h.stack || '', error: '' });
      } catch (e) {
        setHealth({ loading: false, ok: false, msg: '不可达', stack: '', error: String(e.message || e) });
      }

      try {
        const d = await getJSON('/api/industries');
        const names = d.industries || [];
        setIndustries(names);
        for (const name of names) {
          try {
            const c = await getJSON(`/api/components/${name}`);
            setComps((prev) => ({ ...prev, [name]: c.components || [] }));
          } catch (e) {
            setComps((prev) => ({ ...prev, [name]: [] }));
            setCompsError(`行业组件接口不可达（${name}）`);
          }
        }
      } catch (e) {
        setIndustries([]);
        setCompsError(String(e.message || e));
      }
    })();
  }, []);

  const t = I18N[lang] || I18N.zh;
  const renderTab = () => {
    switch (tab) {
      case 'a': return <StudioATab t={t} lang={lang} industries={industries} comps={comps} compsError={compsError} />;
      case 'b': return <EnterpriseTab t={t} lang={lang} industries={industries} comps={comps} compsError={compsError} />;
      case 'c': return <IpStudioTab t={t} />;
      case 'd': return <ContestTab t={t} lang={lang} />;
      case 'orders': return <OrdersTab t={t} lang={lang} />;
      case 'contracts': return <ContractsTab t={t} />;
      case 'ops': return <OpsTab t={t} health={health} />;
      default: return null;
    }
  };

  return (
    <div className="page">
      <div className="grid-bg" />
      <header className="hero">
        <div className="hero-top">
          <span className="brand">{t.brand}</span>
          <span className="chip chip-accent">{t.chip}</span>
          <div className="lang-switch">
            {['zh', 'en', 'de'].map((l) => (
              <button key={l} className={`lang-btn ${lang === l ? 'active' : ''}`} onClick={() => setLang(l)}>{l.toUpperCase()}</button>
            ))}
          </div>
          <span className={`health-mini ${health.ok ? 'ok' : health.loading ? 'check' : 'bad'}`} title="GET /api/health">
            {health.loading ? '…' : health.ok ? '✓' : '✗'}
          </span>
        </div>
        <h1>{t.heroTitle}</h1>
        <p className="sub">{t.heroSub}</p>
        <div className="stack">
          {STACK.map(([name, role]) => (
            <span className="chip" key={name}>{name}<em>{role}</em></span>
          ))}
        </div>
      </header>

      <nav className="tabnav">
        {TABS.map((tb) => (
          <button key={tb.id} className={`tab-btn ${tab === tb.id ? 'active' : ''} ${tb.cls}`} onClick={() => setTab(tb.id)}>
            <span className="tab-icon">{tb.icon}</span>
            <span className="tab-label">{t.tabs[tb.id]}</span>
          </button>
        ))}
      </nav>

      <main>{renderTab()}</main>

      <footer>
        {t.brand} · 重技术栈应标原型 · {new Date().getFullYear()} · {t.footer}
      </footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
